# AI 머니 트래커 서버 시작 스크립트 (PowerShell)

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "    🎯 AI 머니 트래커 서버 시작" -ForegroundColor Yellow
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# 현재 디렉토리로 이동
Set-Location $PSScriptRoot

Write-Host "📦 필요한 패키지 설치 확인 중..." -ForegroundColor Green
python -m pip install -r requirements.txt --quiet

Write-Host ""
Write-Host "🚀 서버 시작 중..." -ForegroundColor Green
Write-Host "브라우저에서 http://localhost:8018 접속하세요" -ForegroundColor Yellow
Write-Host ""
Write-Host "서버를 중지하려면 Ctrl+C를 누르세요" -ForegroundColor Red
Write-Host "========================================" -ForegroundColor Cyan

# 서버 시작
python -m uvicorn backend.main:app --host 0.0.0.0 --port 8018 --reload

Read-Host "Press Enter to exit"
