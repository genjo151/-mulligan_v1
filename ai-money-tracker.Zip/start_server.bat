@echo off
echo ========================================
echo    🎯 AI 머니 트래커 서버 시작
echo ========================================
echo.

cd /d "%~dp0"

echo 📦 필요한 패키지 설치 확인 중...
python -m pip install -r requirements.txt --quiet

echo.
echo 🚀 서버 시작 중...
echo 브라우저에서 http://localhost:8018 접속하세요
echo.
echo 서버를 중지하려면 Ctrl+C를 누르세요
echo ========================================

python -m uvicorn backend.main:app --host 0.0.0.0 --port 8018 --reload

pause
