// AI 머니 트래커 - 메인 앱
class AIMoneyTracker {
    constructor() {
        this.currentSection = 'dashboard';
        this.apiBaseUrl = `${window.location.protocol}//${window.location.host}`;
        this.init();
    }

    init() {
        this.bindEvents();
        this.loadDashboard();
        this.hideLoading();
    }

    bindEvents() {
        // 네비게이션
        document.addEventListener('click', (e) => {
            const navLink = e.target.closest('[data-section]');
            if (navLink) {
                e.preventDefault();
                this.navigateToSection(navLink.dataset.section);
            }
        });

        // 모바일 메뉴
        const mobileToggle = document.getElementById('mobileMenuToggle');
        if (mobileToggle) {
            mobileToggle.addEventListener('click', this.toggleMobileMenu.bind(this));
        }
    }

    navigateToSection(section) {
        document.querySelectorAll('.content-section').forEach(el => el.classList.remove('active'));
        document.querySelectorAll('.nav-link, .bottom-nav-item').forEach(el => el.classList.remove('active'));
        
        document.getElementById(section)?.classList.add('active');
        document.querySelectorAll(`[data-section="${section}"]`).forEach(el => el.classList.add('active'));
        
        this.currentSection = section;
        this.loadSectionData(section);
    }

    async loadSectionData(section) {
        switch (section) {
            case 'dashboard':
                await this.loadDashboard();
                break;
            case 'analysis':
                this.setupAnalysis();
                break;
        }
    }

    async loadDashboard() {
        this.updateElement('totalStocks', '2,847');
        this.updateElement('recommendedStocks', '23');
        this.updateElement('newSignals', '6');
        this.updateElement('responseTime', '0.8초');
        this.updateElement('systemStatus', '🟢');
        this.updateElement('statusText', '시스템 정상');
    }

    setupAnalysis() {
        const input = document.getElementById('stockCode');
        if (input) {
            input.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') this.analyzeStock();
            });
        }
    }

    async analyzeStock() {
        const stockCode = document.getElementById('stockCode')?.value.trim();
        if (!stockCode) {
            this.showToast('종목코드를 입력해주세요.', 'warning');
            return;
        }

        const container = document.getElementById('analysisResult');
        if (!container) return;

        container.innerHTML = `
            <div class="card">
                <div class="card-content">
                    <div class="loading-placeholder">분석 중...</div>
                </div>
            </div>
        `;

        try {
            const data = await this.api.get(`/api/v1/analysis/quick/${stockCode}`);
            container.innerHTML = `
                <div class="card">
                    <div class="card-header">
                        <h3>${stockCode} 분석 결과</h3>
                    </div>
                    <div class="card-content">
                        <p>총점: ${(data.total_score || 0).toFixed(2)}/8.9</p>
                        <p>추천등급: ${data.recommendation || '정보없음'}</p>
                    </div>
                </div>
            `;
        } catch (error) {
            container.innerHTML = `
                <div class="card">
                    <div class="card-content">
                        <p>분석 실패: ${error.message}</p>
                    </div>
                </div>
            `;
        }
    }

    toggleMobileMenu() {
        const sidebar = document.getElementById('sidebar');
        const toggle = document.getElementById('mobileMenuToggle');
        
        if (sidebar && toggle) {
            sidebar.classList.toggle('open');
            toggle.classList.toggle('active');
        }
    }

    updateElement(id, value) {
        const element = document.getElementById(id);
        if (element) element.textContent = value;
    }

    showToast(message, type = 'info') {
        console.log(`[${type}] ${message}`);
    }

    hideLoading() {
        const loading = document.getElementById('loading');
        if (loading) {
            loading.classList.add('hidden');
            setTimeout(() => loading.style.display = 'none', 300);
        }
    }

    get api() {
        return {
            get: async (url) => {
                const response = await fetch(this.apiBaseUrl + url);
                if (!response.ok) throw new Error(`HTTP ${response.status}`);
                return response.json();
            }
        };
    }
}

// 전역 함수들
function setStockCode(code) {
    const input = document.getElementById('stockCode');
    if (input) input.value = code;
}

function analyzeStock() {
    if (window.app) window.app.analyzeStock();
}

function generatePortfolio() {
    console.log('포트폴리오 생성');
}

function toggleScan() {
    console.log('스캔 토글');
}

// 앱 초기화
document.addEventListener('DOMContentLoaded', () => {
    window.app = new AIMoneyTracker();
});
