// AI 머니 트래커 - 메인 앱 로직

class SmartMoneyTracker {
    constructor() {
        this.currentPage = 'dashboard';
        this.stocksData = [];
        this.scanStatus = {
            isRunning: false,
            progress: 0,
            lastScanTime: null
        };
        
        this.init();
    }

    // 앱 초기화
    init() {
        this.setupEventListeners();
        this.setupWebSocketListeners();
        this.loadInitialData();
        this.requestNotificationPermission();
        this.setupServiceWorker();
        
        console.log('AI 머니 트래커가 시작되었습니다.');
    }

    // 이벤트 리스너 설정
    setupEventListeners() {
        // 네비게이션 버튼
        document.querySelectorAll('.nav-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const page = e.target.dataset.page;
                this.navigateTo(page);
            });
        });

        // 새로고침 버튼
        const refreshBtn = document.getElementById('refresh-btn');
        if (refreshBtn) {
            refreshBtn.addEventListener('click', () => this.refreshStockData());
        }

        // 필터 변경
        const scoreFilter = document.getElementById('score-filter');
        if (scoreFilter) {
            scoreFilter.addEventListener('change', () => this.filterStocks());
        }

        // 설정 저장 버튼
        const saveSettingsBtn = document.getElementById('save-settings');
        if (saveSettingsBtn) {
            saveSettingsBtn.addEventListener('click', () => this.saveSettings());
        }

        // 최소 스코어 슬라이더
        const minScoreSlider = document.getElementById('min-score');
        const minScoreValue = document.getElementById('min-score-value');
        if (minScoreSlider && minScoreValue) {
            minScoreSlider.addEventListener('input', (e) => {
                minScoreValue.textContent = e.target.value;
            });
        }

        // 푸시 알림 체크박스
        const pushNotifCheckbox = document.getElementById('push-notifications');
        if (pushNotifCheckbox) {
            pushNotifCheckbox.addEventListener('change', (e) => {
                if (e.target.checked) {
                    this.requestNotificationPermission();
                }
            });
        }
    }

    // WebSocket 이벤트 리스너 설정
    setupWebSocketListeners() {
        window.addEventListener('scan-status-update', (e) => {
            this.updateScanStatus(e.detail);
        });

        window.addEventListener('stock-update', (e) => {
            this.handleStockUpdate(e.detail);
        });

        window.addEventListener('new-notification', (e) => {
            this.showNotification(e.detail);
        });
    }

    // 페이지 이동
    navigateTo(page) {
        // 이전 페이지 숨기기
        document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
        document.querySelectorAll('.nav-btn').forEach(btn => btn.classList.remove('active'));

        // 새 페이지 표시
        const targetPage = document.getElementById(`${page}-page`);
        const targetBtn = document.querySelector(`[data-page="${page}"]`);
        
        if (targetPage && targetBtn) {
            targetPage.classList.add('active');
            targetBtn.classList.add('active');
            this.currentPage = page;

            // 페이지별 데이터 로드
            this.loadPageData(page);
        }
    }

    // 페이지별 데이터 로드
    async loadPageData(page) {
        switch (page) {
            case 'dashboard':
                await this.loadDashboardData();
                break;
            case 'settings':
                this.loadSettingsData();
                break;
            case 'history':
                await this.loadHistoryData();
                break;
        }
    }

    // 초기 데이터 로드
    async loadInitialData() {
        await this.loadDashboardData();
    }

    // 대시보드 데이터 로드
    async loadDashboardData() {
        try {
            // 스캔 상태 조회
            const scanStatus = await window.apiClient.getScanStatus();
            this.updateScanStatus(scanStatus);

            // 추천 종목 조회
            await this.refreshStockData();
        } catch (error) {
            console.error('대시보드 데이터 로드 실패:', error);
            this.showError('데이터를 불러오는 중 오류가 발생했습니다.');
        }
    }

    // 스캔 상태 업데이트
    updateScanStatus(status) {
        this.scanStatus = { ...this.scanStatus, ...status };

        // UI 업데이트
        const lastScanElement = document.getElementById('last-scan-time');
        const progressFill = document.getElementById('progress-fill');
        const progressText = document.getElementById('progress-text');

        if (lastScanElement) {
            if (this.scanStatus.lastScanTime) {
                const time = new Date(this.scanStatus.lastScanTime).toLocaleString('ko-KR');
                lastScanElement.textContent = time;
            } else {
                lastScanElement.textContent = this.scanStatus.isRunning ? '스캔 중...' : '대기 중';
            }
        }

        if (progressFill && progressText) {
            const progress = Math.round(this.scanStatus.progress || 0);
            progressFill.style.width = `${progress}%`;
            progressText.textContent = `${progress}%`;
        }
    }

    // 종목 데이터 새로고침
    async refreshStockData() {
        try {
            const stocksList = document.getElementById('stocks-list');
            if (stocksList) {
                stocksList.innerHTML = '<div class="loading">종목 데이터를 불러오는 중...</div>';
            }

            const filters = {
                minScore: window.appConfig.get('minScore'),
                sectors: window.appConfig.get('excludedSectors')
            };

            this.stocksData = await window.apiClient.getRecommendedStocks(filters);
            this.renderStocksList();
        } catch (error) {
            console.error('종목 데이터 새로고침 실패:', error);
            const stocksList = document.getElementById('stocks-list');
            if (stocksList) {
                stocksList.innerHTML = '<div class="error">데이터를 불러올 수 없습니다.</div>';
            }
        }
    }

    // 종목 리스트 렌더링
    renderStocksList() {
        const stocksList = document.getElementById('stocks-list');
        if (!stocksList) return;

        if (!this.stocksData || this.stocksData.length === 0) {
            stocksList.innerHTML = '<div class="loading">추천 종목이 없습니다.</div>';
            return;
        }

        const html = this.stocksData.map(stock => this.createStockCardHtml(stock)).join('');
        stocksList.innerHTML = html;

        // 종목 카드 클릭 이벤트
        stocksList.querySelectorAll('.stock-card').forEach(card => {
            card.addEventListener('click', () => {
                const stockCode = card.dataset.stockCode;
                this.showStockDetail(stockCode);
            });
        });
    }

    // 종목 카드 HTML 생성
    createStockCardHtml(stock) {
        const scoreClass = this.getScoreClass(stock.score);
        const scoreText = this.getScoreText(stock.score);

        return `
            <div class="stock-card" data-stock-code="${stock.code}">
                <div class="stock-header">
                    <div class="stock-name">${stock.name} (${stock.code})</div>
                    <div class="stock-score ${scoreClass}">${scoreText} ${stock.score.toFixed(1)}</div>
                </div>
                <div class="stock-details">
                    <div>현재가: ${stock.currentPrice ? stock.currentPrice.toLocaleString() : 'N/A'}원</div>
                    <div>변동률: ${stock.changePercent ? stock.changePercent.toFixed(2) : 'N/A'}%</div>
                    <div>거래량: ${stock.volume ? stock.volume.toLocaleString() : 'N/A'}</div>
                    <div>업종: ${stock.sector || 'N/A'}</div>
                </div>
            </div>
        `;
    }

    // 스코어 클래스 결정
    getScoreClass(score) {
        if (score >= 6.5) return 'score-high';
        if (score >= 5.5) return 'score-medium';
        return 'score-low';
    }

    // 스코어 텍스트 결정
    getScoreText(score) {
        if (score >= 6.5) return '🔴';
        if (score >= 5.5) return '🟡';
        return '⚪';
    }

    // 종목 필터링
    filterStocks() {
        const filter = document.getElementById('score-filter').value;
        let filteredStocks = [...this.stocksData];

        switch (filter) {
            case 'high':
                filteredStocks = filteredStocks.filter(stock => stock.score >= 6.5);
                break;
            case 'medium':
                filteredStocks = filteredStocks.filter(stock => stock.score >= 5.5);
                break;
        }

        // 임시로 원본 데이터 백업하고 필터링된 데이터로 렌더링
        const originalData = this.stocksData;
        this.stocksData = filteredStocks;
        this.renderStocksList();
        this.stocksData = originalData;
    }

    // 종목 상세 정보 표시
    async showStockDetail(stockCode) {
        try {
            const detail = await window.apiClient.getStockDetail(stockCode);
            if (detail) {
                // 모달이나 새 페이지로 상세 정보 표시
                alert(`${detail.name} 상세 정보\n스코어: ${detail.score}\n현재가: ${detail.currentPrice}원`);
            }
        } catch (error) {
            console.error('종목 상세 정보 조회 실패:', error);
        }
    }

    // 종목 업데이트 처리
    handleStockUpdate(stockData) {
        // 기존 데이터에서 해당 종목 찾아서 업데이트
        const index = this.stocksData.findIndex(stock => stock.code === stockData.code);
        if (index !== -1) {
            this.stocksData[index] = { ...this.stocksData[index], ...stockData };
            this.renderStocksList();
        }
    }

    // 설정 데이터 로드
    loadSettingsData() {
        const settings = window.appConfig.settings;

        // API 키 (보안상 일부만 표시)
        const dartApiKeyInput = document.getElementById('dart-api-key');
        const stockApiKeyInput = document.getElementById('stock-api-key');
        
        if (dartApiKeyInput && settings.dartApiKey) {
            dartApiKeyInput.value = settings.dartApiKey.substring(0, 8) + '***';
        }
        if (stockApiKeyInput && settings.stockApiKey) {
            stockApiKeyInput.value = settings.stockApiKey.substring(0, 8) + '***';
        }

        // 기타 설정
        const minScoreSlider = document.getElementById('min-score');
        const minScoreValue = document.getElementById('min-score-value');
        const pushNotifCheckbox = document.getElementById('push-notifications');
        const excludedSectors = document.getElementById('excluded-sectors');

        if (minScoreSlider) {
            minScoreSlider.value = settings.minScore;
            if (minScoreValue) minScoreValue.textContent = settings.minScore;
        }

        if (pushNotifCheckbox) {
            pushNotifCheckbox.checked = settings.pushNotifications;
        }

        if (excludedSectors && settings.excludedSectors) {
            Array.from(excludedSectors.options).forEach(option => {
                option.selected = settings.excludedSectors.includes(option.value);
            });
        }
    }

    // 설정 저장
    async saveSettings() {
        try {
            const newSettings = {
                minScore: parseFloat(document.getElementById('min-score').value),
                pushNotifications: document.getElementById('push-notifications').checked,
                excludedSectors: Array.from(document.getElementById('excluded-sectors').selectedOptions)
                    .map(option => option.value)
            };

            // API 키는 실제로 변경된 경우만 업데이트
            const dartApiKeyInput = document.getElementById('dart-api-key');
            const stockApiKeyInput = document.getElementById('stock-api-key');

            if (dartApiKeyInput.value && !dartApiKeyInput.value.includes('***')) {
                newSettings.dartApiKey = dartApiKeyInput.value;
            }
            if (stockApiKeyInput.value && !stockApiKeyInput.value.includes('***')) {
                newSettings.stockApiKey = stockApiKeyInput.value;
            }

            // 로컬 저장
            const success = window.appConfig.saveSettings(newSettings);
            
            if (success) {
                this.showNotification({
                    title: '설정 저장 완료',
                    message: '설정이 성공적으로 저장되었습니다.',
                    type: 'success'
                });

                // API 키가 변경된 경우 검증
                if (newSettings.dartApiKey || newSettings.stockApiKey) {
                    await this.testApiKeys();
                }
            }
        } catch (error) {
            console.error('설정 저장 실패:', error);
            this.showError('설정 저장에 실패했습니다.');
        }
    }

    // API 키 테스트
    async testApiKeys() {
        try {
            const results = await window.apiClient.testApiKeys();
            
            if (results.dartApi && !results.dartApi.success) {
                this.showError(`DART API 키 오류: ${results.dartApi.error}`);
            }
            if (results.stockApi && !results.stockApi.success) {
                this.showError(`증권사 API 키 오류: ${results.stockApi.error}`);
            }
            
            if (results.dartApi?.success && results.stockApi?.success) {
                this.showNotification({
                    title: 'API 키 검증 완료',
                    message: '모든 API 키가 정상적으로 작동합니다.',
                    type: 'success'
                });
            }
        } catch (error) {
            console.error('API 키 테스트 실패:', error);
        }
    }

    // 히스토리 데이터 로드
    async loadHistoryData() {
        try {
            const history = await window.apiClient.getNotificationHistory();
            // 히스토리 UI 업데이트 (추후 구현)
            console.log('히스토리 데이터:', history);
        } catch (error) {
            console.error('히스토리 데이터 로드 실패:', error);
        }
    }

    // 알림 표시
    showNotification(notification) {
        const notificationEl = document.createElement('div');
        notificationEl.className = `notification ${notification.type === 'error' ? 'error' : ''}`;
        notificationEl.innerHTML = `
            <div><strong>${notification.title || '알림'}</strong></div>
            <div>${notification.message}</div>
        `;

        document.body.appendChild(notificationEl);
        
        // 애니메이션으로 표시
        setTimeout(() => notificationEl.classList.add('show'), 100);
        
        // 5초 후 자동 제거
        setTimeout(() => {
            notificationEl.classList.remove('show');
            setTimeout(() => notificationEl.remove(), 300);
        }, 5000);
    }

    // 에러 표시
    showError(message) {
        this.showNotification({
            title: '오류',
            message: message,
            type: 'error'
        });
    }

    // 푸시 알림 권한 요청
    async requestNotificationPermission() {
        if ('Notification' in window) {
            if (Notification.permission === 'default') {
                const permission = await Notification.requestPermission();
                if (permission === 'granted') {
                    console.log('푸시 알림 권한이 허용되었습니다.');
                } else {
                    console.log('푸시 알림 권한이 거부되었습니다.');
                }
            }
        }
    }

    // Service Worker 설정
    async setupServiceWorker() {
        if ('serviceWorker' in navigator) {
            try {
                const registration = await navigator.serviceWorker.register('/static/sw.js');
                console.log('Service Worker 등록 성공:', registration.scope);
            } catch (error) {
                console.error('Service Worker 등록 실패:', error);
            }
        }
    }
}

// 앱 시작
document.addEventListener('DOMContentLoaded', () => {
    window.smartMoneyTracker = new SmartMoneyTracker();
});

console.log('SmartMoneyTracker 앱이 로드되었습니다.');
