// AI 머니 트래커 - 설정 관리 모듈

class Config {
    constructor() {
        this.settings = this.loadSettings();
        this.apiEndpoint = window.location.origin;
    }

    // 기본 설정
    getDefaultSettings() {
        return {
            dartApiKey: '',
            stockApiKey: '',
            minScore: 5.5,
            pushNotifications: false,
            excludedSectors: [],
            lastUpdated: new Date().toISOString()
        };
    }

    // 설정 로드
    loadSettings() {
        try {
            const saved = localStorage.getItem('smart-money-tracker-settings');
            if (saved) {
                return { ...this.getDefaultSettings(), ...JSON.parse(saved) };
            }
        } catch (error) {
            console.error('설정 로드 실패:', error);
        }
        return this.getDefaultSettings();
    }

    // 설정 저장
    saveSettings(newSettings = {}) {
        try {
            this.settings = { 
                ...this.settings, 
                ...newSettings, 
                lastUpdated: new Date().toISOString() 
            };
            localStorage.setItem('smart-money-tracker-settings', JSON.stringify(this.settings));
            console.log('설정이 저장되었습니다.');
            return true;
        } catch (error) {
            console.error('설정 저장 실패:', error);
            return false;
        }
    }

    // 특정 설정 값 가져오기
    get(key) {
        return this.settings[key];
    }

    // 특정 설정 값 설정하기
    set(key, value) {
        this.settings[key] = value;
        this.saveSettings();
    }

    // API 키 검증
    validateApiKeys() {
        const errors = [];
        
        if (!this.settings.dartApiKey || this.settings.dartApiKey.length < 10) {
            errors.push('DART API 키가 올바르지 않습니다.');
        }
        
        if (!this.settings.stockApiKey || this.settings.stockApiKey.length < 10) {
            errors.push('증권사 API 키가 올바르지 않습니다.');
        }
        
        return {
            isValid: errors.length === 0,
            errors: errors
        };
    }

    // 설정 초기화
    resetSettings() {
        this.settings = this.getDefaultSettings();
        this.saveSettings();
        console.log('설정이 초기화되었습니다.');
    }

    // 설정 내보내기
    exportSettings() {
        const exportData = {
            ...this.settings,
            exportedAt: new Date().toISOString(),
            version: '1.0.0'
        };
        
        // 민감한 API 키는 마스킹
        if (exportData.dartApiKey) {
            exportData.dartApiKey = '***마스킹됨***';
        }
        if (exportData.stockApiKey) {
            exportData.stockApiKey = '***마스킹됨***';
        }
        
        return JSON.stringify(exportData, null, 2);
    }

    // API 엔드포인트 URL 생성
    getApiUrl(endpoint) {
        return `${this.apiEndpoint}/api/v1${endpoint}`;
    }

    // 헤더에 API 키 포함
    getAuthHeaders() {
        return {
            'Content-Type': 'application/json',
            'X-DART-API-KEY': this.settings.dartApiKey,
            'X-STOCK-API-KEY': this.settings.stockApiKey
        };
    }
}

// 전역 config 인스턴스
window.appConfig = new Config();

// 설정 변경 이벤트 
window.addEventListener('storage', (e) => {
    if (e.key === 'smart-money-tracker-settings') {
        window.appConfig.settings = window.appConfig.loadSettings();
        console.log('설정이 다른 탭에서 변경되어 동기화되었습니다.');
    }
});

console.log('Config 모듈이 로드되었습니다.');
