// AI 머니 트래커 - API 통신 모듈

class ApiClient {
    constructor() {
        this.baseUrl = window.location.origin;
        this.wsConnection = null;
        this.reconnectAttempts = 0;
        this.maxReconnectAttempts = 5;
    }

    // HTTP 요청 기본 메서드
    async request(endpoint, options = {}) {
        const url = `${this.baseUrl}${endpoint}`;
        const defaultOptions = {
            headers: {
                'Content-Type': 'application/json',
                ...window.appConfig.getAuthHeaders()
            }
        };

        try {
            const response = await fetch(url, { ...defaultOptions, ...options });
            
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }
            
            const contentType = response.headers.get('content-type');
            if (contentType && contentType.includes('application/json')) {
                return await response.json();
            }
            
            return await response.text();
        } catch (error) {
            console.error(`API 요청 실패 (${endpoint}):`, error);
            throw error;
        }
    }

    // GET 요청
    async get(endpoint) {
        return this.request(endpoint, { method: 'GET' });
    }

    // POST 요청
    async post(endpoint, data) {
        return this.request(endpoint, {
            method: 'POST',
            body: JSON.stringify(data)
        });
    }

    // PUT 요청
    async put(endpoint, data) {
        return this.request(endpoint, {
            method: 'PUT',
            body: JSON.stringify(data)
        });
    }

    // DELETE 요청
    async delete(endpoint) {
        return this.request(endpoint, { method: 'DELETE' });
    }

    // 헬스 체크
    async healthCheck() {
        try {
            const response = await this.get('/health');
            return response.status === 'healthy';
        } catch (error) {
            console.error('헬스 체크 실패:', error);
            return false;
        }
    }

    // 실시간 스캔 상태 조회
    async getScanStatus() {
        try {
            return await this.get('/api/v1/scan/status');
        } catch (error) {
            console.error('스캔 상태 조회 실패:', error);
            return {
                isRunning: false,
                progress: 0,
                lastScanTime: null,
                error: error.message
            };
        }
    }

    // 추천 종목 리스트 조회
    async getRecommendedStocks(filters = {}) {
        try {
            const queryParams = new URLSearchParams();
            
            if (filters.minScore) {
                queryParams.append('min_score', filters.minScore);
            }
            if (filters.sectors) {
                queryParams.append('sectors', filters.sectors.join(','));
            }
            
            const endpoint = `/api/v1/stocks/recommended${queryParams.toString() ? '?' + queryParams.toString() : ''}`;
            return await this.get(endpoint);
        } catch (error) {
            console.error('추천 종목 조회 실패:', error);
            return [];
        }
    }

    // 종목 상세 정보 조회
    async getStockDetail(stockCode) {
        try {
            return await this.get(`/api/v1/stocks/${stockCode}/detail`);
        } catch (error) {
            console.error(`종목 상세 정보 조회 실패 (${stockCode}):`, error);
            return null;
        }
    }

    // 종목 스코어 히스토리 조회
    async getStockScoreHistory(stockCode, days = 30) {
        try {
            return await this.get(`/api/v1/stocks/${stockCode}/score-history?days=${days}`);
        } catch (error) {
            console.error(`스코어 히스토리 조회 실패 (${stockCode}):`, error);
            return [];
        }
    }

    // 알림 히스토리 조회
    async getNotificationHistory(limit = 50) {
        try {
            return await this.get(`/api/v1/notifications/history?limit=${limit}`);
        } catch (error) {
            console.error('알림 히스토리 조회 실패:', error);
            return [];
        }
    }

    // 설정 저장
    async saveSettings(settings) {
        try {
            return await this.post('/api/v1/settings', settings);
        } catch (error) {
            console.error('설정 저장 실패:', error);
            throw error;
        }
    }

    // WebSocket 연결 설정
    connectWebSocket() {
        if (this.wsConnection && this.wsConnection.readyState === WebSocket.OPEN) {
            return; // 이미 연결됨
        }

        const wsUrl = `${window.location.protocol === 'https:' ? 'wss:' : 'ws:'}//${window.location.host}/ws`;
        
        try {
            this.wsConnection = new WebSocket(wsUrl);
            
            this.wsConnection.onopen = () => {
                console.log('WebSocket 연결 성공');
                this.reconnectAttempts = 0;
                this.sendMessage({ type: 'subscribe', channels: ['scan_status', 'stock_updates', 'notifications'] });
            };
            
            this.wsConnection.onmessage = (event) => {
                try {
                    const data = JSON.parse(event.data);
                    this.handleWebSocketMessage(data);
                } catch (error) {
                    console.error('WebSocket 메시지 파싱 오류:', error);
                }
            };
            
            this.wsConnection.onclose = () => {
                console.log('WebSocket 연결 종료');
                this.attemptReconnect();
            };
            
            this.wsConnection.onerror = (error) => {
                console.error('WebSocket 오류:', error);
            };
            
        } catch (error) {
            console.error('WebSocket 연결 실패:', error);
            this.attemptReconnect();
        }
    }

    // WebSocket 메시지 처리
    handleWebSocketMessage(data) {
        const event = new CustomEvent('websocket-message', { detail: data });
        window.dispatchEvent(event);
        
        switch (data.type) {
            case 'scan_status':
                this.handleScanStatusUpdate(data.payload);
                break;
            case 'stock_update':
                this.handleStockUpdate(data.payload);
                break;
            case 'notification':
                this.handleNotification(data.payload);
                break;
            default:
                console.log('알 수 없는 WebSocket 메시지:', data);
        }
    }

    // 스캔 상태 업데이트 처리
    handleScanStatusUpdate(status) {
        const event = new CustomEvent('scan-status-update', { detail: status });
        window.dispatchEvent(event);
    }

    // 종목 업데이트 처리
    handleStockUpdate(stockData) {
        const event = new CustomEvent('stock-update', { detail: stockData });
        window.dispatchEvent(event);
    }

    // 알림 처리
    handleNotification(notification) {
        const event = new CustomEvent('new-notification', { detail: notification });
        window.dispatchEvent(event);
        
        // 브라우저 푸시 알림
        if (window.appConfig.get('pushNotifications') && 'Notification' in window) {
            if (Notification.permission === 'granted') {
                new Notification(notification.title, {
                    body: notification.message,
                    icon: '/static/icons/icon-192x192.png',
                    badge: '/static/icons/icon-72x72.png',
                    tag: notification.id
                });
            }
        }
    }

    // WebSocket 메시지 전송
    sendMessage(message) {
        if (this.wsConnection && this.wsConnection.readyState === WebSocket.OPEN) {
            this.wsConnection.send(JSON.stringify(message));
        } else {
            console.warn('WebSocket이 연결되지 않았습니다.');
        }
    }

    // WebSocket 재연결 시도
    attemptReconnect() {
        if (this.reconnectAttempts < this.maxReconnectAttempts) {
            this.reconnectAttempts++;
            const delay = Math.min(1000 * Math.pow(2, this.reconnectAttempts), 30000); // 지수 백오프
            
            console.log(`${delay}ms 후 WebSocket 재연결 시도... (${this.reconnectAttempts}/${this.maxReconnectAttempts})`);
            
            setTimeout(() => {
                this.connectWebSocket();
            }, delay);
        } else {
            console.error('WebSocket 재연결 최대 시도 횟수에 도달했습니다.');
        }
    }

    // WebSocket 연결 종료
    disconnectWebSocket() {
        if (this.wsConnection) {
            this.wsConnection.close();
            this.wsConnection = null;
        }
    }

    // API 키 테스트
    async testApiKeys() {
        try {
            const results = await this.post('/api/v1/test-api-keys', {
                dartApiKey: window.appConfig.get('dartApiKey'),
                stockApiKey: window.appConfig.get('stockApiKey')
            });
            return results;
        } catch (error) {
            console.error('API 키 테스트 실패:', error);
            return {
                dartApi: { success: false, error: error.message },
                stockApi: { success: false, error: error.message }
            };
        }
    }
}

// 전역 API 클라이언트 인스턴스
window.apiClient = new ApiClient();

// 페이지 로드 시 WebSocket 연결
window.addEventListener('load', () => {
    window.apiClient.connectWebSocket();
});

// 페이지 언로드 시 WebSocket 연결 종료
window.addEventListener('beforeunload', () => {
    window.apiClient.disconnectWebSocket();
});

console.log('API 클라이언트가 로드되었습니다.');
