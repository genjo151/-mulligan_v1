// AI 머니 트래커 - Service Worker

const CACHE_NAME = 'smart-money-tracker-v1.0.0';
const urlsToCache = [
    '/',
    '/static/css/style.css',
    '/static/js/config.js',
    '/static/js/api.js',
    '/static/js/app.js',
    '/static/manifest.json',
    '/static/icons/icon-192x192.png',
    '/static/icons/icon-512x512.png',
    'https://cdn.jsdelivr.net/npm/chart.js'
];

// Service Worker 설치 이벤트
self.addEventListener('install', (event) => {
    console.log('Service Worker: 설치 중...');
    
    event.waitUntil(
        caches.open(CACHE_NAME)
            .then((cache) => {
                console.log('Service Worker: 캐시 생성 및 파일 캐싱');
                return cache.addAll(urlsToCache);
            })
            .then(() => {
                console.log('Service Worker: 설치 완료');
                return self.skipWaiting(); // 즉시 활성화
            })
            .catch((error) => {
                console.error('Service Worker 설치 실패:', error);
            })
    );
});

// Service Worker 활성화 이벤트
self.addEventListener('activate', (event) => {
    console.log('Service Worker: 활성화 중...');
    
    event.waitUntil(
        caches.keys().then((cacheNames) => {
            return Promise.all(
                cacheNames.map((cacheName) => {
                    // 이전 버전 캐시 삭제
                    if (cacheName !== CACHE_NAME) {
                        console.log('Service Worker: 이전 캐시 삭제 -', cacheName);
                        return caches.delete(cacheName);
                    }
                })
            );
        }).then(() => {
            console.log('Service Worker: 활성화 완료');
            return self.clients.claim(); // 모든 클라이언트 제어
        })
    );
});

// 네트워크 요청 가로채기 (Fetch 이벤트)
self.addEventListener('fetch', (event) => {
    // API 요청은 항상 네트워크 우선
    if (event.request.url.includes('/api/') || event.request.url.includes('/health')) {
        event.respondWith(
            fetch(event.request)
                .then((response) => {
                    // API 응답은 캐시하지 않음
                    return response;
                })
                .catch((error) => {
                    console.error('API 요청 실패:', error);
                    // 오프라인 상태에서 기본 응답 반환
                    return new Response(
                        JSON.stringify({ 
                            error: '네트워크 연결이 없습니다.',
                            offline: true 
                        }),
                        {
                            status: 503,
                            statusText: 'Service Unavailable',
                            headers: { 'Content-Type': 'application/json' }
                        }
                    );
                })
        );
        return;
    }
    
    // 정적 파일은 캐시 우선 전략
    event.respondWith(
        caches.match(event.request)
            .then((response) => {
                // 캐시에 있으면 캐시된 버전 반환
                if (response) {
                    return response;
                }
                
                // 캐시에 없으면 네트워크에서 가져오기
                return fetch(event.request)
                    .then((response) => {
                        // 유효한 응답인지 확인
                        if (!response || response.status !== 200 || response.type !== 'basic') {
                            return response;
                        }
                        
                        // 응답 복사 (스트림은 한 번만 사용 가능)
                        const responseToCache = response.clone();
                        
                        // 동적으로 캐시에 추가
                        caches.open(CACHE_NAME)
                            .then((cache) => {
                                cache.put(event.request, responseToCache);
                            });
                        
                        return response;
                    })
                    .catch((error) => {
                        console.error('네트워크 요청 실패:', error);
                        
                        // 오프라인 상태에서 기본 페이지 반환
                        if (event.request.destination === 'document') {
                            return caches.match('/');
                        }
                        
                        throw error;
                    });
            })
    );
});

// 푸시 알림 수신
self.addEventListener('push', (event) => {
    console.log('푸시 알림 수신:', event);
    
    if (event.data) {
        const data = event.data.json();
        const options = {
            body: data.message,
            icon: '/static/icons/icon-192x192.png',
            badge: '/static/icons/icon-72x72.png',
            tag: data.tag || 'stock-alert',
            data: data.data || {},
            actions: [
                {
                    action: 'view',
                    title: '보기',
                    icon: '/static/icons/icon-72x72.png'
                },
                {
                    action: 'dismiss',
                    title: '닫기'
                }
            ],
            requireInteraction: true, // 사용자가 닫을 때까지 유지
            vibrate: [200, 100, 200] // 진동 패턴
        };
        
        event.waitUntil(
            self.registration.showNotification(data.title || 'AI 머니 트래커', options)
        );
    }
});

// 알림 클릭 처리
self.addEventListener('notificationclick', (event) => {
    console.log('알림 클릭:', event);
    
    event.notification.close();
    
    if (event.action === 'view') {
        // 앱 열기 또는 포커스
        event.waitUntil(
            clients.matchAll({ type: 'window' })
                .then((clientList) => {
                    // 이미 열린 창이 있으면 포커스
                    for (const client of clientList) {
                        if (client.url === '/' && 'focus' in client) {
                            return client.focus();
                        }
                    }
                    // 새 창 열기
                    if (clients.openWindow) {
                        return clients.openWindow('/');
                    }
                })
        );
    } else if (event.action === 'dismiss') {
        // 알림만 닫기 (기본 동작)
        return;
    } else {
        // 기본 클릭 (앱 열기)
        event.waitUntil(
            clients.matchAll({ type: 'window' })
                .then((clientList) => {
                    for (const client of clientList) {
                        if (client.url === '/' && 'focus' in client) {
                            return client.focus();
                        }
                    }
                    if (clients.openWindow) {
                        return clients.openWindow('/');
                    }
                })
        );
    }
});

// 백그라운드 동기화 (추후 구현)
self.addEventListener('sync', (event) => {
    console.log('백그라운드 동기화:', event);
    
    if (event.tag === 'background-sync') {
        event.waitUntil(
            // 백그라운드에서 데이터 동기화 작업
            doBackgroundSync()
        );
    }
});

// 백그라운드 동기화 함수
async function doBackgroundSync() {
    try {
        // 캐시된 API 요청 재시도
        // 오프라인 상태에서 실패한 요청들을 다시 시도
        console.log('백그라운드 동기화 시작');
        
        // 실제 구현은 추후 추가
        
        console.log('백그라운드 동기화 완료');
    } catch (error) {
        console.error('백그라운드 동기화 실패:', error);
    }
}

// 메시지 수신 (앱과 통신)
self.addEventListener('message', (event) => {
    console.log('Service Worker 메시지 수신:', event.data);
    
    if (event.data && event.data.type === 'SKIP_WAITING') {
        self.skipWaiting();
    }
    
    // 클라이언트에게 응답
    event.ports[0].postMessage({
        type: 'SW_RESPONSE',
        data: 'Service Worker가 응답했습니다.'
    });
});

console.log('Service Worker 스크립트가 로드되었습니다.');
