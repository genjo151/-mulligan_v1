@echo off
echo ========================================
echo    🎯 AI 머니 트래커 (운영 모드)
echo ========================================
echo.

cd /d "%~dp0"

echo 📦 패키지 설치 확인 중...
python -m pip install -r requirements.txt --quiet

echo.
echo 🔧 데이터베이스 마이그레이션 실행 중...
python -m alembic upgrade head

echo.
echo 🚀 운영 서버 시작 중...
echo 브라우저에서 http://localhost:8018 접속하세요
echo.

python -m uvicorn backend.main:app --host 0.0.0.0 --port 8018 --workers 4

pause
