# AI 머니 트래커 - Pydantic 스키마 모델

from pydantic import BaseModel, Field
from typing import List, Optional, Union, Dict, Any
from datetime import datetime
from datetime import date as datetime_date

class StockInfo(BaseModel):
    """종목 기본 정보"""
    code: str = Field(..., description="종목 코드")
    name: str = Field(..., description="종목명")
    currentPrice: Optional[int] = Field(None, description="현재가")
    changePercent: Optional[float] = Field(None, description="변동률")
    volume: Optional[int] = Field(None, description="거래량")
    sector: Optional[str] = Field(None, description="업종")
    score: float = Field(..., description="세력 감지 스코어", ge=0, le=10)

class StockDetail(StockInfo):
    """종목 상세 정보"""
    marketCap: Optional[int] = Field(None, description="시가총액")
    per: Optional[float] = Field(None, description="PER")
    pbr: Optional[float] = Field(None, description="PBR")
    dividendYield: Optional[float] = Field(None, description="배당수익률")
    
    # 세력 분석 상세
    coreScore: float = Field(..., description="코어 5요소 점수")
    dartScore: float = Field(..., description="DART 6요소 점수")
    lastAnalyzed: datetime = Field(..., description="마지막 분석 시각")

class ScoreHistory(BaseModel):
    """스코어 히스토리"""
    date: datetime = Field(..., description="날짜")
    score: float = Field(..., description="스코어")
    coreScore: float = Field(..., description="코어 점수")
    dartScore: float = Field(..., description="DART 점수")

class ScanStatus(BaseModel):
    """스캔 상태"""
    isRunning: bool = Field(..., description="스캔 실행 중 여부")
    progress: float = Field(..., description="진행률 (0-100)", ge=0, le=100)
    lastScanTime: Optional[datetime] = Field(None, description="마지막 스캔 시각")
    totalStocks: int = Field(default=0, description="전체 종목 수")
    processedStocks: int = Field(default=0, description="처리된 종목 수")
    estimatedTimeRemaining: Optional[int] = Field(None, description="예상 남은 시간 (초)")

class ScanResponse(BaseModel):
    """스캔 응답"""
    message: str = Field(..., description="응답 메시지")
    status: str = Field(..., description="상태")
    scanId: Optional[str] = Field(None, description="스캔 ID")

class UserSettings(BaseModel):
    """사용자 설정"""
    minScore: float = Field(default=5.5, description="최소 알림 스코어", ge=0, le=10)
    pushNotifications: bool = Field(default=False, description="푸시 알림 사용")
    excludedSectors: List[str] = Field(default=[], description="제외할 업종")
    maxNotificationsPerHour: int = Field(default=10, description="시간당 최대 알림 수", ge=1, le=100)
    
class SettingsResponse(BaseModel):
    """설정 응답"""
    message: str = Field(..., description="응답 메시지")
    
class ApiKeyTest(BaseModel):
    """API 키 테스트 요청"""
    dartApiKey: str = Field(..., description="DART API 키")
    stockApiKey: str = Field(..., description="증권사 API 키")

class ApiKeyTestResult(BaseModel):
    """API 키 테스트 결과"""
    success: bool = Field(..., description="성공 여부")
    error: Optional[str] = Field(None, description="오류 메시지")
    lastTested: datetime = Field(default_factory=datetime.now, description="마지막 테스트 시각")

class ApiKeyTestResponse(BaseModel):
    """API 키 테스트 응답"""
    dartApi: ApiKeyTestResult = Field(..., description="DART API 테스트 결과")
    stockApi: ApiKeyTestResult = Field(..., description="증권사 API 테스트 결과")

class NotificationHistory(BaseModel):
    """알림 히스토리"""
    id: str = Field(..., description="알림 ID")
    title: str = Field(..., description="제목")
    message: str = Field(..., description="메시지")
    stockCode: Optional[str] = Field(None, description="관련 종목 코드")
    score: Optional[float] = Field(None, description="당시 스코어")
    createdAt: datetime = Field(..., description="생성 시각")
    clicked: bool = Field(default=False, description="클릭 여부")

class StockFilters(BaseModel):
    """종목 필터"""
    min_score: Optional[float] = Field(None, description="최소 스코어", ge=0, le=10)
    sectors: Optional[str] = Field(None, description="포함할 업종 (쉼표 구분)")
    exclude_sectors: Optional[str] = Field(None, description="제외할 업종 (쉼표 구분)")
    limit: Optional[int] = Field(20, description="최대 결과 수", ge=1, le=100)

class ErrorResponse(BaseModel):
    """에러 응답"""
    detail: str = Field(..., description="에러 상세 메시지")
    error_code: Optional[str] = Field(None, description="에러 코드")
    timestamp: datetime = Field(default_factory=datetime.now, description="에러 발생 시각")

# 증권사 API 연동을 위한 새로운 모델들
class OHLCVData(BaseModel):
    """OHLCV 데이터"""
    date: str = Field(..., description="날짜 (YYYYMMDD)")
    open: int = Field(..., description="시가")
    high: int = Field(..., description="고가")
    low: int = Field(..., description="저가")
    close: int = Field(..., description="종가")
    volume: int = Field(..., description="거래량")
    value: Optional[int] = Field(None, description="거래대금")

class InvestorTradingData(BaseModel):
    """투자자별 매매동향 데이터"""
    date: str = Field(..., description="날짜 (YYYYMMDD)")
    individual_buy: int = Field(..., description="개인 매수")
    individual_sell: int = Field(..., description="개인 매도")
    individual_net: int = Field(..., description="개인 순매수")
    institution_buy: int = Field(..., description="기관 매수")
    institution_sell: int = Field(..., description="기관 매도")
    institution_net: int = Field(..., description="기관 순매수")
    foreign_buy: int = Field(..., description="외국인 매수")
    foreign_sell: int = Field(..., description="외국인 매도")
    foreign_net: int = Field(..., description="외국인 순매수")

class CoreScores(BaseModel):
    """코어 5요소 점수"""
    core1_institution_foreign_60d: float = Field(..., description="기관·외국인 60일 누적 순매수", ge=0, le=1)
    core2_obv_uptrend_60d: float = Field(..., description="OBV 정량 우상향", ge=0, le=1)
    core3_volatility_squeeze: float = Field(..., description="변동성 수축 (BBW)", ge=0, le=1)
    core4_relative_strength: float = Field(..., description="상대강도(RS) 개선", ge=0, le=1)
    core5_accumulation_candles: float = Field(..., description="매집봉 패턴", ge=0, le=1)

class StockRecommendation(BaseModel):
    """종목 추천 정보"""
    stock_code: str = Field(..., description="종목코드")
    stock_name: str = Field(..., description="종목명")
    current_price: int = Field(..., description="현재가")
    total_score: float = Field(..., description="총 점수", ge=0, le=10)
    core_score: float = Field(..., description="코어 5요소 점수", ge=0, le=5)
    dart_score: float = Field(..., description="DART 6요소 점수", ge=0, le=5)
    last_updated: datetime = Field(..., description="마지막 업데이트")
    recommendation_reason: str = Field(..., description="추천 사유")

class StockDetail(BaseModel):
    """종목 상세 정보"""
    stock_code: str = Field(..., description="종목코드")
    stock_name: str = Field(..., description="종목명")
    current_price: int = Field(..., description="현재가")
    total_score: float = Field(..., description="총 점수", ge=0, le=10)
    core_score: float = Field(..., description="코어 5요소 점수", ge=0, le=5)
    dart_score: float = Field(..., description="DART 6요소 점수", ge=0, le=5)
    price_change: int = Field(..., description="전일 대비 변동")
    price_change_rate: float = Field(..., description="전일 대비 변동률 (%)")
    volume: int = Field(..., description="거래량")
    market_cap: Optional[int] = Field(None, description="시가총액")
    sector: Optional[str] = Field(None, description="업종")
    core_scores: CoreScores = Field(..., description="코어 5요소 상세 점수")
    recent_ohlcv: List[OHLCVData] = Field(..., description="최근 OHLCV 데이터")
    last_updated: datetime = Field(..., description="마지막 업데이트")

class StockScoreHistory(BaseModel):
    """종목 점수 히스토리"""
    date: datetime_date = Field(..., description="날짜")
    total_score: float = Field(..., description="총 점수", ge=0, le=10)
    core_score: float = Field(..., description="코어 점수", ge=0, le=5)
    dart_score: float = Field(..., description="DART 점수", ge=0, le=5)
    price: int = Field(..., description="해당일 종가")

class StockAnalysisResult(BaseModel):
    """종목 분석 결과"""
    stock_code: str = Field(..., description="종목코드")
    analysis_timestamp: datetime = Field(..., description="분석 시각")
    core_scores: CoreScores = Field(..., description="코어 5요소 점수")
    total_core_score: float = Field(..., description="코어 총점", ge=0, le=5)
    ohlcv_data: List[OHLCVData] = Field(..., description="OHLCV 데이터")
    investor_data: List[InvestorTradingData] = Field(..., description="투자자별 매매동향")
    analysis_summary: str = Field(..., description="분석 요약")
    recommendations: List[str] = Field(..., description="투자 추천사항")

class ApiResponse(BaseModel):
    """공통 API 응답"""
    success: bool = Field(..., description="성공 여부")
    message: str = Field(..., description="응답 메시지")
    data: Optional[Dict[str, Any]] = Field(None, description="응답 데이터")
