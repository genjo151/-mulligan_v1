# AI 머니 트래커 - 증권사 API 클라이언트 및 코어 5요소 계산

import aiohttp
import asyncio
from typing import List, Dict, Optional, Tuple
from datetime import datetime, timedelta
import json
import statistics
from loguru import logger

class StockApiClient:
    """증권사 API 클라이언트"""
    
    def __init__(self, api_key: str, base_url: str = "https://openapi.koreainvestment.com"):
        """
        초기화
        
        Args:
            api_key: 증권사 API 키
            base_url: API 기본 URL
        """
        self.api_key = api_key
        self.base_url = base_url
        self.headers = {
            "Content-Type": "application/json",
            "authorization": f"Bearer {api_key}",
            "tr_id": "",  # 각 요청마다 다른 tr_id 설정
        }
    
    async def fetch_ohlcv_data(self, stock_code: str, period: int = 60) -> List[Dict]:
        """
        일봉 OHLCV 데이터 조회
        
        Args:
            stock_code: 종목코드 (예: "005930")
            period: 조회 기간 (일수)
        
        Returns:
            OHLCV 데이터 리스트
        """
        try:
            # 실제 API가 없으므로 테스트 데이터 반환
            logger.info(f"증권사 API OHLCV 데이터 조회: {stock_code}, 기간: {period}일")
            
            # 실제 구현에서는 아래 코드 사용
            # endpoint = f"/uapi/domestic-stock/v1/quotations/inquire-daily-price"
            # params = {
            #     "fid_cond_mrkt_div_code": "J",
            #     "fid_input_iscd": stock_code,
            #     "fid_period_div_code": "D",
            #     "fid_org_adj_prc": "1"
            # }
            # async with aiohttp.ClientSession() as session:
            #     async with session.get(
            #         f"{self.base_url}{endpoint}",
            #         headers=self.headers,
            #         params=params
            #     ) as response:
            #         data = await response.json()
            #         return self._parse_ohlcv_data(data)
            
            # 테스트용 가상 데이터
            test_data = []
            base_price = 75000
            base_volume = 10000000
            
            for i in range(period):
                date_obj = datetime.now() - timedelta(days=i)
                date_str = date_obj.strftime("%Y%m%d")
                
                # 랜덤한 가격 변동 시뮬레이션
                price_change = (i % 10 - 5) * 100  # -500 ~ +400 범위
                open_price = base_price + price_change
                high_price = open_price + abs(i % 5) * 200
                low_price = open_price - abs(i % 3) * 150
                close_price = open_price + (i % 7 - 3) * 100
                volume = base_volume + (i % 5) * 2000000
                
                # 가격 논리 검증
                high_price = max(high_price, open_price, close_price)
                low_price = min(low_price, open_price, close_price)
                
                test_data.append({
                    "date": date_str,
                    "open": int(open_price),
                    "high": int(high_price),
                    "low": int(low_price),
                    "close": int(close_price),
                    "volume": int(volume),
                    "value": int(volume * close_price)  # 거래대금
                })
            
            # 최신 날짜부터 내림차순으로 정렬
            test_data.sort(key=lambda x: x["date"], reverse=True)
            
            logger.info(f"OHLCV 데이터 조회 완료: {len(test_data)}건")
            return test_data
            
        except Exception as e:
            logger.error(f"OHLCV 데이터 조회 실패: {e}")
            raise
    
    async def fetch_investor_trading_data(self, stock_code: str, period: int = 60) -> List[Dict]:
        """
        투자자별 매매동향 조회
        
        Args:
            stock_code: 종목코드
            period: 조회 기간 (일수)
        
        Returns:
            투자자별 매매동향 데이터 리스트
        """
        try:
            logger.info(f"투자자별 매매동향 조회: {stock_code}, 기간: {period}일")
            
            # 테스트용 가상 데이터
            test_data = []
            
            for i in range(period):
                date_obj = datetime.now() - timedelta(days=i)
                date_str = date_obj.strftime("%Y%m%d")
                
                # 가상의 매매동향 데이터
                individual_buy = 500000000 + (i % 10) * 50000000
                individual_sell = 450000000 + (i % 8) * 60000000
                individual_net = individual_buy - individual_sell
                
                institution_buy = 300000000 + (i % 7) * 40000000
                institution_sell = 280000000 + (i % 6) * 35000000
                institution_net = institution_buy - institution_sell
                
                foreign_buy = 200000000 + (i % 5) * 30000000
                foreign_sell = 250000000 + (i % 9) * 25000000
                foreign_net = foreign_buy - foreign_sell
                
                test_data.append({
                    "date": date_str,
                    "individual_buy": individual_buy,
                    "individual_sell": individual_sell,
                    "individual_net": individual_net,
                    "institution_buy": institution_buy,
                    "institution_sell": institution_sell,
                    "institution_net": institution_net,
                    "foreign_buy": foreign_buy,
                    "foreign_sell": foreign_sell,
                    "foreign_net": foreign_net
                })
            
            test_data.sort(key=lambda x: x["date"], reverse=True)
            
            logger.info(f"투자자별 매매동향 조회 완료: {len(test_data)}건")
            return test_data
            
        except Exception as e:
            logger.error(f"투자자별 매매동향 조회 실패: {e}")
            raise
    
    async def fetch_benchmark_data(self, index_code: str = "KS11", period: int = 60) -> List[Dict]:
        """
        벤치마크 지수 데이터 조회 (KOSPI)
        
        Args:
            index_code: 지수 코드 (KS11: KOSPI, KQ11: KOSDAQ)
            period: 조회 기간
        
        Returns:
            지수 데이터 리스트
        """
        try:
            logger.info(f"벤치마크 지수 데이터 조회: {index_code}, 기간: {period}일")
            
            # 테스트용 가상 벤치마크 데이터
            test_data = []
            base_index = 2500.0
            
            for i in range(period):
                date_obj = datetime.now() - timedelta(days=i)
                date_str = date_obj.strftime("%Y%m%d")
                
                # 지수 변동 시뮬레이션
                index_change = (i % 20 - 10) * 0.5  # -5.0 ~ +4.5 범위
                close_index = base_index + index_change
                
                test_data.append({
                    "date": date_str,
                    "close": round(close_index, 2)
                })
            
            test_data.sort(key=lambda x: x["date"], reverse=True)
            
            logger.info(f"벤치마크 데이터 조회 완료: {len(test_data)}건")
            return test_data
            
        except Exception as e:
            logger.error(f"벤치마크 데이터 조회 실패: {e}")
            raise
    
    async def test_connection(self) -> Tuple[bool, str]:
        """
        API 연결 테스트
        
        Returns:
            (성공 여부, 메시지)
        """
        try:
            # 실제 구현에서는 API 상태 확인 엔드포인트 호출
            logger.info("증권사 API 연결 테스트 시작")
            
            # 가상의 연결 테스트
            await asyncio.sleep(0.1)  # 네트워크 지연 시뮬레이션
            
            if len(self.api_key) >= 10:
                logger.info("증권사 API 연결 테스트 성공")
                return True, "연결 성공"
            else:
                logger.warning("증권사 API 키가 유효하지 않음")
                return False, "유효하지 않은 API 키"
                
        except Exception as e:
            logger.error(f"증권사 API 연결 테스트 실패: {e}")
            return False, f"연결 실패: {str(e)}"


class CoreElementsCalculator:
    """PRD 코어 5요소 계산기"""
    
    @staticmethod
    def calculate_all_scores(ohlcv_data: List[Dict], investor_data: List[Dict], 
                           benchmark_data: List[Dict]) -> Dict[str, float]:
        """
        모든 코어 요소 점수 계산
        
        Args:
            ohlcv_data: OHLCV 데이터
            investor_data: 투자자별 매매동향 데이터
            benchmark_data: 벤치마크 데이터
        
        Returns:
            코어 요소별 점수 딕셔너리
        """
        logger.info("코어 5요소 점수 계산 시작")
        
        scores = {
            "core1_institution_foreign_60d": 0.0,  # 기관·외국인 60일 누적 순매수
            "core2_obv_uptrend_60d": 0.0,          # OBV 정량 우상향
            "core3_volatility_squeeze": 0.0,        # 변동성 수축 (BBW)
            "core4_relative_strength": 0.0,         # 상대강도(RS) 개선
            "core5_accumulation_candles": 0.0       # 매집봉 패턴
        }
        
        try:
            # 코어-1: 기관·외국인 60일 누적 순매수
            scores["core1_institution_foreign_60d"] = CoreElementsCalculator._calculate_core1(
                investor_data, ohlcv_data
            )
            
            # 코어-2: OBV 정량 우상향
            scores["core2_obv_uptrend_60d"] = CoreElementsCalculator._calculate_core2(
                ohlcv_data
            )
            
            # 코어-3: 변동성 수축 (BBW)
            scores["core3_volatility_squeeze"] = CoreElementsCalculator._calculate_core3(
                ohlcv_data
            )
            
            # 코어-4: 상대강도(RS) 개선
            scores["core4_relative_strength"] = CoreElementsCalculator._calculate_core4(
                ohlcv_data, benchmark_data
            )
            
            # 코어-5: 매집봉 패턴
            scores["core5_accumulation_candles"] = CoreElementsCalculator._calculate_core5(
                ohlcv_data
            )
            
            logger.info(f"코어 5요소 점수 계산 완료: {scores}")
            return scores
            
        except Exception as e:
            logger.error(f"코어 요소 점수 계산 실패: {e}")
            return scores
    
    @staticmethod
    def _calculate_core1(investor_data: List[Dict], ohlcv_data: List[Dict]) -> float:
        """코어-1: 기관·외국인 60일 누적 순매수"""
        try:
            if len(investor_data) < 60 or len(ohlcv_data) < 20:
                return 0.0
            
            # 60일 누적 순매수 계산
            total_net_buy = 0
            for data in investor_data[:60]:  # 최신 60일
                institution_net = data.get("institution_net", 0)
                foreign_net = data.get("foreign_net", 0)
                total_net_buy += (institution_net + foreign_net)
            
            # ADV_20 계산 (최근 20일 평균 거래대금)
            adv_20 = 0
            for data in ohlcv_data[:20]:  # 최신 20일
                adv_20 += data.get("value", 0)
            adv_20 = adv_20 / 20 if adv_20 > 0 else 1
            
            # NetBuy_60_norm 계산
            netbuy_60_norm = total_net_buy / (adv_20 * 20) if adv_20 > 0 else 0
            
            # 점수 계산: NetBuy_60_norm >= 1.0이면 1.0점
            score = min(1.0, max(0.0, netbuy_60_norm)) if netbuy_60_norm >= 1.0 else 0.0
            
            logger.debug(f"코어-1 계산: NetBuy_60={total_net_buy}, ADV_20={adv_20}, Score={score}")
            return score
            
        except Exception as e:
            logger.error(f"코어-1 계산 실패: {e}")
            return 0.0
    
    @staticmethod
    def _calculate_core2(ohlcv_data: List[Dict]) -> float:
        """코어-2: OBV 정량 우상향"""
        try:
            if len(ohlcv_data) < 60:
                return 0.0
            
            # OBV 계산
            obv_values = []
            obv = 0
            
            # 역순으로 정렬된 데이터를 시간순으로 처리
            reversed_data = list(reversed(ohlcv_data))
            
            for i, data in enumerate(reversed_data):
                if i > 0:
                    prev_close = reversed_data[i-1]["close"]
                    curr_close = data["close"]
                    volume = data["volume"]
                    
                    if curr_close > prev_close:
                        obv += volume
                    elif curr_close < prev_close:
                        obv -= volume
                
                obv_values.append(obv)
            
            if len(obv_values) < 60:
                return 0.0
            
            # 60일 기간을 3등분하여 기울기 계산
            period1 = obv_values[:20]  # 첫 20일
            period2 = obv_values[20:40]  # 중간 20일
            period3 = obv_values[40:60]  # 마지막 20일
            
            avg1 = statistics.mean(period1)
            avg2 = statistics.mean(period2)
            avg3 = statistics.mean(period3)
            
            # 우상향 조건: avg3 > avg2 > avg1
            if avg3 > avg2 > avg1:
                score = 1.0
            else:
                score = 0.0
            
            logger.debug(f"코어-2 계산: OBV 평균값 {avg1:.0f} -> {avg2:.0f} -> {avg3:.0f}, Score={score}")
            return score
            
        except Exception as e:
            logger.error(f"코어-2 계산 실패: {e}")
            return 0.0
    
    @staticmethod
    def _calculate_core3(ohlcv_data: List[Dict]) -> float:
        """코어-3: 변동성 수축 (BBW)"""
        try:
            if len(ohlcv_data) < 40:  # 20일 + 여유분
                return 0.0
            
            # 최근 20일 종가 추출
            recent_closes = [data["close"] for data in ohlcv_data[:20]]
            
            # 볼린저밴드 계산
            ma = statistics.mean(recent_closes)
            std_dev = statistics.stdev(recent_closes) if len(recent_closes) > 1 else 0
            
            if ma == 0:
                return 0.0
            
            # BBW (Bollinger Band Width) 계산
            bbw = (2 * 2 * std_dev) / ma  # 2σ 볼린저밴드
            
            # BBW < 0.1 (10%)이면 변동성 수축으로 판정
            if bbw < 0.1:
                score = 1.0
            else:
                score = 0.0
            
            logger.debug(f"코어-3 계산: BBW={bbw:.4f}, Score={score}")
            return score
            
        except Exception as e:
            logger.error(f"코어-3 계산 실패: {e}")
            return 0.0
    
    @staticmethod
    def _calculate_core4(ohlcv_data: List[Dict], benchmark_data: List[Dict]) -> float:
        """코어-4: 상대강도(RS) 개선"""
        try:
            if len(ohlcv_data) < 20 or len(benchmark_data) < 20:
                return 0.0
            
            # 20일 수익률 계산
            stock_price_start = ohlcv_data[19]["close"]  # 20일 전
            stock_price_end = ohlcv_data[0]["close"]     # 현재
            
            benchmark_start = benchmark_data[19]["close"]  # 20일 전
            benchmark_end = benchmark_data[0]["close"]     # 현재
            
            stock_return = (stock_price_end - stock_price_start) / stock_price_start
            benchmark_return = (benchmark_end - benchmark_start) / benchmark_start
            
            # 상대강도 계산
            relative_strength = stock_return - benchmark_return
            
            # 상대강도가 양수면 1.0점
            score = 1.0 if relative_strength > 0 else 0.0
            
            logger.debug(f"코어-4 계산: 주식수익률={stock_return:.4f}, 벤치마크수익률={benchmark_return:.4f}, RS={relative_strength:.4f}, Score={score}")
            return score
            
        except Exception as e:
            logger.error(f"코어-4 계산 실패: {e}")
            return 0.0
    
    @staticmethod
    def _calculate_core5(ohlcv_data: List[Dict]) -> float:
        """코어-5: 매집봉 패턴"""
        try:
            if len(ohlcv_data) < 60:
                return 0.0
            
            accumulation_count = 0
            total_volume = sum(data["volume"] for data in ohlcv_data[:60])
            avg_volume = total_volume / 60
            
            for data in ohlcv_data[:60]:  # 최근 60일
                open_price = data["open"]
                high_price = data["high"]
                low_price = data["low"]
                close_price = data["close"]
                volume = data["volume"]
                
                # 캔들 전체 길이
                candle_total = high_price - low_price
                
                if candle_total == 0:
                    continue
                
                # 윗꼬리 길이
                upper_shadow = high_price - max(open_price, close_price)
                
                # 윗꼬리 비율 계산
                upper_shadow_ratio = upper_shadow / candle_total
                
                # 매집봉 조건: 윗꼬리 60% 이상 + 평균 거래량 이상
                if upper_shadow_ratio >= 0.6 and volume >= avg_volume:
                    accumulation_count += 1
            
            # 60일 중 3개 이상의 매집봉이 있으면 1.0점
            score = 1.0 if accumulation_count >= 3 else 0.0
            
            logger.debug(f"코어-5 계산: 매집봉 개수={accumulation_count}, Score={score}")
            return score
            
        except Exception as e:
            logger.error(f"코어-5 계산 실패: {e}")
            return 0.0


class StockDataProcessor:
    """주식 데이터 처리 및 통합 클래스"""
    
    def __init__(self, api_client: StockApiClient):
        """
        초기화
        
        Args:
            api_client: 증권사 API 클라이언트
        """
        self.api_client = api_client
        self.calculator = CoreElementsCalculator()
    
    async def get_complete_stock_analysis(self, stock_code: str) -> Dict:
        """
        종목의 완전한 분석 데이터 조회
        
        Args:
            stock_code: 종목코드
        
        Returns:
            통합 분석 결과
        """
        try:
            logger.info(f"종목 완전 분석 시작: {stock_code}")
            
            # 모든 데이터를 병렬로 조회
            tasks = [
                self.api_client.fetch_ohlcv_data(stock_code, 60),
                self.api_client.fetch_investor_trading_data(stock_code, 60),
                self.api_client.fetch_benchmark_data("KS11", 60)
            ]
            
            ohlcv_data, investor_data, benchmark_data = await asyncio.gather(*tasks)
            
            # 코어 5요소 점수 계산
            core_scores = self.calculator.calculate_all_scores(
                ohlcv_data, investor_data, benchmark_data
            )
            
            # 총 점수 계산 (각 코어 요소는 최대 1.0점)
            total_core_score = sum(core_scores.values())
            
            result = {
                "stock_code": stock_code,
                "analysis_timestamp": datetime.now().isoformat(),
                "ohlcv_data": ohlcv_data[:10],  # 최근 10일만 반환
                "investor_data": investor_data[:10],
                "benchmark_data": benchmark_data[:10],
                "core_scores": core_scores,
                "total_core_score": total_core_score,
                "max_possible_score": 5.0,
                "data_counts": {
                    "ohlcv_count": len(ohlcv_data),
                    "investor_count": len(investor_data),
                    "benchmark_count": len(benchmark_data)
                }
            }
            
            logger.info(f"종목 완전 분석 완료: {stock_code}, 총점: {total_core_score}/5.0")
            return result
            
        except Exception as e:
            logger.error(f"종목 완전 분석 실패: {stock_code}, 오류: {e}")
            raise


# 테스트용 독립 실행 함수
def run_standalone_test():
    """독립적으로 실행 가능한 테스트"""
    import asyncio
    
    async def test_core():
        from backend.services.stock_api import CoreElementsCalculator
        
        # 테스트 OHLCV 데이터
        ohlcv_data = [
            {"date": "20241201", "open": 75000, "high": 76500, "low": 74500, "close": 76000, "volume": 15000000, "value": 1140000000000},
            {"date": "20241130", "open": 74500, "high": 75200, "low": 74000, "close": 75000, "volume": 12000000, "value": 900000000000}
        ] * 30  # 60일 데이터 시뮬레이션
        
        # 테스트 투자자 데이터
        investor_data = [
            {"date": "20241201", "institution_net": 50000000, "foreign_net": 20000000}
        ] * 60
        
        # 테스트 벤치마크 데이터  
        benchmark_data = [
            {"date": "20241201", "close": 2500.50}
        ] * 60
        
        # 코어 점수 계산
        calculator = CoreElementsCalculator()
        scores = calculator.calculate_all_scores(ohlcv_data, investor_data, benchmark_data)
        
        print(f"✅ 코어 5요소 계산 성공: {scores}")
        print(f"✅ 총점: {sum(scores.values())}/5.0")
        return scores
    
    return asyncio.run(test_core())

# 테스트용 함수들
async def test_stock_api_functionality():
    """증권사 API 기능 테스트"""
    logger.info("증권사 API 기능 테스트 시작")
    
    # 테스트 API 키로 클라이언트 생성
    test_api_key = "TEST_STOCK_API_KEY_1234567890"
    client = StockApiClient(test_api_key)
    
    try:
        # 연결 테스트
        is_connected, message = await client.test_connection()
        logger.info(f"연결 테스트: {is_connected}, {message}")
        
        # 데이터 조회 테스트
        processor = StockDataProcessor(client)
        result = await processor.get_complete_stock_analysis("005930")
        
        logger.info(f"테스트 결과: 총점 {result['total_core_score']}/5.0")
        logger.info("증권사 API 기능 테스트 완료")
        
        return result
        
    except Exception as e:
        logger.error(f"증권사 API 테스트 실패: {e}")
        raise


if __name__ == "__main__":
    # 비동기 테스트 실행
    asyncio.run(test_stock_api_functionality())
