# AI 머니 트래커 - 데이터 무결성 검증 시스템

import asyncio
from datetime import datetime, date, timedelta
from typing import List, Dict, Any, Optional, Set, Tuple
from loguru import logger
from dataclasses import dataclass
from enum import Enum

from backend.database.base import get_db_session
from backend.database.repositories import (
    DailyPriceRepository, InvestorTradingRepository, DartDisclosureRepository
)


class ValidationSeverity(Enum):
    """검증 결과 심각도"""
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    CRITICAL = "critical"


@dataclass
class ValidationResult:
    """검증 결과"""
    is_valid: bool
    severity: ValidationSeverity
    message: str
    details: Optional[Dict[str, Any]] = None


@dataclass
class IntegrityReport:
    """무결성 검사 보고서"""
    timestamp: datetime
    overall_status: str
    data_types: Dict[str, Dict[str, Any]]
    alerts: List[Dict[str, Any]]
    recommendations: List[str]
    statistics: Dict[str, Any]


class DataIntegrityValidator:
    """데이터 무결성 검증기"""
    
    def __init__(self):
        """검증기 초기화"""
        self.validation_rules = {
            "ohlcv": ["price_consistency", "volume_positive", "date_sequence", "trading_value_calc"],
            "investor_trading": ["volume_sum_consistency", "amount_calculation", "net_balance", "investor_type_valid"],
            "dart": ["rcept_no_format", "date_format", "corp_code_format", "report_type_valid"]
        }
        
        self.tolerance = {
            "price_variance": 0.1,  # 10% 가격 변동 허용
            "volume_variance": 0.05,  # 5% 거래량 변동 허용
            "amount_precision": 1000,  # 1000원 단위 허용
            "completeness_threshold": 0.95  # 95% 완전성 기준
        }
        
        self.duplicate_keys = {
            "ohlcv": ["stock_code", "date"],
            "investor_trading": ["stock_code", "date", "investor_type"],
            "dart": ["rcept_no"]
        }
        
        logger.info("데이터 무결성 검증기 초기화 완료")
    
    def validate_ohlcv_data(self, data: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        OHLCV 데이터 검증
        
        Args:
            data: OHLCV 데이터 리스트
            
        Returns:
            검증 결과
        """
        validation_result = {
            "is_valid": True,
            "errors": [],
            "warnings": [],
            "statistics": {
                "total_records": len(data),
                "valid_records": 0,
                "invalid_records": 0
            }
        }
        
        for i, record in enumerate(data):
            record_errors = []
            record_warnings = []
            
            # 1. 필수 필드 검증
            required_fields = ["stock_code", "date", "open", "high", "low", "close", "volume"]
            for field in required_fields:
                if field not in record or record[field] is None:
                    record_errors.append(f"레코드 {i}: 필수 필드 '{field}' 누락")
            
            # 2. 가격 일관성 검증
            if all(field in record for field in ["open", "high", "low", "close"]):
                high, low, open_price, close = record["high"], record["low"], record["open"], record["close"]
                
                if high < low:
                    record_errors.append(f"레코드 {i}: 고가({high})가 저가({low})보다 낮음")
                if high < max(open_price, close):
                    record_errors.append(f"레코드 {i}: 고가({high})가 시가/종가보다 낮음")
                if low > min(open_price, close):
                    record_errors.append(f"레코드 {i}: 저가({low})가 시가/종가보다 높음")
                
                # 이상한 가격 변동 감지
                price_change = abs(close - open_price) / open_price if open_price > 0 else 0
                if price_change > 0.3:  # 30% 이상 변동
                    record_warnings.append(f"레코드 {i}: 큰 가격 변동 감지 ({price_change:.1%})")
            
            # 3. 양수 검증
            for field in ["volume", "trading_value"]:
                if field in record and record[field] is not None:
                    if record[field] < 0:
                        record_errors.append(f"레코드 {i}: {field}가 음수값({record[field]})")
                    elif record[field] == 0:
                        record_warnings.append(f"레코드 {i}: {field}가 0값")
            
            # 4. 거래대금 계산 검증
            if all(field in record for field in ["close", "volume", "trading_value"]):
                expected_value = record["close"] * record["volume"]
                actual_value = record["trading_value"]
                if expected_value > 0:
                    variance = abs(expected_value - actual_value) / expected_value
                    if variance > 0.1:  # 10% 이상 차이
                        record_warnings.append(
                            f"레코드 {i}: 거래대금 계산 불일치 (예상: {expected_value:,.0f}, 실제: {actual_value:,.0f})"
                        )
            
            # 5. 날짜 형식 검증
            if "date" in record:
                if not isinstance(record["date"], date):
                    record_errors.append(f"레코드 {i}: 날짜 형식이 올바르지 않음")
                else:
                    # 미래 날짜 검증
                    if record["date"] > date.today():
                        record_warnings.append(f"레코드 {i}: 미래 날짜 데이터 ({record['date']})")
            
            # 결과 집계
            validation_result["errors"].extend(record_errors)
            validation_result["warnings"].extend(record_warnings)
            
            if record_errors:
                validation_result["statistics"]["invalid_records"] += 1
                validation_result["is_valid"] = False
            else:
                validation_result["statistics"]["valid_records"] += 1
        
        return validation_result
    
    def validate_investor_trading_data(self, data: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        투자자별 매매동향 데이터 검증
        
        Args:
            data: 투자자별 매매동향 데이터 리스트
            
        Returns:
            검증 결과
        """
        validation_result = {
            "is_valid": True,
            "errors": [],
            "warnings": [],
            "statistics": {
                "total_records": len(data),
                "valid_records": 0,
                "invalid_records": 0
            }
        }
        
        valid_investor_types = ["individual", "institution", "foreign", "etc"]
        
        for i, record in enumerate(data):
            record_errors = []
            record_warnings = []
            
            # 1. 필수 필드 검증
            required_fields = ["stock_code", "date", "investor_type", "buy_volume", "sell_volume", "net_volume"]
            for field in required_fields:
                if field not in record or record[field] is None:
                    record_errors.append(f"레코드 {i}: 필수 필드 '{field}' 누락")
            
            # 2. 순매수량 계산 검증
            if all(field in record for field in ["buy_volume", "sell_volume", "net_volume"]):
                expected_net = record["buy_volume"] - record["sell_volume"]
                actual_net = record["net_volume"]
                
                if expected_net != actual_net:
                    record_errors.append(
                        f"레코드 {i}: 순매수량 계산 오류 (예상: {expected_net:,}, 실제: {actual_net:,})"
                    )
            
            # 3. 순매수금액 계산 검증
            if all(field in record for field in ["buy_amount", "sell_amount", "net_amount"]):
                expected_net_amount = record["buy_amount"] - record["sell_amount"]
                actual_net_amount = record["net_amount"]
                
                if abs(expected_net_amount - actual_net_amount) > self.tolerance["amount_precision"]:
                    record_errors.append(
                        f"레코드 {i}: 순매수금액 계산 오류 (예상: {expected_net_amount:,}, 실제: {actual_net_amount:,})"
                    )
            
            # 4. 투자자 유형 검증
            if "investor_type" in record:
                if record["investor_type"] not in valid_investor_types:
                    record_errors.append(f"레코드 {i}: 유효하지 않은 투자자 유형 '{record['investor_type']}'")
            
            # 5. 양수 검증 (매수/매도량, 매수/매도금액)
            for field in ["buy_volume", "sell_volume", "buy_amount", "sell_amount"]:
                if field in record and record[field] is not None:
                    if record[field] < 0:
                        record_errors.append(f"레코드 {i}: {field}가 음수값({record[field]:,})")
            
            # 6. 비정상적인 거래량 감지
            if "buy_volume" in record and "sell_volume" in record:
                total_volume = record["buy_volume"] + record["sell_volume"]
                if total_volume > 100000000:  # 1억주 이상
                    record_warnings.append(f"레코드 {i}: 비정상적으로 큰 거래량 ({total_volume:,}주)")
            
            # 결과 집계
            validation_result["errors"].extend(record_errors)
            validation_result["warnings"].extend(record_warnings)
            
            if record_errors:
                validation_result["statistics"]["invalid_records"] += 1
                validation_result["is_valid"] = False
            else:
                validation_result["statistics"]["valid_records"] += 1
        
        return validation_result
    
    def validate_dart_data(self, data: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        DART 공시 데이터 검증
        
        Args:
            data: DART 공시 데이터 리스트
            
        Returns:
            검증 결과
        """
        validation_result = {
            "is_valid": True,
            "errors": [],
            "warnings": [],
            "statistics": {
                "total_records": len(data),
                "valid_records": 0,
                "invalid_records": 0
            }
        }
        
        valid_reports = ["대량보유상황보고서", "주요사항보고서", "임원·주요주주특정증권등소유상황보고서"]
        
        for i, record in enumerate(data):
            record_errors = []
            record_warnings = []
            
            # 1. 필수 필드 검증
            required_fields = ["rcept_no", "corp_name", "corp_code", "stock_code", "report_nm", "rcept_dt"]
            for field in required_fields:
                if field not in record or record[field] is None:
                    record_errors.append(f"레코드 {i}: 필수 필드 '{field}' 누락")
            
            # 2. 접수번호 형식 검증
            if "rcept_no" in record:
                rcept_no = str(record["rcept_no"])
                if not (rcept_no.isdigit() and len(rcept_no) >= 14):
                    record_errors.append(f"레코드 {i}: 접수번호 형식 오류 '{rcept_no}'")
            
            # 3. 법인코드 형식 검증
            if "corp_code" in record:
                corp_code = str(record["corp_code"])
                if not (corp_code.isdigit() and len(corp_code) == 8):
                    record_errors.append(f"레코드 {i}: 법인코드 형식 오류 '{corp_code}'")
            
            # 4. 종목코드 형식 검증
            if "stock_code" in record:
                stock_code = str(record["stock_code"])
                if not (stock_code.isdigit() and len(stock_code) == 6):
                    record_errors.append(f"레코드 {i}: 종목코드 형식 오류 '{stock_code}'")
            
            # 5. 날짜 형식 검증
            if "rcept_dt" in record:
                if not isinstance(record["rcept_dt"], date):
                    record_errors.append(f"레코드 {i}: 접수일자 형식이 올바르지 않음")
                else:
                    # 너무 오래된 데이터 또는 미래 데이터 검증
                    if record["rcept_dt"] > date.today():
                        record_warnings.append(f"레코드 {i}: 미래 날짜 공시 ({record['rcept_dt']})")
                    elif record["rcept_dt"] < date.today() - timedelta(days=365):
                        record_warnings.append(f"레코드 {i}: 1년 이상 오래된 공시 ({record['rcept_dt']})")
            
            # 6. 보고서명 검증
            if "report_nm" in record:
                report_nm = record["report_nm"]
                is_valid_report = any(valid_report in report_nm for valid_report in valid_reports)
                
                if not is_valid_report:
                    record_warnings.append(f"레코드 {i}: 알 수 없는 보고서 유형 '{report_nm}'")
            
            # 결과 집계
            validation_result["errors"].extend(record_errors)
            validation_result["warnings"].extend(record_warnings)
            
            if record_errors:
                validation_result["statistics"]["invalid_records"] += 1
                validation_result["is_valid"] = False
            else:
                validation_result["statistics"]["valid_records"] += 1
        
        return validation_result
    
    def detect_duplicates(self, data: List[Dict[str, Any]], key_fields: List[str]) -> Dict[str, Any]:
        """
        중복 데이터 감지
        
        Args:
            data: 검사할 데이터 리스트
            key_fields: 중복 검사 키 필드들
            
        Returns:
            중복 감지 결과
        """
        seen_keys: Set[Tuple] = set()
        duplicates = []
        unique_data = []
        
        for i, record in enumerate(data):
            # 키 필드로 고유 키 생성
            key_values = tuple(record.get(field) for field in key_fields)
            
            if key_values in seen_keys:
                duplicates.append({
                    "index": i,
                    "key": dict(zip(key_fields, key_values)),
                    "record": record
                })
            else:
                seen_keys.add(key_values)
                unique_data.append(record)
        
        return {
            "has_duplicates": len(duplicates) > 0,
            "duplicate_count": len(duplicates),
            "duplicates": duplicates,
            "unique_data": unique_data,
            "unique_count": len(unique_data),
            "duplicate_rate": len(duplicates) / len(data) if data else 0
        }
    
    def check_data_completeness(
        self,
        stock_codes: List[str],
        date_range: int,
        actual_data: Dict[str, List[Dict[str, Any]]]
    ) -> Dict[str, Any]:
        """
        데이터 완전성 검사
        
        Args:
            stock_codes: 확인할 종목 코드 리스트
            date_range: 확인할 날짜 범위 (일)
            actual_data: 실제 데이터 {"ohlcv": [...], "investor_trading": [...]}
            
        Returns:
            완전성 검사 결과
        """
        # 기대되는 영업일 계산 (간단한 버전 - 주말만 제외)
        end_date = date.today()
        start_date = end_date - timedelta(days=date_range)
        
        expected_dates = []
        current_date = start_date
        while current_date <= end_date:
            if current_date.weekday() < 5:  # 월-금
                expected_dates.append(current_date)
            current_date += timedelta(days=1)
        
        completeness_result = {
            "is_complete": True,
            "missing_data": [],
            "coverage_rates": {},
            "statistics": {
                "expected_business_days": len(expected_dates),
                "expected_ohlcv_records": len(stock_codes) * len(expected_dates),
                "expected_investor_records": len(stock_codes) * len(expected_dates) * 3,  # 3개 투자자 유형
                "actual_records": {}
            }
        }
        
        # OHLCV 완전성 검사
        ohlcv_data = actual_data.get("ohlcv", [])
        ohlcv_keys = set((record.get("stock_code"), record.get("date")) for record in ohlcv_data)
        
        missing_ohlcv = 0
        for stock_code in stock_codes:
            for expected_date in expected_dates:
                if (stock_code, expected_date) not in ohlcv_keys:
                    completeness_result["missing_data"].append({
                        "data_type": "ohlcv",
                        "stock_code": stock_code,
                        "date": expected_date
                    })
                    missing_ohlcv += 1
        
        # 투자자별 매매동향 완전성 검사
        investor_data = actual_data.get("investor_trading", [])
        investor_keys = set((
            record.get("stock_code"), 
            record.get("date"), 
            record.get("investor_type")
        ) for record in investor_data)
        
        missing_investor = 0
        investor_types = ["individual", "institution", "foreign"]
        for stock_code in stock_codes:
            for expected_date in expected_dates:
                for investor_type in investor_types:
                    if (stock_code, expected_date, investor_type) not in investor_keys:
                        completeness_result["missing_data"].append({
                            "data_type": "investor_trading",
                            "stock_code": stock_code,
                            "date": expected_date,
                            "investor_type": investor_type
                        })
                        missing_investor += 1
        
        # 커버리지 비율 계산
        ohlcv_coverage = 1 - (missing_ohlcv / completeness_result["statistics"]["expected_ohlcv_records"]) if completeness_result["statistics"]["expected_ohlcv_records"] > 0 else 1
        investor_coverage = 1 - (missing_investor / completeness_result["statistics"]["expected_investor_records"]) if completeness_result["statistics"]["expected_investor_records"] > 0 else 1
        
        completeness_result["coverage_rates"] = {
            "ohlcv": max(0.0, ohlcv_coverage),
            "investor_trading": max(0.0, investor_coverage),
            "overall": max(0.0, (ohlcv_coverage + investor_coverage) / 2)
        }
        
        completeness_result["statistics"]["actual_records"] = {
            "ohlcv": len(ohlcv_data),
            "investor_trading": len(investor_data)
        }
        
        # 완전성 임계값 검사
        if any(rate < self.tolerance["completeness_threshold"] for rate in completeness_result["coverage_rates"].values()):
            completeness_result["is_complete"] = False
        
        return completeness_result


class DataIntegrityService:
    """데이터 무결성 서비스"""
    
    def __init__(self):
        """서비스 초기화"""
        self.validator = DataIntegrityValidator()
        self.config = {
            "check_frequency": "daily",
            "alert_threshold": 0.95,
            "auto_fix": False,
            "report_format": "json"
        }
        
        logger.info("데이터 무결성 서비스 초기화 완료")
    
    async def run_comprehensive_integrity_check(
        self,
        stock_codes: Optional[List[str]] = None,
        date_range: int = 30
    ) -> IntegrityReport:
        """
        종합 무결성 검사 실행
        
        Args:
            stock_codes: 검사할 종목 코드 (None이면 모든 종목)
            date_range: 검사할 날짜 범위 (일)
            
        Returns:
            무결성 검사 보고서
        """
        logger.info(f"종합 무결성 검사 시작: {len(stock_codes) if stock_codes else '전체'} 종목, {date_range}일")
        
        start_time = datetime.now()
        
        try:
            # 1. 데이터베이스에서 데이터 조회
            data = await self._fetch_data_from_database(stock_codes, date_range)
            
            # 2. 각 데이터 타입별 무결성 검사
            ohlcv_result = self.validator.validate_ohlcv_data(data["ohlcv"])
            investor_result = self.validator.validate_investor_trading_data(data["investor_trading"])
            dart_result = self.validator.validate_dart_data(data["dart"])
            
            # 3. 중복 데이터 검사
            ohlcv_dup = self.validator.detect_duplicates(data["ohlcv"], self.validator.duplicate_keys["ohlcv"])
            investor_dup = self.validator.detect_duplicates(data["investor_trading"], self.validator.duplicate_keys["investor_trading"])
            dart_dup = self.validator.detect_duplicates(data["dart"], self.validator.duplicate_keys["dart"])
            
            # 4. 완전성 검사
            completeness = self.validator.check_data_completeness(
                stock_codes or ["005930", "000660"],  # 기본 종목
                date_range,
                {"ohlcv": data["ohlcv"], "investor_trading": data["investor_trading"]}
            )
            
            # 5. 보고서 생성
            report = self._generate_integrity_report(
                {
                    "ohlcv": {"validation": ohlcv_result, "duplicates": ohlcv_dup},
                    "investor_trading": {"validation": investor_result, "duplicates": investor_dup},
                    "dart": {"validation": dart_result, "duplicates": dart_dup}
                },
                completeness,
                start_time
            )
            
            logger.info(f"종합 무결성 검사 완료: {report.overall_status}")
            return report
            
        except Exception as e:
            logger.error(f"무결성 검사 실행 실패: {e}")
            return IntegrityReport(
                timestamp=datetime.now(),
                overall_status="error",
                data_types={},
                alerts=[{
                    "type": "system_error",
                    "message": f"무결성 검사 실행 실패: {str(e)}",
                    "severity": "critical"
                }],
                recommendations=["시스템 관리자에게 문의하세요."],
                statistics={"execution_time": (datetime.now() - start_time).total_seconds()}
            )
    
    async def _fetch_data_from_database(
        self,
        stock_codes: Optional[List[str]],
        date_range: int
    ) -> Dict[str, List[Dict[str, Any]]]:
        """
        데이터베이스에서 데이터 조회
        
        Args:
            stock_codes: 조회할 종목 코드
            date_range: 조회할 날짜 범위
            
        Returns:
            조회된 데이터
        """
        data = {"ohlcv": [], "investor_trading": [], "dart": []}
        
        try:
            async for session in get_db_session():
                # OHLCV 데이터 조회
                daily_repo = DailyPriceRepository(session)
                if stock_codes:
                    for stock_code in stock_codes:
                        prices = await daily_repo.get_by_stock_code_and_date_range(
                            stock_code, date_range
                        )
                        data["ohlcv"].extend([{
                            "stock_code": p.stock_code,
                            "date": p.date,
                            "open": p.open,
                            "high": p.high,
                            "low": p.low,
                            "close": p.close,
                            "volume": p.volume,
                            "trading_value": p.trading_value
                        } for p in prices])
                
                # 투자자별 매매동향 데이터 조회
                investor_repo = InvestorTradingRepository(session)
                if stock_codes:
                    for stock_code in stock_codes:
                        trading_data = await investor_repo.get_by_stock_code_and_date_range(
                            stock_code, date_range
                        )
                        data["investor_trading"].extend([{
                            "stock_code": t.stock_code,
                            "date": t.date,
                            "investor_type": t.investor_type,
                            "buy_volume": t.buy_volume,
                            "sell_volume": t.sell_volume,
                            "net_volume": t.net_volume,
                            "buy_amount": t.buy_amount,
                            "sell_amount": t.sell_amount,
                            "net_amount": t.net_amount
                        } for t in trading_data])
                
                # DART 공시 데이터 조회
                dart_repo = DartDisclosureRepository(session)
                if stock_codes:
                    for stock_code in stock_codes:
                        disclosures = await dart_repo.get_by_stock_code_and_date_range(
                            stock_code, date_range
                        )
                        data["dart"].extend([{
                            "rcept_no": d.rcept_no,
                            "corp_name": d.corp_name,
                            "corp_code": d.corp_code,
                            "stock_code": d.stock_code,
                            "report_nm": d.report_nm,
                            "rcept_dt": d.rcept_dt,
                            "flr_nm": d.flr_nm,
                            "rm": d.rm
                        } for d in disclosures])
                
                break
                
        except Exception as e:
            logger.error(f"데이터베이스 조회 실패: {e}")
        
        return data
    
    def _generate_integrity_report(
        self,
        validation_results: Dict[str, Dict[str, Any]],
        completeness_result: Dict[str, Any],
        start_time: datetime
    ) -> IntegrityReport:
        """
        무결성 검사 보고서 생성
        
        Args:
            validation_results: 검증 결과들
            completeness_result: 완전성 검사 결과
            start_time: 검사 시작 시간
            
        Returns:
            무결성 검사 보고서
        """
        execution_time = (datetime.now() - start_time).total_seconds()
        
        data_types = {}
        alerts = []
        recommendations = []
        overall_status = "healthy"
        
        # 각 데이터 타입별 결과 처리
        for data_type, results in validation_results.items():
            validation = results["validation"]
            duplicates = results["duplicates"]
            
            # 상태 결정
            status = "healthy"
            if validation["errors"]:
                status = "error"
                overall_status = "error"
            elif validation["warnings"] or duplicates["has_duplicates"]:
                status = "warning"
                if overall_status == "healthy":
                    overall_status = "warning"
            
            # 유효성 비율 계산
            total_records = validation["statistics"]["total_records"]
            validity_rate = validation["statistics"]["valid_records"] / total_records if total_records > 0 else 1.0
            
            # 완전성 비율
            completeness_rate = completeness_result["coverage_rates"].get(data_type, 1.0)
            
            data_types[data_type] = {
                "status": status,
                "record_count": total_records,
                "validity_rate": validity_rate,
                "completeness_rate": completeness_rate,
                "duplicate_rate": duplicates["duplicate_rate"],
                "error_count": len(validation["errors"]),
                "warning_count": len(validation["warnings"])
            }
            
            # 알림 생성
            if validity_rate < self.config["alert_threshold"]:
                alerts.append({
                    "type": "low_validity",
                    "data_type": data_type,
                    "current_rate": validity_rate,
                    "threshold": self.config["alert_threshold"],
                    "severity": "warning"
                })
            
            if completeness_rate < self.config["alert_threshold"]:
                alerts.append({
                    "type": "low_completeness",
                    "data_type": data_type,
                    "current_rate": completeness_rate,
                    "threshold": self.config["alert_threshold"],
                    "severity": "warning"
                })
            
            if duplicates["has_duplicates"]:
                alerts.append({
                    "type": "duplicates_found",
                    "data_type": data_type,
                    "duplicate_count": duplicates["duplicate_count"],
                    "severity": "warning"
                })
        
        # 추천사항 생성
        if completeness_result["missing_data"]:
            recommendations.append("누락된 데이터에 대한 재수집을 고려하세요.")
        
        if any(results["duplicates"]["has_duplicates"] for results in validation_results.values()):
            recommendations.append("중복 데이터를 제거하거나 통합하세요.")
        
        if any(len(results["validation"]["errors"]) > 0 for results in validation_results.values()):
            recommendations.append("데이터 검증 오류를 수정하세요.")
        
        if not recommendations:
            recommendations.append("현재 데이터 품질이 양호합니다.")
        
        return IntegrityReport(
            timestamp=datetime.now(),
            overall_status=overall_status,
            data_types=data_types,
            alerts=alerts,
            recommendations=recommendations,
            statistics={
                "execution_time": execution_time,
                "total_records_checked": sum(dt["record_count"] for dt in data_types.values()),
                "total_alerts": len(alerts),
                "completeness_overall": completeness_result["coverage_rates"].get("overall", 1.0)
            }
        )


# 전역 무결성 서비스 인스턴스
integrity_service = DataIntegrityService()
