# AI 머니 트래커 - DART API 클라이언트

import aiohttp
import asyncio
import xml.etree.ElementTree as ET
from typing import List, Dict, Optional, Tuple
from datetime import datetime, timedelta
import json
import zipfile
import io
from loguru import logger

class DartApiClient:
    """DART 전자공시시스템 API 클라이언트"""
    
    def __init__(self, api_key: str):
        """
        DART API 클라이언트 초기화
        
        Args:
            api_key: DART API 인증키
        """
        if not api_key or len(api_key) < 20:
            raise ValueError("유효한 DART API 키가 필요합니다.")
        
        self.api_key = api_key
        self.base_url = "https://opendart.fss.or.kr/api"
        self.session: Optional[aiohttp.ClientSession] = None
        self._corp_codes: Optional[Dict[str, str]] = None  # 캐시용
        
        logger.info("DART API 클라이언트 초기화 완료")
    
    async def __aenter__(self):
        """비동기 컨텍스트 매니저 진입"""
        self.session = aiohttp.ClientSession(
            timeout=aiohttp.ClientTimeout(total=30),
            connector=aiohttp.TCPConnector(limit=10)
        )
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """비동기 컨텍스트 매니저 종료"""
        if self.session:
            await self.session.close()
    
    def validate_api_key(self) -> Tuple[bool, str]:
        """
        DART API 키 형식 검증
        
        Returns:
            Tuple[bool, str]: (유효성, 메시지)
        """
        if not self.api_key:
            return False, "API 키가 필요합니다."
        
        if len(self.api_key) < 20:
            return False, "API 키가 너무 짧습니다. (최소 20자)"
        
        if not self.api_key.replace("-", "").isalnum():
            return False, "API 키 형식이 올바르지 않습니다."
        
        return True, "유효한 API 키입니다."
    
    async def _make_request(self, endpoint: str, params: Dict = None) -> Dict:
        """
        DART API 요청 공통 메서드
        
        Args:
            endpoint: API 엔드포인트
            params: 요청 파라미터
            
        Returns:
            Dict: API 응답 데이터
        """
        if not self.session:
            raise RuntimeError("세션이 초기화되지 않았습니다. async with 구문을 사용하세요.")
        
        # 기본 파라미터 설정
        request_params = {"crtfc_key": self.api_key}
        if params:
            request_params.update(params)
        
        url = f"{self.base_url}/{endpoint}"
        
        try:
            async with self.session.get(url, params=request_params) as response:
                if response.status != 200:
                    raise aiohttp.ClientError(f"HTTP {response.status}: {await response.text()}")
                
                # XML 응답 처리
                if endpoint.endswith('.xml'):
                    content = await response.read()
                    return {"content": content, "content_type": "xml"}
                
                # JSON 응답 처리
                data = await response.json()
                
                # DART API 상태 코드 확인
                if data.get("status") != "000":
                    error_msg = data.get("message", "Unknown error")
                    raise ValueError(f"DART API Error [{data.get('status')}]: {error_msg}")
                
                return data
                
        except aiohttp.ClientError as e:
            logger.error(f"DART API 요청 실패 ({endpoint}): {e}")
            raise
        except Exception as e:
            logger.error(f"DART API 요청 중 예외 발생 ({endpoint}): {e}")
            raise
    
    async def fetch_corp_code(self) -> Dict[str, str]:
        """
        종목코드 조회 (corpCode.xml)
        
        Returns:
            Dict[str, str]: {종목코드: 회사명} 매핑
        """
        if self._corp_codes:
            logger.info("캐시된 종목코드 데이터 사용")
            return self._corp_codes
        
        try:
            logger.info("종목코드 데이터 조회 시작")
            response = await self._make_request("corpCode.xml")
            
            # ZIP 파일 압축 해제
            zip_content = response["content"]
            with zipfile.ZipFile(io.BytesIO(zip_content)) as zip_file:
                xml_content = zip_file.read("CORPCODE.xml")
            
            # XML 파싱
            root = ET.fromstring(xml_content)
            corp_codes = {}
            
            for corp in root.findall("list"):
                corp_code = corp.find("corp_code")
                corp_name = corp.find("corp_name")
                stock_code = corp.find("stock_code")
                
                if corp_code is not None and corp_name is not None:
                    # 상장사만 필터링 (stock_code가 있는 경우)
                    if stock_code is not None and stock_code.text:
                        corp_codes[stock_code.text] = {
                            "corp_code": corp_code.text,
                            "corp_name": corp_name.text
                        }
            
            self._corp_codes = corp_codes
            logger.info(f"종목코드 {len(corp_codes)}개 조회 완료")
            return corp_codes
            
        except Exception as e:
            logger.error(f"종목코드 조회 실패: {e}")
            raise
    
    async def fetch_majorstock(self, corp_code: str, begin_de: str = None, end_de: str = None) -> List[Dict]:
        """
        대량보유상황보고서 조회 (majorstock.json)
        
        Args:
            corp_code: 고유번호 (8자리)
            begin_de: 시작일자 (YYYYMMDD, 기본값: 60일 전)
            end_de: 종료일자 (YYYYMMDD, 기본값: 오늘)
            
        Returns:
            List[Dict]: 대량보유상황보고서 목록
        """
        # 기본 날짜 설정 (최근 60일)
        if not end_de:
            end_de = datetime.now().strftime("%Y%m%d")
        if not begin_de:
            begin_de = (datetime.now() - timedelta(days=60)).strftime("%Y%m%d")
        
        params = {
            "corp_code": corp_code,
            "begin_de": begin_de,
            "end_de": end_de
        }
        
        try:
            logger.info(f"대량보유상황보고서 조회: {corp_code} ({begin_de}~{end_de})")
            response = await self._make_request("majorstock.json", params)
            
            reports = response.get("list", [])
            logger.info(f"대량보유상황보고서 {len(reports)}건 조회 완료")
            return reports
            
        except Exception as e:
            logger.error(f"대량보유상황보고서 조회 실패 ({corp_code}): {e}")
            raise
    
    async def fetch_elestock(self, corp_code: str, begin_de: str = None, end_de: str = None) -> List[Dict]:
        """
        임원·주요주주 보유현황 조회 (elestock.json)
        
        Args:
            corp_code: 고유번호 (8자리)
            begin_de: 시작일자 (YYYYMMDD, 기본값: 60일 전)
            end_de: 종료일자 (YYYYMMDD, 기본값: 오늘)
            
        Returns:
            List[Dict]: 임원·주요주주 보유현황 목록
        """
        # 기본 날짜 설정 (최근 60일)
        if not end_de:
            end_de = datetime.now().strftime("%Y%m%d")
        if not begin_de:
            begin_de = (datetime.now() - timedelta(days=60)).strftime("%Y%m%d")
        
        params = {
            "corp_code": corp_code,
            "begin_de": begin_de,
            "end_de": end_de
        }
        
        try:
            logger.info(f"임원·주요주주 보유현황 조회: {corp_code} ({begin_de}~{end_de})")
            response = await self._make_request("elestock.json", params)
            
            reports = response.get("list", [])
            logger.info(f"임원·주요주주 보유현황 {len(reports)}건 조회 완료")
            return reports
            
        except Exception as e:
            logger.error(f"임원·주요주주 보유현황 조회 실패 ({corp_code}): {e}")
            raise
    
    async def test_api_connection(self) -> Tuple[bool, str]:
        """
        DART API 연결 테스트
        
        Returns:
            Tuple[bool, str]: (성공 여부, 메시지)
        """
        try:
            # 간단한 API 호출로 연결 테스트
            params = {
                "corp_code": "00126380",  # 삼성전자
                "begin_de": datetime.now().strftime("%Y%m%d"),
                "end_de": datetime.now().strftime("%Y%m%d")
            }
            
            await self._make_request("majorstock.json", params)
            return True, "DART API 연결 테스트 성공"
            
        except ValueError as e:
            # DART API 응답 오류
            return False, str(e)
        except Exception as e:
            # 기타 연결 오류
            return False, f"연결 테스트 실패: {str(e)}"

class DartDataProcessor:
    """DART 데이터 처리 및 분석 클래스"""
    
    @staticmethod
    def calculate_dart_scores(majorstock_reports: List[Dict], elestock_reports: List[Dict]) -> Dict[str, float]:
        """
        PRD 문서의 DART 6요소 기반 점수 계산
        
        Args:
            majorstock_reports: 대량보유상황보고서 목록
            elestock_reports: 임원·주요주주 보유현황 목록
            
        Returns:
            Dict[str, float]: DART 점수 구성요소
        """
        scores = {
            "dart1_new_holder": 0.0,       # 신규 5% 보유자 등장 (1.0점)
            "dart2_continuous_increase": 0.0,  # 연속 증가 (0.8점)
            "dart3_purpose_upgrade": 0.0,       # 보유목적 상향 (0.6점)
            "dart4_investor_type": 0.0,         # 보고자 성격 (0.3-0.5점)
            "dart5_insider_buy": 0.0,           # 임원·주요주주 순매수 (0.6점)
            "dart6_split_purchase": 0.0         # 분할매수 패턴 (0.4점)
        }
        
        # DART-1: 신규 5% 보유자 등장
        for report in majorstock_reports:
            if report.get("report_tp") == "신규보고":
                scores["dart1_new_holder"] = 1.0
                break
        
        # DART-2: 연속 지분 증가
        increase_count = 0
        for report in majorstock_reports:
            stkrt_irds = report.get("stkrt_irds", "")
            if stkrt_irds.startswith("+") and float(stkrt_irds.replace("+", "")) >= 1.0:
                increase_count += 1
        
        if increase_count >= 2:
            scores["dart2_continuous_increase"] = 0.8
        
        # DART-3: 보유목적 상향
        for report in majorstock_reports:
            report_resn = report.get("report_resn", "")
            if "경영권" in report_resn or "일반투자" in report_resn:
                scores["dart3_purpose_upgrade"] = 0.6
                break
        
        # DART-4: 보고자 성격 가중치
        for report in majorstock_reports:
            repror = report.get("repror", "").lower()
            if any(keyword in repror for keyword in ["연기금", "공제회", "전략"]):
                scores["dart4_investor_type"] = 0.5
                break
            elif any(keyword in repror for keyword in ["헤지펀드", "사모"]):
                scores["dart4_investor_type"] = 0.3
                break
        
        # DART-5: 임원·주요주주 순매수
        for report in elestock_reports:
            stkrt_irds = report.get("sp_stock_lmp_irds_rate", "")
            if stkrt_irds and float(stkrt_irds) > 0:
                scores["dart5_insider_buy"] = 0.6
                break
        
        # DART-6: 분할매수 패턴
        small_increases = 0
        for report in majorstock_reports:
            stkrt_irds = report.get("stkrt_irds", "")
            if stkrt_irds.startswith("+"):
                increase = float(stkrt_irds.replace("+", ""))
                if 0.2 <= increase <= 0.5:
                    small_increases += 1
        
        if small_increases >= 3:
            scores["dart6_split_purchase"] = 0.4
        
        return scores
    
    @staticmethod
    def filter_recent_reports(reports: List[Dict], days: int = 60) -> List[Dict]:
        """
        최근 N일 이내의 보고서만 필터링
        
        Args:
            reports: 보고서 목록
            days: 필터링할 일수
            
        Returns:
            List[Dict]: 필터링된 보고서 목록
        """
        cutoff_date = datetime.now() - timedelta(days=days)
        filtered_reports = []
        
        for report in reports:
            rcept_dt = report.get("rcept_dt", "")
            if rcept_dt:
                try:
                    report_date = datetime.strptime(rcept_dt, "%Y%m%d")
                    if report_date >= cutoff_date:
                        filtered_reports.append(report)
                except ValueError:
                    # 날짜 형식이 잘못된 경우 일단 포함
                    filtered_reports.append(report)
        
        return filtered_reports

# DART API 클라이언트 싱글톤 인스턴스 생성 함수
_dart_client_instance = None

async def get_dart_client(api_key: str) -> DartApiClient:
    """DART API 클라이언트 인스턴스 반환"""
    global _dart_client_instance
    
    if _dart_client_instance is None:
        _dart_client_instance = DartApiClient(api_key)
    
    return _dart_client_instance
