# AI 머니 트래커 - 데이터 수집 기본 클래스

from abc import ABC, abstractmethod
from typing import List, Dict, Any, Optional, Union
from datetime import datetime, date, timedelta
import asyncio
import aiohttp
from loguru import logger
import time
from enum import Enum

class CollectionStatus(str, Enum):
    """수집 상태"""
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    RETRY = "retry"

class DataCollectionError(Exception):
    """데이터 수집 오류"""
    pass

class RateLimitError(DataCollectionError):
    """API 속도 제한 오류"""
    pass

class ValidationError(DataCollectionError):
    """데이터 검증 오류"""
    pass

class BaseDataCollector(ABC):
    """데이터 수집기 기본 클래스"""
    
    def __init__(self, 
                 api_key: str,
                 base_url: str,
                 timeout: int = 30,
                 max_retries: int = 3,
                 retry_delay: int = 5,
                 rate_limit: int = 100):
        """
        데이터 수집기 초기화
        
        Args:
            api_key: API 키
            base_url: 기본 URL
            timeout: 요청 타임아웃 (초)
            max_retries: 최대 재시도 횟수
            retry_delay: 재시도 지연 시간 (초)
            rate_limit: 속도 제한 (초당 요청 수)
        """
        self.api_key = api_key
        self.base_url = base_url.rstrip('/')
        self.timeout = timeout
        self.max_retries = max_retries
        self.retry_delay = retry_delay
        self.rate_limit = rate_limit
        
        # 속도 제한을 위한 요청 시간 추적
        self.request_times = []
        
        # 세션 초기화
        self.session: Optional[aiohttp.ClientSession] = None
        
        logger.info(f"{self.__class__.__name__} 초기화 완료: {base_url}")
    
    async def __aenter__(self):
        """비동기 컨텍스트 매니저 진입"""
        await self.initialize()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """비동기 컨텍스트 매니저 종료"""
        await self.cleanup()
    
    async def initialize(self):
        """수집기 초기화"""
        if not self.session:
            timeout = aiohttp.ClientTimeout(total=self.timeout)
            self.session = aiohttp.ClientSession(timeout=timeout)
            logger.info(f"{self.__class__.__name__} HTTP 세션 초기화")
    
    async def cleanup(self):
        """수집기 정리"""
        if self.session:
            await self.session.close()
            self.session = None
            logger.info(f"{self.__class__.__name__} HTTP 세션 종료")
    
    async def _check_rate_limit(self):
        """속도 제한 검사"""
        current_time = time.time()
        
        # 1초 이내의 요청만 유지
        self.request_times = [t for t in self.request_times if current_time - t < 1.0]
        
        if len(self.request_times) >= self.rate_limit:
            sleep_time = 1.0 - (current_time - self.request_times[0])
            if sleep_time > 0:
                logger.warning(f"속도 제한 도달. {sleep_time:.2f}초 대기")
                await asyncio.sleep(sleep_time)
        
        self.request_times.append(current_time)
    
    async def _make_request(self, 
                          method: str, 
                          url: str, 
                          params: Optional[Dict] = None,
                          headers: Optional[Dict] = None,
                          data: Optional[Dict] = None) -> Dict[str, Any]:
        """
        HTTP 요청 실행
        
        Args:
            method: HTTP 메서드
            url: 요청 URL
            params: 쿼리 파라미터
            headers: 요청 헤더
            data: 요청 데이터
            
        Returns:
            응답 데이터
            
        Raises:
            DataCollectionError: 요청 실패시
        """
        if not self.session:
            await self.initialize()
        
        # 속도 제한 검사
        await self._check_rate_limit()
        
        # 기본 헤더 설정
        default_headers = {
            "User-Agent": "AI-Money-Tracker/1.0",
            "Accept": "application/json"
        }
        if headers:
            default_headers.update(headers)
        
        for attempt in range(self.max_retries + 1):
            try:
                logger.debug(f"API 요청: {method} {url} (시도 {attempt + 1}/{self.max_retries + 1})")
                
                async with self.session.request(
                    method=method,
                    url=url,
                    params=params,
                    headers=default_headers,
                    json=data
                ) as response:
                    
                    if response.status == 429:  # Too Many Requests
                        raise RateLimitError("API 속도 제한 초과")
                    
                    response.raise_for_status()
                    
                    content_type = response.headers.get('content-type', '')
                    if 'application/json' in content_type:
                        return await response.json()
                    else:
                        text_data = await response.text()
                        return {"data": text_data}
                        
            except aiohttp.ClientError as e:
                logger.warning(f"API 요청 실패 (시도 {attempt + 1}): {e}")
                
                if attempt == self.max_retries:
                    raise DataCollectionError(f"API 요청 최종 실패: {e}")
                
                # 지수 백오프로 재시도
                sleep_time = self.retry_delay * (2 ** attempt)
                logger.info(f"{sleep_time}초 후 재시도")
                await asyncio.sleep(sleep_time)
            
            except RateLimitError:
                if attempt == self.max_retries:
                    raise
                
                # 속도 제한시 더 긴 대기
                sleep_time = self.retry_delay * 3
                logger.warning(f"속도 제한으로 {sleep_time}초 대기")
                await asyncio.sleep(sleep_time)
    
    def validate_date_format(self, date_str: str, format_str: str = "%Y%m%d") -> bool:
        """날짜 형식 검증"""
        try:
            datetime.strptime(date_str, format_str)
            return True
        except ValueError:
            return False
    
    def validate_stock_code(self, stock_code: str) -> bool:
        """종목코드 검증"""
        return (isinstance(stock_code, str) and 
                len(stock_code) == 6 and 
                stock_code.isdigit())
    
    def detect_duplicates(self, data_list: List[Dict], key_fields: List[str]) -> List[Dict]:
        """중복 데이터 탐지"""
        seen = set()
        duplicates = []
        
        for item in data_list:
            key = tuple(item.get(field) for field in key_fields)
            if key in seen:
                duplicates.append(item)
            else:
                seen.add(key)
        
        return duplicates
    
    @abstractmethod
    async def collect_data(self, **kwargs) -> List[Dict[str, Any]]:
        """
        데이터 수집 (추상 메서드)
        
        Returns:
            수집된 데이터 목록
        """
        pass
    
    @abstractmethod
    def validate_data(self, data: Dict[str, Any]) -> List[str]:
        """
        데이터 검증 (추상 메서드)
        
        Args:
            data: 검증할 데이터
            
        Returns:
            오류 메시지 목록
        """
        pass

class BatchDataCollector(BaseDataCollector):
    """일괄 처리 데이터 수집기"""
    
    def __init__(self, batch_size: int = 100, **kwargs):
        """
        일괄 처리 수집기 초기화
        
        Args:
            batch_size: 배치 크기
            **kwargs: 기본 수집기 인자
        """
        super().__init__(**kwargs)
        self.batch_size = batch_size
    
    async def collect_batch_data(self, items: List[Any], **kwargs) -> Dict[str, List[Dict]]:
        """
        배치 단위로 데이터 수집
        
        Args:
            items: 수집할 항목 목록
            **kwargs: 추가 인자
            
        Returns:
            항목별 수집 결과
        """
        results = {}
        total_batches = (len(items) + self.batch_size - 1) // self.batch_size
        
        logger.info(f"배치 수집 시작: {len(items)}개 항목, {total_batches}개 배치")
        
        for i in range(0, len(items), self.batch_size):
            batch_items = items[i:i + self.batch_size]
            batch_num = i // self.batch_size + 1
            
            logger.info(f"배치 {batch_num}/{total_batches} 수집 중: {len(batch_items)}개 항목")
            
            # 배치 내 항목들을 동시에 처리
            tasks = []
            for item in batch_items:
                task = self.collect_single_item(item, **kwargs)
                tasks.append(task)
            
            try:
                batch_results = await asyncio.gather(*tasks, return_exceptions=True)
                
                for item, result in zip(batch_items, batch_results):
                    if isinstance(result, Exception):
                        logger.error(f"항목 {item} 수집 실패: {result}")
                        results[str(item)] = []
                    else:
                        results[str(item)] = result
                        
            except Exception as e:
                logger.error(f"배치 {batch_num} 수집 실패: {e}")
                for item in batch_items:
                    results[str(item)] = []
            
            # 배치 간 쿨다운
            if batch_num < total_batches:
                await asyncio.sleep(1)
        
        logger.info(f"배치 수집 완료: {len(results)}개 결과")
        return results
    
    @abstractmethod
    async def collect_single_item(self, item: Any, **kwargs) -> List[Dict[str, Any]]:
        """
        단일 항목 데이터 수집 (추상 메서드)
        
        Args:
            item: 수집할 항목
            **kwargs: 추가 인자
            
        Returns:
            수집된 데이터 목록
        """
        pass

class CollectionManager:
    """데이터 수집 관리자"""
    
    def __init__(self):
        """수집 관리자 초기화"""
        self.collectors: Dict[str, BaseDataCollector] = {}
        self.collection_status: Dict[str, CollectionStatus] = {}
        self.collection_results: Dict[str, Dict] = {}
        
        logger.info("데이터 수집 관리자 초기화 완료")
    
    def register_collector(self, name: str, collector: BaseDataCollector):
        """수집기 등록"""
        self.collectors[name] = collector
        self.collection_status[name] = CollectionStatus.PENDING
        logger.info(f"수집기 등록: {name}")
    
    async def run_collection(self, 
                           collector_name: str, 
                           **kwargs) -> Dict[str, Any]:
        """
        데이터 수집 실행
        
        Args:
            collector_name: 수집기 이름
            **kwargs: 수집 인자
            
        Returns:
            수집 결과
        """
        if collector_name not in self.collectors:
            raise ValueError(f"등록되지 않은 수집기: {collector_name}")
        
        collector = self.collectors[collector_name]
        self.collection_status[collector_name] = CollectionStatus.RUNNING
        
        start_time = datetime.now()
        logger.info(f"데이터 수집 시작: {collector_name}")
        
        try:
            async with collector:
                data = await collector.collect_data(**kwargs)
                
                # 데이터 검증
                validation_errors = []
                for item in data:
                    errors = collector.validate_data(item)
                    if errors:
                        validation_errors.extend(errors)
                
                end_time = datetime.now()
                duration = (end_time - start_time).total_seconds()
                
                result = {
                    "collector": collector_name,
                    "status": CollectionStatus.COMPLETED,
                    "start_time": start_time.isoformat(),
                    "end_time": end_time.isoformat(),
                    "duration_seconds": duration,
                    "data_count": len(data),
                    "validation_errors": validation_errors,
                    "data": data
                }
                
                self.collection_status[collector_name] = CollectionStatus.COMPLETED
                self.collection_results[collector_name] = result
                
                logger.info(f"데이터 수집 완료: {collector_name}, "
                          f"{len(data)}건, {duration:.2f}초")
                
                return result
                
        except Exception as e:
            self.collection_status[collector_name] = CollectionStatus.FAILED
            logger.error(f"데이터 수집 실패: {collector_name}, {e}")
            
            result = {
                "collector": collector_name,
                "status": CollectionStatus.FAILED,
                "start_time": start_time.isoformat(),
                "error": str(e),
                "data": []
            }
            
            self.collection_results[collector_name] = result
            return result
    
    def get_collection_status(self, collector_name: str = None) -> Dict[str, Any]:
        """수집 상태 조회"""
        if collector_name:
            return {
                "collector": collector_name,
                "status": self.collection_status.get(collector_name, CollectionStatus.PENDING),
                "result": self.collection_results.get(collector_name)
            }
        
        return {
            "collectors": {
                name: {
                    "status": self.collection_status.get(name, CollectionStatus.PENDING),
                    "has_result": name in self.collection_results
                }
                for name in self.collectors.keys()
            }
        }
