# AI 머니 트래커 - OHLCV 데이터 수집기

from typing import List, Dict, Any, Optional
from datetime import datetime, date, timedelta
import asyncio
from loguru import logger

from .base import BatchDataCollector, DataCollectionError, ValidationError
from backend.database.base import get_db_session
from backend.database.repositories import StockInfoRepository, DailyPriceRepository

class OHLCVDataCollector(BatchDataCollector):
    """일봉 OHLCV 데이터 수집기"""
    
    def __init__(self, 
                 api_key: str,
                 base_url: str = "https://openapi.koreainvestment.com:9443",
                 **kwargs):
        """
        OHLCV 수집기 초기화
        
        Args:
            api_key: 한국투자증권 API 키
            base_url: API 기본 URL
            **kwargs: 기본 수집기 인자
        """
        # 기본값 설정
        default_kwargs = {
            "timeout": 30,
            "max_retries": 3,
            "retry_delay": 5,
            "rate_limit": 20,  # 초당 20개 요청
        }
        
        # kwargs로 전달된 값이 있으면 덮어쓰기
        default_kwargs.update(kwargs)
        
        super().__init__(
            api_key=api_key,
            base_url=base_url,
            **default_kwargs
        )
        
        # API 엔드포인트
        self.ohlcv_endpoint = "/uapi/domestic-stock/v1/quotations/inquire-daily-itemchartprice"
        
        logger.info("OHLCV 데이터 수집기 초기화 완료")
    
    def _get_api_headers(self) -> Dict[str, str]:
        """API 요청 헤더 생성"""
        return {
            "Content-Type": "application/json; charset=utf-8",
            "authorization": f"Bearer {self.api_key}",
            "appkey": self.api_key,
            "appsecret": "APP_SECRET_KEY",  # 실제 환경에서는 설정에서 가져와야 함
            "tr_id": "FHKST03010100"  # 국내주식기간별시세(일/주/월/년)
        }
    
    async def collect_data(self, 
                          stock_codes: List[str] = None,
                          days: int = 60,
                          end_date: str = None) -> List[Dict[str, Any]]:
        """
        OHLCV 데이터 수집
        
        Args:
            stock_codes: 수집할 종목코드 목록 (None이면 전체)
            days: 수집할 일수
            end_date: 종료 날짜 (YYYYMMDD 형식, None이면 오늘)
            
        Returns:
            수집된 OHLCV 데이터 목록
        """
        if end_date is None:
            end_date = date.today().strftime("%Y%m%d")
        
        # 시작 날짜 계산 (영업일 기준 대략 계산)
        start_date_obj = datetime.strptime(end_date, "%Y%m%d") - timedelta(days=days*2)
        start_date = start_date_obj.strftime("%Y%m%d")
        
        logger.info(f"OHLCV 수집 시작: {start_date} ~ {end_date}, {days}일")
        
        # 종목코드 목록 준비
        if stock_codes is None:
            stock_codes = await self._get_all_stock_codes()
        
        # 유효한 종목코드만 필터링
        valid_codes = [code for code in stock_codes if self.validate_stock_code(code)]
        logger.info(f"수집 대상 종목: {len(valid_codes)}개")
        
        # 배치 수집 실행
        batch_results = await self.collect_batch_data(
            valid_codes,
            start_date=start_date,
            end_date=end_date,
            days=days
        )
        
        # 결과 통합
        all_data = []
        for stock_code, data_list in batch_results.items():
            all_data.extend(data_list)
        
        logger.info(f"OHLCV 수집 완료: {len(all_data)}건")
        return all_data
    
    async def collect_single_item(self, 
                                 stock_code: str,
                                 start_date: str,
                                 end_date: str,
                                 days: int,
                                 **kwargs) -> List[Dict[str, Any]]:
        """
        단일 종목 OHLCV 데이터 수집
        
        Args:
            stock_code: 종목코드
            start_date: 시작날짜 (YYYYMMDD)
            end_date: 종료날짜 (YYYYMMDD)
            days: 요청할 일수
            
        Returns:
            해당 종목의 OHLCV 데이터 목록
        """
        try:
            logger.debug(f"OHLCV 수집: {stock_code} ({start_date}~{end_date})")
            
            # 실제 API 호출 대신 모의 데이터 생성 (개발용)
            if self.api_key.startswith("TEST_"):
                return await self._generate_mock_ohlcv_data(stock_code, days)
            
            # 실제 API 호출
            params = {
                "FID_COND_MRKT_DIV_CODE": "J",  # 시장구분코드 (J: 주식)
                "FID_INPUT_ISCD": stock_code,   # 종목코드
                "FID_INPUT_DATE_1": start_date,  # 시작일자
                "FID_INPUT_DATE_2": end_date,    # 종료일자
                "FID_PERIOD_DIV_CODE": "D",      # 기간분류코드 (D: 일)
                "FID_ORG_ADJ_PRC": "0"           # 수정주가 원주가 가격구분코드
            }
            
            url = f"{self.base_url}{self.ohlcv_endpoint}"
            headers = self._get_api_headers()
            
            response = await self._make_request("GET", url, params=params, headers=headers)
            
            return self._parse_ohlcv_response(response, stock_code)
            
        except Exception as e:
            logger.error(f"OHLCV 수집 실패: {stock_code}, {e}")
            return []
    
    async def _generate_mock_ohlcv_data(self, stock_code: str, days: int) -> List[Dict[str, Any]]:
        """모의 OHLCV 데이터 생성 (개발/테스트용)"""
        data = []
        base_price = 75000  # 기준 가격
        
        for i in range(days):
            date_obj = date.today() - timedelta(days=i)
            
            # 가격 변동폭 (±5%)
            price_change = (hash(f"{stock_code}{date_obj}") % 10000 - 5000) / 100000
            daily_price = int(base_price * (1 + price_change))
            
            # OHLCV 데이터 생성
            open_price = daily_price + (hash(f"open{stock_code}{date_obj}") % 2000 - 1000)
            close_price = daily_price + (hash(f"close{stock_code}{date_obj}") % 2000 - 1000)
            high_price = max(open_price, close_price) + abs(hash(f"high{stock_code}{date_obj}") % 1500)
            low_price = min(open_price, close_price) - abs(hash(f"low{stock_code}{date_obj}") % 1500)
            
            volume = 10000000 + abs(hash(f"volume{stock_code}{date_obj}") % 20000000)
            trading_value = int((high_price + low_price) / 2 * volume)
            
            data.append({
                "stock_code": stock_code,
                "date": date_obj.strftime("%Y%m%d"),
                "open_price": str(open_price),
                "high_price": str(high_price),
                "low_price": str(low_price),
                "close_price": str(close_price),
                "volume": str(volume),
                "trading_value": str(trading_value)
            })
        
        return data
    
    def _parse_ohlcv_response(self, response: Dict, stock_code: str) -> List[Dict[str, Any]]:
        """OHLCV API 응답 파싱"""
        try:
            if response.get("rt_cd") != "0":
                error_msg = response.get("msg1", "알 수 없는 오류")
                raise DataCollectionError(f"API 오류: {error_msg}")
            
            output_list = response.get("output2", [])
            parsed_data = []
            
            for item in output_list:
                parsed_data.append({
                    "stock_code": stock_code,
                    "date": item.get("stck_bsop_date"),     # 영업일자
                    "open_price": item.get("stck_oprc"),     # 시가
                    "high_price": item.get("stck_hgpr"),     # 고가  
                    "low_price": item.get("stck_lwpr"),      # 저가
                    "close_price": item.get("stck_clpr"),    # 종가
                    "volume": item.get("acml_vol"),          # 누적거래량
                    "trading_value": item.get("acml_tr_pbmn") # 누적거래대금
                })
            
            return parsed_data
            
        except Exception as e:
            logger.error(f"OHLCV 응답 파싱 실패: {stock_code}, {e}")
            return []
    
    def validate_data(self, data: Dict[str, Any]) -> List[str]:
        """OHLCV 데이터 검증"""
        errors = []
        
        # 필수 필드 검증
        required_fields = ["stock_code", "date", "open_price", "high_price", 
                          "low_price", "close_price", "volume"]
        
        for field in required_fields:
            if field not in data or data[field] is None:
                errors.append(f"필수 필드 '{field}' 누락")
        
        # 종목코드 검증
        if "stock_code" in data and not self.validate_stock_code(data["stock_code"]):
            errors.append(f"유효하지 않은 종목코드: {data['stock_code']}")
        
        # 날짜 형식 검증
        if "date" in data and not self.validate_date_format(data["date"]):
            errors.append(f"유효하지 않은 날짜 형식: {data['date']}")
        
        # 가격 데이터 검증
        if all(field in data for field in ["open_price", "high_price", "low_price", "close_price"]):
            try:
                open_p = int(data["open_price"])
                high_p = int(data["high_price"])
                low_p = int(data["low_price"])
                close_p = int(data["close_price"])
                
                if low_p <= 0 or high_p <= 0:
                    errors.append("가격은 0보다 커야 함")
                
                if low_p > high_p:
                    errors.append("저가가 고가보다 높음")
                
                if not (low_p <= open_p <= high_p):
                    errors.append("시가가 고가-저가 범위를 벗어남")
                
                if not (low_p <= close_p <= high_p):
                    errors.append("종가가 고가-저가 범위를 벗어남")
                    
            except (ValueError, TypeError):
                errors.append("가격 데이터가 숫자가 아님")
        
        # 거래량 검증
        if "volume" in data:
            try:
                volume = int(data["volume"])
                if volume < 0:
                    errors.append("거래량이 음수")
            except (ValueError, TypeError):
                errors.append("거래량이 숫자가 아님")
        
        return errors
    
    async def _get_all_stock_codes(self) -> List[str]:
        """전체 종목코드 목록 조회"""
        try:
            async for session in get_db_session():
                stock_repo = StockInfoRepository(session)
                stocks = await stock_repo.get_all()
                return [stock.stock_code for stock in stocks]
        except Exception as e:
            logger.error(f"종목코드 목록 조회 실패: {e}")
            # 기본 종목코드 목록 반환
            return ["005930", "000660", "035420", "005380", "006400", "051910", "035720"]
    
    async def save_to_database(self, ohlcv_data: List[Dict[str, Any]]) -> Dict[str, int]:
        """OHLCV 데이터를 데이터베이스에 저장"""
        try:
            async for session in get_db_session():
                price_repo = DailyPriceRepository(session)
                
                # 데이터 변환
                db_data = []
                for item in ohlcv_data:
                    # 데이터 검증
                    validation_errors = self.validate_data(item)
                    if validation_errors:
                        logger.warning(f"데이터 검증 실패: {item}, 오류: {validation_errors}")
                        continue
                    
                    # 데이터베이스 형식으로 변환
                    db_item = {
                        "stock_code": item["stock_code"],
                        "date": datetime.strptime(item["date"], "%Y%m%d").date(),
                        "open_price": int(item["open_price"]),
                        "high_price": int(item["high_price"]),
                        "low_price": int(item["low_price"]),
                        "close_price": int(item["close_price"]),
                        "volume": int(item["volume"]),
                        "trading_value": int(item.get("trading_value", 0))
                    }
                    db_data.append(db_item)
                
                # 중복 제거
                duplicates = self.detect_duplicates(db_data, ["stock_code", "date"])
                unique_data = [item for item in db_data if item not in duplicates]
                
                # 데이터베이스 저장
                saved_count = await price_repo.bulk_create(unique_data)
                
                logger.info(f"OHLCV 데이터 저장 완료: {saved_count}건 (중복 제거: {len(duplicates)}건)")
                
                return {
                    "total_received": len(ohlcv_data),
                    "validation_passed": len(db_data),
                    "duplicates_removed": len(duplicates),
                    "saved_count": saved_count
                }
                
        except Exception as e:
            logger.error(f"OHLCV 데이터 저장 실패: {e}")
            return {
                "total_received": len(ohlcv_data),
                "validation_passed": 0,
                "duplicates_removed": 0,
                "saved_count": 0,
                "error": str(e)
            }

class OHLCVCollectionScheduler:
    """OHLCV 데이터 수집 스케줄러"""
    
    def __init__(self, collector: OHLCVDataCollector):
        """
        스케줄러 초기화
        
        Args:
            collector: OHLCV 데이터 수집기
        """
        self.collector = collector
        self.is_running = False
        self.last_collection_time = None
        
        logger.info("OHLCV 수집 스케줄러 초기화 완료")
    
    async def run_daily_collection(self, 
                                  target_time: str = "18:00",
                                  stock_codes: List[str] = None,
                                  days: int = 60) -> Dict[str, Any]:
        """
        일일 OHLCV 데이터 수집 실행
        
        Args:
            target_time: 수집 시간 (HH:MM 형식)
            stock_codes: 대상 종목코드 (None이면 전체)
            days: 수집할 일수
            
        Returns:
            수집 결과
        """
        start_time = datetime.now()
        logger.info(f"일일 OHLCV 수집 시작: {start_time}")
        
        try:
            # 데이터 수집
            ohlcv_data = await self.collector.collect_data(
                stock_codes=stock_codes,
                days=days
            )
            
            # 데이터베이스 저장
            save_result = await self.collector.save_to_database(ohlcv_data)
            
            end_time = datetime.now()
            duration = (end_time - start_time).total_seconds()
            
            self.last_collection_time = end_time
            
            result = {
                "collection_type": "daily_ohlcv",
                "start_time": start_time.isoformat(),
                "end_time": end_time.isoformat(),
                "duration_seconds": duration,
                "target_stocks": len(stock_codes) if stock_codes else "all",
                "collection_result": save_result,
                "success": True
            }
            
            logger.info(f"일일 OHLCV 수집 완료: {duration:.2f}초, "
                       f"{save_result['saved_count']}건 저장")
            
            return result
            
        except Exception as e:
            logger.error(f"일일 OHLCV 수집 실패: {e}")
            
            return {
                "collection_type": "daily_ohlcv",
                "start_time": start_time.isoformat(),
                "error": str(e),
                "success": False
            }
    
    def get_collection_status(self) -> Dict[str, Any]:
        """수집 상태 조회"""
        return {
            "scheduler_type": "ohlcv_daily",
            "is_running": self.is_running,
            "last_collection_time": self.last_collection_time.isoformat() if self.last_collection_time else None,
            "next_collection_time": None  # 실제 스케줄러에서는 다음 실행 시간 계산
        }
