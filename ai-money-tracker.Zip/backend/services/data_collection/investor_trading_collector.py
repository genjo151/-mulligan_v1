# AI 머니 트래커 - 투자자별 매매동향 수집기

from typing import List, Dict, Any, Optional
from datetime import datetime, date, timedelta
import asyncio
from loguru import logger

from .base import BatchDataCollector, DataCollectionError, ValidationError
from backend.database.base import get_db_session
from backend.database.repositories import StockInfoRepository, InvestorTradingRepository

class InvestorTradingCollector(BatchDataCollector):
    """투자자별 매매동향 데이터 수집기"""
    
    def __init__(self, 
                 api_key: str,
                 base_url: str = "https://openapi.koreainvestment.com:9443",
                 **kwargs):
        """
        투자자별 매매동향 수집기 초기화
        
        Args:
            api_key: 한국투자증권 API 키
            base_url: API 기본 URL
            **kwargs: 기본 수집기 인자
        """
        # 기본값 설정
        default_kwargs = {
            "timeout": 30,
            "max_retries": 3,
            "retry_delay": 5,
            "rate_limit": 10,  # 초당 10개 요청 (OHLCV보다 낮음)
        }
        
        # kwargs로 전달된 값이 있으면 덮어쓰기
        default_kwargs.update(kwargs)
        
        super().__init__(
            api_key=api_key,
            base_url=base_url,
            **default_kwargs
        )
        
        # API 엔드포인트
        self.trading_endpoint = "/uapi/domestic-stock/v1/quotations/inquire-investor-trading"
        
        logger.info("투자자별 매매동향 수집기 초기화 완료")
    
    def _get_api_headers(self) -> Dict[str, str]:
        """API 요청 헤더 생성"""
        return {
            "Content-Type": "application/json; charset=utf-8",
            "authorization": f"Bearer {self.api_key}",
            "appkey": self.api_key,
            "appsecret": "APP_SECRET_KEY",  # 실제 환경에서는 설정에서 가져와야 함
            "tr_id": "FHKST01010900"  # 국내주식 투자자별 매매동향
        }
    
    async def collect_data(self, 
                          stock_codes: List[str] = None,
                          days: int = 60,
                          end_date: str = None) -> List[Dict[str, Any]]:
        """
        투자자별 매매동향 데이터 수집
        
        Args:
            stock_codes: 수집할 종목코드 목록 (None이면 전체)
            days: 수집할 일수
            end_date: 종료 날짜 (YYYYMMDD 형식, None이면 오늘)
            
        Returns:
            수집된 매매동향 데이터 목록
        """
        if end_date is None:
            end_date = date.today().strftime("%Y%m%d")
        
        # 시작 날짜 계산 (영업일 기준 대략 계산)
        start_date_obj = datetime.strptime(end_date, "%Y%m%d") - timedelta(days=days*2)
        start_date = start_date_obj.strftime("%Y%m%d")
        
        logger.info(f"투자자별 매매동향 수집 시작: {start_date} ~ {end_date}, {days}일")
        
        # 종목코드 목록 준비
        if stock_codes is None:
            stock_codes = await self._get_all_stock_codes()
        
        # 유효한 종목코드만 필터링
        valid_codes = [code for code in stock_codes if self.validate_stock_code(code)]
        logger.info(f"수집 대상 종목: {len(valid_codes)}개")
        
        # 배치 수집 실행
        batch_results = await self.collect_batch_data(
            valid_codes,
            start_date=start_date,
            end_date=end_date,
            days=days
        )
        
        # 결과 통합
        all_data = []
        for stock_code, data_list in batch_results.items():
            all_data.extend(data_list)
        
        logger.info(f"투자자별 매매동향 수집 완료: {len(all_data)}건")
        return all_data
    
    async def collect_single_item(self, 
                                 stock_code: str,
                                 start_date: str,
                                 end_date: str,
                                 days: int,
                                 **kwargs) -> List[Dict[str, Any]]:
        """
        단일 종목 투자자별 매매동향 데이터 수집
        
        Args:
            stock_code: 종목코드
            start_date: 시작날짜 (YYYYMMDD)
            end_date: 종료날짜 (YYYYMMDD)
            days: 요청할 일수
            
        Returns:
            해당 종목의 매매동향 데이터 목록
        """
        try:
            logger.debug(f"투자자별 매매동향 수집: {stock_code} ({start_date}~{end_date})")
            
            # 실제 API 호출 대신 모의 데이터 생성 (개발용)
            if self.api_key.startswith("TEST_"):
                return await self._generate_mock_trading_data(stock_code, days)
            
            # 실제 API 호출
            params = {
                "FID_COND_MRKT_DIV_CODE": "J",  # 시장구분코드 (J: 주식)
                "FID_INPUT_ISCD": stock_code,   # 종목코드
                "FID_INPUT_DATE_1": start_date,  # 시작일자
                "FID_INPUT_DATE_2": end_date,    # 종료일자
                "FID_PERIOD_DIV_CODE": "D"       # 기간분류코드 (D: 일)
            }
            
            url = f"{self.base_url}{self.trading_endpoint}"
            headers = self._get_api_headers()
            
            response = await self._make_request("GET", url, params=params, headers=headers)
            
            return self._parse_trading_response(response, stock_code)
            
        except Exception as e:
            logger.error(f"투자자별 매매동향 수집 실패: {stock_code}, {e}")
            return []
    
    async def _generate_mock_trading_data(self, stock_code: str, days: int) -> List[Dict[str, Any]]:
        """모의 투자자별 매매동향 데이터 생성 (개발/테스트용)"""
        data = []
        
        for i in range(days):
            date_obj = date.today() - timedelta(days=i)
            
            # 해시를 이용한 의사 랜덤 데이터 생성
            base_seed = hash(f"{stock_code}{date_obj}")
            
            # 개인 투자자 (보통 순매도 경향)
            individual_buy = 500000000 + (base_seed % 200000000)
            individual_sell = individual_buy + (abs(base_seed >> 8) % 100000000)  # 보통 더 많이 매도
            individual_net = individual_buy - individual_sell
            
            # 기관 투자자 (보통 순매수 경향)
            institution_buy = 300000000 + (abs(base_seed >> 16) % 150000000)
            institution_sell = institution_buy - (abs(base_seed >> 24) % 50000000)  # 보통 더 적게 매도
            institution_net = institution_buy - institution_sell
            
            # 외국인 투자자 (변동성 큼)
            foreign_buy = 200000000 + (abs(base_seed >> 32) % 300000000)
            foreign_sell_variation = (base_seed >> 40) % 200000000
            if (base_seed >> 48) % 2 == 0:  # 50% 확률로 순매수/순매도
                foreign_sell = foreign_buy - abs(foreign_sell_variation)
            else:
                foreign_sell = foreign_buy + abs(foreign_sell_variation)
            foreign_net = foreign_buy - foreign_sell
            
            # 투신 및 연기금 (상대적으로 작은 규모)
            trust_buy = 80000000 + (abs(base_seed >> 56) % 40000000)
            trust_sell = trust_buy + ((base_seed >> 60) % 20000000) - 10000000
            trust_net = trust_buy - trust_sell
            
            pension_buy = 40000000 + (abs(base_seed >> 8) % 20000000)
            pension_sell = pension_buy + ((base_seed >> 16) % 10000000) - 5000000
            pension_net = pension_buy - pension_sell
            
            data.append({
                "stock_code": stock_code,
                "date": date_obj.strftime("%Y%m%d"),
                "individual_buy": str(max(0, individual_buy)),
                "individual_sell": str(max(0, individual_sell)),
                "individual_net": str(individual_net),
                "institution_buy": str(max(0, institution_buy)),
                "institution_sell": str(max(0, institution_sell)),
                "institution_net": str(institution_net),
                "foreign_buy": str(max(0, foreign_buy)),
                "foreign_sell": str(max(0, foreign_sell)),
                "foreign_net": str(foreign_net),
                "trust_buy": str(max(0, trust_buy)),
                "trust_sell": str(max(0, trust_sell)),
                "trust_net": str(trust_net),
                "pension_buy": str(max(0, pension_buy)),
                "pension_sell": str(max(0, pension_sell)),
                "pension_net": str(pension_net)
            })
        
        return data
    
    def _parse_trading_response(self, response: Dict, stock_code: str) -> List[Dict[str, Any]]:
        """투자자별 매매동향 API 응답 파싱"""
        try:
            if response.get("rt_cd") != "0":
                error_msg = response.get("msg1", "알 수 없는 오류")
                raise DataCollectionError(f"API 오류: {error_msg}")
            
            output_list = response.get("output", [])
            parsed_data = []
            
            for item in output_list:
                parsed_data.append({
                    "stock_code": stock_code,
                    "date": item.get("stck_bsop_date"),         # 영업일자
                    "individual_buy": item.get("prsn_ntby_qty"),      # 개인 순매수량
                    "individual_sell": item.get("prsn_shnu_qty"),     # 개인 순매도량  
                    "individual_net": item.get("prsn_ntby_qty"),      # 개인 순매수량
                    "institution_buy": item.get("inst_ntby_qty"),     # 기관 순매수량
                    "institution_sell": item.get("inst_shnu_qty"),    # 기관 순매도량
                    "institution_net": item.get("inst_ntby_qty"),     # 기관 순매수량
                    "foreign_buy": item.get("frgn_ntby_qty"),         # 외국인 순매수량
                    "foreign_sell": item.get("frgn_shnu_qty"),        # 외국인 순매도량
                    "foreign_net": item.get("frgn_ntby_qty"),         # 외국인 순매수량
                })
            
            return parsed_data
            
        except Exception as e:
            logger.error(f"투자자별 매매동향 응답 파싱 실패: {stock_code}, {e}")
            return []
    
    def validate_data(self, data: Dict[str, Any]) -> List[str]:
        """투자자별 매매동향 데이터 검증"""
        errors = []
        
        # 필수 필드 검증
        required_fields = [
            "stock_code", "date",
            "individual_buy", "individual_sell", "individual_net",
            "institution_buy", "institution_sell", "institution_net",
            "foreign_buy", "foreign_sell", "foreign_net"
        ]
        
        for field in required_fields:
            if field not in data or data[field] is None:
                errors.append(f"필수 필드 '{field}' 누락")
        
        # 종목코드 검증
        if "stock_code" in data and not self.validate_stock_code(data["stock_code"]):
            errors.append(f"유효하지 않은 종목코드: {data['stock_code']}")
        
        # 날짜 형식 검증
        if "date" in data and not self.validate_date_format(data["date"]):
            errors.append(f"유효하지 않은 날짜 형식: {data['date']}")
        
        # 매매금액 검증
        trading_fields = [
            "individual_buy", "individual_sell", 
            "institution_buy", "institution_sell",
            "foreign_buy", "foreign_sell"
        ]
        
        for field in trading_fields:
            if field in data:
                try:
                    amount = int(data[field])
                    if amount < 0:
                        errors.append(f"{field}가 음수: {amount}")
                except (ValueError, TypeError):
                    errors.append(f"{field}가 숫자가 아님: {data[field]}")
        
        # 순매수 금액 일관성 검증
        net_checks = [
            ("individual_buy", "individual_sell", "individual_net"),
            ("institution_buy", "institution_sell", "institution_net"),
            ("foreign_buy", "foreign_sell", "foreign_net")
        ]
        
        for buy_field, sell_field, net_field in net_checks:
            if all(field in data for field in [buy_field, sell_field, net_field]):
                try:
                    buy_amount = int(data[buy_field])
                    sell_amount = int(data[sell_field])
                    net_amount = int(data[net_field])
                    expected_net = buy_amount - sell_amount
                    
                    if abs(net_amount - expected_net) > 1000:  # 1000원 오차 허용
                        errors.append(f"{net_field} 불일치: 예상 {expected_net}, 실제 {net_amount}")
                        
                except (ValueError, TypeError):
                    pass  # 이미 위에서 검증함
        
        return errors
    
    async def _get_all_stock_codes(self) -> List[str]:
        """전체 종목코드 목록 조회"""
        try:
            async for session in get_db_session():
                stock_repo = StockInfoRepository(session)
                stocks = await stock_repo.get_all()
                return [stock.stock_code for stock in stocks]
        except Exception as e:
            logger.error(f"종목코드 목록 조회 실패: {e}")
            # 기본 종목코드 목록 반환
            return ["005930", "000660", "035420", "005380", "006400", "051910", "035720"]
    
    async def save_to_database(self, trading_data: List[Dict[str, Any]]) -> Dict[str, int]:
        """투자자별 매매동향 데이터를 데이터베이스에 저장"""
        try:
            async for session in get_db_session():
                trading_repo = InvestorTradingRepository(session)
                
                # 데이터 변환
                db_data = []
                for item in trading_data:
                    # 데이터 검증
                    validation_errors = self.validate_data(item)
                    if validation_errors:
                        logger.warning(f"데이터 검증 실패: {item}, 오류: {validation_errors}")
                        continue
                    
                    # 데이터베이스 형식으로 변환
                    db_item = {
                        "stock_code": item["stock_code"],
                        "date": datetime.strptime(item["date"], "%Y%m%d").date(),
                        "individual_buy": int(item["individual_buy"]),
                        "individual_sell": int(item["individual_sell"]),
                        "individual_net": int(item["individual_net"]),
                        "institution_buy": int(item["institution_buy"]),
                        "institution_sell": int(item["institution_sell"]),
                        "institution_net": int(item["institution_net"]),
                        "foreign_buy": int(item["foreign_buy"]),
                        "foreign_sell": int(item["foreign_sell"]),
                        "foreign_net": int(item["foreign_net"]),
                        "trust_buy": int(item.get("trust_buy", 0)),
                        "trust_sell": int(item.get("trust_sell", 0)),
                        "trust_net": int(item.get("trust_net", 0)),
                        "pension_buy": int(item.get("pension_buy", 0)),
                        "pension_sell": int(item.get("pension_sell", 0)),
                        "pension_net": int(item.get("pension_net", 0))
                    }
                    db_data.append(db_item)
                
                # 중복 제거
                duplicates = self.detect_duplicates(db_data, ["stock_code", "date"])
                unique_data = [item for item in db_data if item not in duplicates]
                
                # 데이터베이스 저장
                saved_count = await trading_repo.bulk_create(unique_data)
                
                logger.info(f"투자자별 매매동향 데이터 저장 완료: {saved_count}건 (중복 제거: {len(duplicates)}건)")
                
                return {
                    "total_received": len(trading_data),
                    "validation_passed": len(db_data),
                    "duplicates_removed": len(duplicates),
                    "saved_count": saved_count
                }
                
        except Exception as e:
            logger.error(f"투자자별 매매동향 데이터 저장 실패: {e}")
            return {
                "total_received": len(trading_data),
                "validation_passed": 0,
                "duplicates_removed": 0,
                "saved_count": 0,
                "error": str(e)
            }
    
    def analyze_trading_patterns(self, trading_data: List[Dict[str, Any]]) -> Dict[str, Any]:
        """매매 패턴 분석"""
        if not trading_data:
            return {}
        
        # 날짜순 정렬
        sorted_data = sorted(trading_data, key=lambda x: x["date"])
        
        analysis = {
            "period": {
                "start": sorted_data[0]["date"],
                "end": sorted_data[-1]["date"],
                "days": len(sorted_data)
            },
            "cumulative_net": {
                "individual": 0,
                "institution": 0,
                "foreign": 0,
                "institution_foreign": 0
            },
            "patterns": {
                "institution_foreign_buying_streak": 0,
                "individual_selling_streak": 0,
                "foreign_accumulation": False,
                "institutional_strength": 0.0
            },
            "daily_average": {}
        }
        
        # 누적 순매수 계산
        institution_foreign_positives = 0
        individual_negatives = 0
        
        for item in sorted_data:
            individual_net = int(item.get("individual_net", 0))
            institution_net = int(item.get("institution_net", 0))
            foreign_net = int(item.get("foreign_net", 0))
            
            analysis["cumulative_net"]["individual"] += individual_net
            analysis["cumulative_net"]["institution"] += institution_net
            analysis["cumulative_net"]["foreign"] += foreign_net
            analysis["cumulative_net"]["institution_foreign"] += (institution_net + foreign_net)
            
            # 패턴 분석
            if (institution_net + foreign_net) > 0:
                institution_foreign_positives += 1
            if individual_net < 0:
                individual_negatives += 1
        
        # 패턴 계산
        total_days = len(sorted_data)
        analysis["patterns"]["institution_foreign_buying_streak"] = institution_foreign_positives
        analysis["patterns"]["individual_selling_streak"] = individual_negatives
        analysis["patterns"]["foreign_accumulation"] = analysis["cumulative_net"]["foreign"] > 0
        
        # 기관 매수력 계산
        total_institution_trading = sum(
            int(item.get("institution_buy", 0)) + int(item.get("institution_sell", 0))
            for item in sorted_data
        )
        if total_institution_trading > 0:
            analysis["patterns"]["institutional_strength"] = (
                analysis["cumulative_net"]["institution"] / total_institution_trading
            )
        
        # 일평균 계산
        if total_days > 0:
            for key, value in analysis["cumulative_net"].items():
                analysis["daily_average"][key] = value / total_days
        
        return analysis

class InvestorTradingScheduler:
    """투자자별 매매동향 수집 스케줄러"""
    
    def __init__(self, collector: InvestorTradingCollector):
        """
        스케줄러 초기화
        
        Args:
            collector: 투자자별 매매동향 수집기
        """
        self.collector = collector
        self.is_running = False
        self.last_collection_time = None
        
        logger.info("투자자별 매매동향 수집 스케줄러 초기화 완료")
    
    async def run_daily_collection(self, 
                                  target_time: str = "19:00",
                                  stock_codes: List[str] = None,
                                  days: int = 60) -> Dict[str, Any]:
        """
        일일 투자자별 매매동향 수집 실행
        
        Args:
            target_time: 수집 시간 (HH:MM 형식)
            stock_codes: 대상 종목코드 (None이면 전체)
            days: 수집할 일수
            
        Returns:
            수집 결과
        """
        start_time = datetime.now()
        logger.info(f"일일 투자자별 매매동향 수집 시작: {start_time}")
        
        try:
            # 데이터 수집
            trading_data = await self.collector.collect_data(
                stock_codes=stock_codes,
                days=days
            )
            
            # 데이터베이스 저장
            save_result = await self.collector.save_to_database(trading_data)
            
            # 패턴 분석
            pattern_analysis = self.collector.analyze_trading_patterns(trading_data)
            
            end_time = datetime.now()
            duration = (end_time - start_time).total_seconds()
            
            self.last_collection_time = end_time
            
            result = {
                "collection_type": "daily_investor_trading",
                "start_time": start_time.isoformat(),
                "end_time": end_time.isoformat(),
                "duration_seconds": duration,
                "target_stocks": len(stock_codes) if stock_codes else "all",
                "collection_result": save_result,
                "pattern_analysis": pattern_analysis,
                "success": True
            }
            
            logger.info(f"일일 투자자별 매매동향 수집 완료: {duration:.2f}초, "
                       f"{save_result['saved_count']}건 저장")
            
            return result
            
        except Exception as e:
            logger.error(f"일일 투자자별 매매동향 수집 실패: {e}")
            
            return {
                "collection_type": "daily_investor_trading",
                "start_time": start_time.isoformat(),
                "error": str(e),
                "success": False
            }
    
    def get_collection_status(self) -> Dict[str, Any]:
        """수집 상태 조회"""
        return {
            "scheduler_type": "investor_trading_daily",
            "is_running": self.is_running,
            "last_collection_time": self.last_collection_time.isoformat() if self.last_collection_time else None,
            "next_collection_time": None  # 실제 스케줄러에서는 다음 실행 시간 계산
        }
