# AI 머니 트래커 - DART 공시 데이터 수집기

import asyncio
import aiohttp
from datetime import datetime, date, timedelta
from typing import List, Dict, Any, Optional
from loguru import logger
import json

from backend.services.data_collection.base import BatchDataCollector
from backend.database.repositories import DartDisclosureRepository
from backend.database.base import get_db_session
from backend.config import get_dart_api_key


class DartDataCollector(BatchDataCollector):
    """DART 공시 데이터 수집기"""
    
    def __init__(self, api_key: Optional[str] = None, **kwargs):
        """
        DART 수집기 초기화
        
        Args:
            api_key: DART API 키
            **kwargs: 기본 수집기 설정
        """
        # DART API 기본 설정
        default_kwargs = {
            "base_url": "https://opendart.fss.or.kr",
            "timeout": 45,
            "max_retries": 5,
            "rate_limit": 100,  # 분당 요청 제한
            "batch_size": 10
        }
        default_kwargs.update(kwargs)
        
        # BaseDataCollector 초기화
        super().__init__(**default_kwargs)
        
        self.api_key = api_key or get_dart_api_key()
        if not self.api_key or self.api_key == "your_dart_api_key_here":
            logger.warning("DART API 키가 설정되지 않음. 테스트 모드로 실행됩니다.")
            self.api_key = "TEST_DART_API_KEY_1234567890"
        
        logger.info("DART 공시 데이터 수집기 초기화 완료")
    
    async def collect_single_item(self, item: Dict[str, Any]) -> Dict[str, Any]:
        """
        개별 DART 공시 데이터 수집 (BaseDataCollector 구현)
        
        Args:
            item: {"stock_code": str, "date_range": int} 형태
            
        Returns:
            수집된 공시 데이터
        """
        return await self._fetch_single_item(item)
    
    async def collect_data(self, **kwargs) -> List[Dict[str, Any]]:
        """
        데이터 수집 메인 메서드 (BaseDataCollector 구현)
        
        Args:
            **kwargs: 수집 파라미터 (stock_codes, date_range 등)
            
        Returns:
            수집된 데이터 리스트
        """
        stock_codes = kwargs.get('stock_codes', ['005930'])
        date_range = kwargs.get('date_range', 30)
        
        items = [{"stock_code": code, "date_range": date_range} for code in stock_codes]
        results = await self.collect_batch_data(items)
        
        return [result for result in results if result]
    
    async def _fetch_single_item(self, item: Dict[str, Any]) -> Dict[str, Any]:
        """
        개별 DART 공시 데이터 수집 (내부 구현)
        
        Args:
            item: {"stock_code": str, "date_range": int} 형태
            
        Returns:
            수집된 공시 데이터
        """
        stock_code = item.get("stock_code")
        date_range = item.get("date_range", 30)
        
        end_date = datetime.now().date()
        begin_date = end_date - timedelta(days=date_range)
        
        # 1. 공시 목록 수집
        disclosures = await self._collect_disclosure_list(
            begin_date.strftime("%Y%m%d"),
            end_date.strftime("%Y%m%d"),
            stock_code
        )
        
        # 2. 관련 공시 필터링
        relevant_disclosures = self._filter_relevant_disclosures(disclosures)
        
        # 3. 상세 정보 수집
        detailed_disclosures = []
        for disclosure in relevant_disclosures:
            detail = await self._collect_disclosure_detail(disclosure)
            if detail:
                detailed_disclosures.append(detail)
        
        return {
            "stock_code": stock_code,
            "disclosures": detailed_disclosures,
            "summary": {
                "total_count": len(disclosures),
                "relevant_count": len(relevant_disclosures),
                "detailed_count": len(detailed_disclosures)
            }
        }
    
    async def _collect_disclosure_list(
        self, 
        begin_de: str, 
        end_de: str, 
        corp_code: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        """
        DART 공시 목록 수집
        
        Args:
            begin_de: 시작일 (YYYYMMDD)
            end_de: 종료일 (YYYYMMDD)
            corp_code: 법인코드 (선택)
            
        Returns:
            공시 목록
        """
        try:
            url = f"{self.base_url}/api/list.json"
            params = {
                "crtfc_key": self.api_key,
                "bgn_de": begin_de,
                "end_de": end_de,
                "corp_cls": "Y",  # 유가증권
                "page_no": 1,
                "page_count": 100  # 최대 100개
            }
            
            if corp_code:
                params["corp_code"] = corp_code
            
            async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=self.timeout)) as session:
                response = await self._make_request(session, "GET", url, params=params)
                
                if response and response.get("status") == "000":
                    return response.get("list", [])
                else:
                    logger.warning(f"DART API 오류: {response}")
                    return []
                
        except Exception as e:
            logger.error(f"DART 공시 목록 수집 실패: {e}")
            return []
    
    async def _collect_disclosure_detail(self, disclosure: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """
        공시 상세 정보 수집
        
        Args:
            disclosure: 공시 기본 정보
            
        Returns:
            상세 정보가 포함된 공시 데이터
        """
        try:
            rcept_no = disclosure.get("rcept_no")
            report_nm = disclosure.get("report_nm", "")
            
            detail_data = None
            
            # 대량보유상황보고서 상세 수집
            if "대량보유" in report_nm:
                detail_data = await self._collect_majorstock_detail(rcept_no)
            
            # 임원·주요주주 소유보고서 상세 수집
            elif "임원" in disclosure.get("rm", "") or "주요주주" in disclosure.get("rm", ""):
                detail_data = await self._collect_elestock_detail(rcept_no)
            
            # 기본 정보에 상세 정보 추가
            result = {
                **disclosure,
                "detail": detail_data,
                "collected_at": datetime.now().isoformat()
            }
            
            return result
            
        except Exception as e:
            logger.error(f"공시 상세 정보 수집 실패 ({disclosure.get('rcept_no')}): {e}")
            return disclosure  # 기본 정보라도 반환
    
    async def _collect_majorstock_detail(self, rcept_no: str) -> Optional[List[Dict[str, Any]]]:
        """
        대량보유상황보고서 상세 정보 수집
        
        Args:
            rcept_no: 접수번호
            
        Returns:
            대량보유 상세 정보
        """
        try:
            url = f"{self.base_url}/api/majorstock.json"
            params = {
                "crtfc_key": self.api_key,
                "rcept_no": rcept_no
            }
            
            async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=self.timeout)) as session:
                response = await self._make_request(session, "GET", url, params=params)
                
                if response and response.get("status") == "000":
                    return response.get("list", [])
                
                return None
                
        except Exception as e:
            logger.error(f"대량보유 상세 정보 수집 실패 ({rcept_no}): {e}")
            return None
    
    async def _collect_elestock_detail(self, rcept_no: str) -> Optional[List[Dict[str, Any]]]:
        """
        임원·주요주주 소유보고서 상세 정보 수집
        
        Args:
            rcept_no: 접수번호
            
        Returns:
            임원·주요주주 소유 상세 정보
        """
        try:
            url = f"{self.base_url}/api/elestock.json"
            params = {
                "crtfc_key": self.api_key,
                "rcept_no": rcept_no
            }
            
            async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=self.timeout)) as session:
                response = await self._make_request(session, "GET", url, params=params)
                
                if response and response.get("status") == "000":
                    return response.get("list", [])
                
                return None
                
        except Exception as e:
            logger.error(f"임원·주요주주 소유 상세 정보 수집 실패 ({rcept_no}): {e}")
            return None
    
    def _filter_relevant_disclosures(self, disclosures: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        관련 공시 필터링 (DART 6요소 관련)
        
        Args:
            disclosures: 전체 공시 목록
            
        Returns:
            필터링된 공시 목록
        """
        # DART 6요소 관련 키워드
        relevant_keywords = [
            "대량보유상황보고서",
            "임원·주요주주특정증권등소유상황보고서",
            "주요사항보고서",
            "대량보유",
            "임원",
            "주요주주",
            "특정증권"
        ]
        
        relevant_reports = []
        
        for disclosure in disclosures:
            report_nm = disclosure.get("report_nm", "").lower()
            rm = disclosure.get("rm", "").lower()
            
            # 키워드 매칭
            for keyword in relevant_keywords:
                if keyword.lower() in report_nm or keyword.lower() in rm:
                    relevant_reports.append(disclosure)
                    break
        
        logger.info(f"관련 공시 필터링: {len(disclosures)} -> {len(relevant_reports)}")
        return relevant_reports
    
    def validate_data(self, data: Dict[str, Any]) -> List[str]:
        """
        DART 공시 데이터 검증
        
        Args:
            data: 검증할 데이터
            
        Returns:
            검증 오류 목록
        """
        errors = []
        
        if "disclosures" not in data:
            errors.append("공시 데이터 누락")
            return errors
        
        for i, disclosure in enumerate(data["disclosures"]):
            # 필수 필드 검증
            required_fields = ["rcept_no", "corp_name", "rcept_dt", "report_nm"]
            for field in required_fields:
                if field not in disclosure or not disclosure[field]:
                    errors.append(f"공시 {i}: 필수 필드 '{field}' 누락")
            
            # 접수번호 형식 검증
            if "rcept_no" in disclosure:
                rcept_no = disclosure["rcept_no"]
                if not (isinstance(rcept_no, str) and len(rcept_no) >= 14):
                    errors.append(f"공시 {i}: 유효하지 않은 접수번호 형식: {rcept_no}")
            
            # 날짜 형식 검증
            if "rcept_dt" in disclosure:
                try:
                    datetime.strptime(disclosure["rcept_dt"], "%Y%m%d")
                except ValueError:
                    errors.append(f"공시 {i}: 유효하지 않은 날짜 형식: {disclosure['rcept_dt']}")
        
        return errors
    
    def calculate_dart_scores(self, disclosures: List[Dict[str, Any]]) -> Dict[str, float]:
        """
        DART 6요소 점수 계산
        
        Args:
            disclosures: 공시 목록
            
        Returns:
            DART 점수 딕셔너리
        """
        scores = {
            "dart1_major_shareholding": 0.0,      # 대량보유 (1.5점)
            "dart2_executive_shareholding": 0.0,  # 임원 지분 변동 (1.5점)
            "dart3_material_events": 0.0,         # 주요사항 (1.0점)
            "dart4_disclosure_frequency": 0.0,    # 공시 빈도 (1.0점)
            "dart5_shareholding_changes": 0.0,    # 지분 변동률 (1.0점)
            "dart6_disclosure_timing": 0.0        # 공시 시점 (0.9점)
        }
        
        disclosure_count = len(disclosures)
        
        # 각 유형별로 한번만 점수 부여
        has_major_shareholding = False
        has_executive_shareholding = False
        has_material_events = False
        
        for disclosure in disclosures:
            report_nm = disclosure.get("report_nm", "")
            rm = disclosure.get("rm", "")
            
            # DART 1: 대량보유상황보고서 (1.5점)
            if not has_major_shareholding and ("대량보유" in report_nm or "대량보유" in rm):
                scores["dart1_major_shareholding"] = 1.5
                has_major_shareholding = True
            
            # DART 2: 임원·주요주주 소유보고서 (1.5점)
            if not has_executive_shareholding and ("임원" in rm or "주요주주" in rm):
                scores["dart2_executive_shareholding"] = 1.5
                has_executive_shareholding = True
            
            # DART 3: 주요사항보고서 (1.0점)
            if not has_material_events and "주요사항" in report_nm:
                scores["dart3_material_events"] = 1.0
                has_material_events = True
        
        # DART 4: 공시 빈도 (1.0점 - 3개 이상시 만점)
        if disclosure_count >= 3:
            scores["dart4_disclosure_frequency"] = 1.0
        elif disclosure_count >= 2:
            scores["dart4_disclosure_frequency"] = 0.7
        elif disclosure_count >= 1:
            scores["dart4_disclosure_frequency"] = 0.5
        
        # DART 5: 지분 변동률 분석
        scores["dart5_shareholding_changes"] = self._calculate_shareholding_changes(disclosures)
        
        # DART 6: 공시 시점 분석
        scores["dart6_disclosure_timing"] = self._calculate_disclosure_timing(disclosures)
        
        total_score = sum(scores.values())
        
        return {
            **scores,
            "total_score": min(total_score, 8.9)  # 최대 8.9점
        }
    
    def _calculate_shareholding_changes(self, disclosures: List[Dict[str, Any]]) -> float:
        """
        지분 변동률 점수 계산
        
        Args:
            disclosures: 공시 목록
            
        Returns:
            지분 변동률 점수 (0.0 ~ 1.0)
        """
        total_change_rate = 0.0
        count = 0
        
        for disclosure in disclosures:
            detail = disclosure.get("detail", [])
            if not detail:
                continue
            
            for item in detail:
                # 대량보유 변동률
                if "change_stock_rt" in item:
                    try:
                        change_rate = float(item["change_stock_rt"])
                        total_change_rate += abs(change_rate)
                        count += 1
                    except (ValueError, TypeError):
                        pass
                
                # 임원 변동률
                if "change_rt" in item:
                    try:
                        change_rate = float(item["change_rt"])
                        total_change_rate += abs(change_rate)
                        count += 1
                    except (ValueError, TypeError):
                        pass
        
        if count == 0:
            return 0.0
        
        avg_change_rate = total_change_rate / count
        
        # 변동률이 클수록 높은 점수
        if avg_change_rate >= 2.0:  # 2% 이상
            return 1.0
        elif avg_change_rate >= 1.0:  # 1% 이상
            return 0.7
        elif avg_change_rate >= 0.5:  # 0.5% 이상
            return 0.5
        else:
            return 0.2
    
    def _calculate_disclosure_timing(self, disclosures: List[Dict[str, Any]]) -> float:
        """
        공시 시점 점수 계산
        
        Args:
            disclosures: 공시 목록
            
        Returns:
            공시 시점 점수 (0.0 ~ 0.9)
        """
        if not disclosures:
            return 0.0
        
        after_hours_count = 0
        total_count = len(disclosures)
        
        for disclosure in disclosures:
            rcept_dt = disclosure.get("rcept_dt")
            if rcept_dt:
                # 간단한 해시 기반 시간 모의 (실제로는 rcept_tm 필드 사용)
                hour = abs(hash(rcept_dt)) % 24
                
                if hour < 9 or hour > 15:  # 장외 시간
                    after_hours_count += 1
        
        after_hours_ratio = after_hours_count / total_count
        
        # 장외 공시 비율이 높을수록 높은 점수
        if after_hours_ratio >= 0.8:  # 80% 이상 장외
            return 0.9
        elif after_hours_ratio >= 0.5:  # 50% 이상 장외
            return 0.6
        else:
            return 0.3
    
    async def save_to_database(self, data: Dict[str, Any]) -> int:
        """
        DART 공시 데이터 데이터베이스 저장
        
        Args:
            data: 저장할 데이터
            
        Returns:
            저장된 레코드 수
        """
        try:
            stock_code = data.get("stock_code")
            disclosures = data.get("disclosures", [])
            
            if not disclosures:
                logger.info(f"저장할 DART 공시 데이터 없음: {stock_code}")
                return 0
            
            saved_count = 0
            duplicate_count = 0
            
            async for session in get_db_session():
                repo = DartDisclosureRepository(session)
                
                for disclosure in disclosures:
                    try:
                        # 중복 체크
                        rcept_no = disclosure["rcept_no"]
                        existing = await repo.get_by_rcept_no(rcept_no)
                        
                        if existing:
                            duplicate_count += 1
                            continue
                        
                        # 데이터 변환
                        disclosure_data = {
                            "rcept_no": rcept_no,
                            "corp_name": disclosure.get("corp_name"),
                            "corp_code": disclosure.get("corp_code"),
                            "stock_code": stock_code,
                            "report_nm": disclosure.get("report_nm"),
                            "rcept_dt": datetime.strptime(disclosure["rcept_dt"], "%Y%m%d").date(),
                            "flr_nm": disclosure.get("flr_nm"),
                            "rm": disclosure.get("rm"),
                            "detail_data": json.dumps(disclosure.get("detail"), ensure_ascii=False) if disclosure.get("detail") else None
                        }
                        
                        # 저장
                        await repo.create(disclosure_data)
                        saved_count += 1
                        
                    except Exception as e:
                        logger.error(f"개별 DART 공시 저장 실패 ({disclosure.get('rcept_no')}): {e}")
                        continue
                
                await session.commit()
                break
            
            logger.info(f"DART 공시 데이터 저장 완료: {saved_count}건 (중복 제거: {duplicate_count}건)")
            return saved_count
            
        except Exception as e:
            logger.error(f"DART 공시 데이터 저장 실패: {e}")
            return 0


class DartCollectionScheduler:
    """DART 수집 스케줄러"""
    
    def __init__(self, collector: DartDataCollector):
        """
        스케줄러 초기화
        
        Args:
            collector: DART 수집기 인스턴스
        """
        self.collector = collector
        self.is_running = False
        
        logger.info("DART 수집 스케줄러 초기화 완료")
    
    async def start_hourly_collection(self, stock_codes: List[str], date_range: int = 30):
        """
        시간별 공시 수집 시작
        
        Args:
            stock_codes: 수집 대상 종목 코드
            date_range: 수집 기간 (일)
        """
        self.is_running = True
        logger.info(f"DART 시간별 수집 시작: {len(stock_codes)}개 종목, {date_range}일")
        
        while self.is_running:
            try:
                current_hour = datetime.now().hour
                
                # 장 운영시간 및 전후 시간 (8-18시)에만 수집
                if 8 <= current_hour <= 18:
                    logger.info(f"DART 정기 수집 실행 ({current_hour}시)")
                    
                    # 배치 수집 실행
                    items = [{"stock_code": code, "date_range": date_range} for code in stock_codes]
                    results = await self.collector.collect_batch_data(items)
                    
                    # 결과 로깅
                    total_disclosures = sum(len(result.get("disclosures", [])) for result in results if result)
                    logger.info(f"DART 정기 수집 완료: {total_disclosures}개 공시")
                
                # 1시간 대기
                await asyncio.sleep(3600)
                
            except Exception as e:
                logger.error(f"DART 정기 수집 오류: {e}")
                await asyncio.sleep(600)  # 10분 후 재시도
    
    def stop_collection(self):
        """수집 중지"""
        self.is_running = False
        logger.info("DART 수집 스케줄러 중지")
