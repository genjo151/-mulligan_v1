# AI 머니 트래커 - 통합 분석 엔진

import asyncio
from datetime import datetime, date, timedelta
from typing import List, Dict, Any, Optional, Tuple
from dataclasses import dataclass, field
from enum import Enum
from loguru import logger
import json

from backend.database.base import get_db_session
from backend.database.repositories import (
    StockInfoRepository, DailyPriceRepository, InvestorTradingRepository, 
    DartDisclosureRepository, StockScoreRepository
)
from backend.services.stock_api import StockApiClient, StockDataProcessor
from backend.services.dart_api import DartApiClient, DartDataProcessor


class RecommendationLevel(Enum):
    """추천 등급"""
    STRONG_BUY = "강력추천"
    BUY = "추천"
    WATCH = "관심"
    HOLD = "보류"
    DISQUALIFIED = "부적격"


class EventType(Enum):
    """이벤트 유형"""
    EARNINGS_ANNOUNCEMENT = "earnings_announcement"
    REBALANCING = "rebalancing"
    NEWS_SURGE = "news_surge"
    DIVIDEND_PAYMENT = "dividend_payment"
    STOCK_SPLIT = "stock_split"


@dataclass
class UnifiedScoreBreakdown:
    """통합 점수 세부사항"""
    total_score: float
    core_score: float
    dart_score: float
    core_elements_met: int
    dart_elements_met: int
    meets_minimum_requirements: bool
    grade: str
    core_scores: Dict[str, float] = field(default_factory=dict)
    dart_scores: Dict[str, float] = field(default_factory=dict)
    weights: Dict[str, float] = field(default_factory=dict)


@dataclass
class PatternValidation:
    """패턴 검증 결과"""
    pattern_validated: bool
    occurrence_count: int
    required_count: int
    recent_analyses_count: int
    trend: str
    qualified_analyses: List[Dict[str, Any]] = field(default_factory=list)
    validation_date: date = field(default_factory=date.today)
    next_validation_date: date = field(default_factory=lambda: date.today() + timedelta(days=1))


@dataclass
class EventExclusion:
    """이벤트 제외 결과"""
    should_exclude: bool
    exclusion_reasons: List[Dict[str, Any]] = field(default_factory=list)
    analysis_date: date = field(default_factory=date.today)
    stock_code: str = ""


@dataclass
class UnifiedAnalysisResult:
    """통합 분석 결과"""
    stock_code: str
    stock_name: str
    analysis_date: date
    timestamp: datetime
    status: str
    
    # 분석 결과
    core_analysis: Dict[str, Any] = field(default_factory=dict)
    dart_analysis: Dict[str, Any] = field(default_factory=dict)
    unified_score: UnifiedScoreBreakdown = None
    pattern_validation: PatternValidation = None
    event_exclusion: EventExclusion = None
    
    # 최종 결과
    recommendation: RecommendationLevel = RecommendationLevel.DISQUALIFIED
    confidence_level: str = "low"
    risk_level: str = "high"
    
    # 추가 정보
    analysis_summary: Dict[str, Any] = field(default_factory=dict)
    error_message: Optional[str] = None


class UnifiedAnalysisEngine:
    """통합 분석 엔진"""
    
    def __init__(self):
        """엔진 초기화"""
        self.config = {
            "max_total_score": 8.9,
            "core_weight": 0.6,      # 60%
            "dart_weight": 0.4,      # 40%
            "pattern_threshold": 2,   # 최소 2회 출현
            "minimum_core_count": 3,  # 최소 3개 코어 요소 충족
            "minimum_total_score": 3.0,  # 최소 총점
            "exclusion_days": 2       # 이벤트 전후 제외 일수
        }
        
        self.core_max_score = 5.0
        self.dart_max_score = 3.9
        
        logger.info("통합 분석 엔진 초기화 완료")
    
    async def analyze_stock(
        self,
        stock_code: str,
        analysis_date: date = None,
        force_analysis: bool = False
    ) -> UnifiedAnalysisResult:
        """
        종목 통합 분석 실행
        
        Args:
            stock_code: 분석할 종목 코드
            analysis_date: 분석 기준일 (None이면 오늘)
            force_analysis: 이벤트 제외 조건 무시하고 강제 분석
            
        Returns:
            통합 분석 결과
        """
        if analysis_date is None:
            analysis_date = date.today()
        
        logger.info(f"통합 분석 시작: {stock_code}, 기준일: {analysis_date}")
        
        try:
            # 1. 기본 종목 정보 조회
            stock_info = await self._get_stock_info(stock_code)
            if not stock_info:
                return UnifiedAnalysisResult(
                    stock_code=stock_code,
                    stock_name="알 수 없음",
                    analysis_date=analysis_date,
                    timestamp=datetime.now(),
                    status="error",
                    error_message="종목 정보를 찾을 수 없습니다"
                )
            
            result = UnifiedAnalysisResult(
                stock_code=stock_code,
                stock_name=stock_info.get("stock_name", ""),
                analysis_date=analysis_date,
                timestamp=datetime.now(),
                status="processing"
            )
            
            # 2. 이벤트 제외 검사
            if not force_analysis:
                event_exclusion = await self._check_event_exclusion(stock_code, analysis_date)
                result.event_exclusion = event_exclusion
                
                if event_exclusion.should_exclude:
                    result.status = "excluded"
                    result.error_message = f"이벤트 제외: {', '.join([r['event_type'] for r in event_exclusion.exclusion_reasons])}"
                    logger.info(f"분석 제외: {stock_code}, 사유: {result.error_message}")
                    return result
            
            # 3. 코어 5요소 분석
            core_analysis = await self._analyze_core_elements(stock_code, analysis_date)
            result.core_analysis = core_analysis
            
            # 4. DART 6요소 분석
            dart_analysis = await self._analyze_dart_elements(stock_code, analysis_date)
            result.dart_analysis = dart_analysis
            
            # 5. 통합 점수 계산
            unified_score = self._calculate_unified_score(
                core_analysis.get("scores", {}),
                dart_analysis.get("scores", {})
            )
            result.unified_score = unified_score
            
            # 6. 패턴 검증
            pattern_validation = await self._validate_pattern(stock_code, unified_score)
            result.pattern_validation = pattern_validation
            
            # 7. 최종 추천 등급 결정
            recommendation = self._determine_recommendation(unified_score, pattern_validation)
            result.recommendation = recommendation
            
            # 8. 신뢰도 및 위험도 평가
            result.confidence_level = self._assess_confidence_level(pattern_validation, unified_score)
            result.risk_level = self._assess_risk_level(unified_score, core_analysis, dart_analysis)
            
            # 9. 분석 요약 생성
            result.analysis_summary = self._generate_analysis_summary(result)
            
            # 10. 결과 저장
            await self._save_analysis_result(result)
            
            result.status = "completed"
            logger.info(f"통합 분석 완료: {stock_code}, 점수: {unified_score.total_score}, 추천: {recommendation.value}")
            
            return result
            
        except Exception as e:
            logger.error(f"통합 분석 실패: {stock_code}, {e}")
            return UnifiedAnalysisResult(
                stock_code=stock_code,
                stock_name=stock_info.get("stock_name", "") if 'stock_info' in locals() else "",
                analysis_date=analysis_date,
                timestamp=datetime.now(),
                status="error",
                error_message=str(e)
            )
    
    async def _get_stock_info(self, stock_code: str) -> Optional[Dict[str, Any]]:
        """종목 기본 정보 조회"""
        try:
            async for session in get_db_session():
                stock_repo = StockInfoRepository(session)
                stock = await stock_repo.get_by_stock_code(stock_code)
                
                if stock:
                    return {
                        "stock_code": stock.stock_code,
                        "stock_name": stock.stock_name,
                        "market_type": stock.market_type,
                        "sector": stock.sector
                    }
                
                # 데이터베이스에 없으면 새로 생성
                new_stock = await stock_repo.create({
                    "stock_code": stock_code,
                    "stock_name": f"종목_{stock_code}",
                    "market_type": "KOSPI" if stock_code.startswith("00") else "KOSDAQ",
                    "sector": "기타"
                })
                
                return {
                    "stock_code": new_stock.stock_code,
                    "stock_name": new_stock.stock_name,
                    "market_type": new_stock.market_type,
                    "sector": new_stock.sector
                }
                
        except Exception as e:
            logger.error(f"종목 정보 조회 실패: {stock_code}, {e}")
            return None
    
    async def _check_event_exclusion(self, stock_code: str, analysis_date: date) -> EventExclusion:
        """이벤트 제외 검사"""
        exclusion_reasons = []
        
        try:
            # 실제로는 데이터베이스에서 이벤트 정보를 조회
            # 여기서는 간단한 예시로 구현
            
            # 주요 이벤트 날짜들 (실제로는 동적으로 조회)
            events = [
                # 매월 첫째 주 금요일: ETF 리밸런싱
                # 분기별 둘째 주: 실적발표 시즌
                # 기타 이벤트들...
            ]
            
            for event in events:
                event_date = event.get("event_date")
                event_type = event.get("event_type")
                
                if not event_date:
                    continue
                
                # 이벤트 전후 제외 기간 계산
                exclusion_start = event_date - timedelta(days=self.config["exclusion_days"])
                exclusion_end = event_date + timedelta(days=self.config["exclusion_days"])
                
                if exclusion_start <= analysis_date <= exclusion_end:
                    exclusion_reasons.append({
                        "event_type": event_type,
                        "event_date": event_date,
                        "days_from_event": (analysis_date - event_date).days,
                        "description": event.get("description", "")
                    })
            
        except Exception as e:
            logger.error(f"이벤트 제외 검사 실패: {stock_code}, {e}")
        
        return EventExclusion(
            should_exclude=len(exclusion_reasons) > 0,
            exclusion_reasons=exclusion_reasons,
            analysis_date=analysis_date,
            stock_code=stock_code
        )
    
    async def _analyze_core_elements(self, stock_code: str, analysis_date: date) -> Dict[str, Any]:
        """코어 5요소 분석"""
        try:
            # 기존 StockDataProcessor 활용
            processor = StockDataProcessor()
            
            # API 클라이언트를 통해 데이터 조회 (실제로는 데이터베이스에서)
            # 여기서는 더미 데이터로 구현
            
            scores = {
                "core1_institution_foreign_60d": 1.2,
                "core2_obv_uptrend_60d": 0.8,
                "core3_volatility_squeeze": 1.5,
                "core4_relative_strength": 1.0,
                "core5_accumulation_candles": 0.9
            }
            
            elements_met = sum(1 for score in scores.values() if score > 0)
            total_score = sum(scores.values())
            
            return {
                "scores": scores,
                "total": total_score,
                "elements_met": elements_met,
                "analysis_date": analysis_date,
                "data_quality": "good"
            }
            
        except Exception as e:
            logger.error(f"코어 5요소 분석 실패: {stock_code}, {e}")
            return {
                "scores": {},
                "total": 0.0,
                "elements_met": 0,
                "analysis_date": analysis_date,
                "data_quality": "error",
                "error": str(e)
            }
    
    async def _analyze_dart_elements(self, stock_code: str, analysis_date: date) -> Dict[str, Any]:
        """DART 6요소 분석"""
        try:
            # 기존 DartDataProcessor 활용
            # 실제로는 데이터베이스에서 DART 공시 데이터를 조회
            
            scores = {
                "dart1_major_shareholding": 1.5,
                "dart2_executive_shareholding": 0.0,
                "dart3_material_events": 0.8,
                "dart4_disclosure_frequency": 0.6,
                "dart5_ownership_change_rate": 1.0,
                "dart6_disclosure_timing": 0.5
            }
            
            elements_met = sum(1 for score in scores.values() if score > 0)
            total_score = sum(scores.values())
            
            return {
                "scores": scores,
                "total": total_score,
                "elements_met": elements_met,
                "analysis_date": analysis_date,
                "data_quality": "good"
            }
            
        except Exception as e:
            logger.error(f"DART 6요소 분석 실패: {stock_code}, {e}")
            return {
                "scores": {},
                "total": 0.0,
                "elements_met": 0,
                "analysis_date": analysis_date,
                "data_quality": "error",
                "error": str(e)
            }
    
    def _calculate_unified_score(
        self,
        core_scores: Dict[str, float],
        dart_scores: Dict[str, float]
    ) -> UnifiedScoreBreakdown:
        """통합 점수 계산"""
        
        # 1. 코어 5요소 정규화 (5점 만점)
        core_total = sum(core_scores.values())
        core_normalized = min(core_total / self.core_max_score, 1.0) * self.core_max_score
        
        # 2. DART 6요소 정규화 (3.9점 만점)
        dart_total = sum(dart_scores.values())
        dart_normalized = min(dart_total / self.dart_max_score, 1.0) * self.dart_max_score
        
        # 3. 가중 평균으로 최종 점수 계산
        weighted_score = (
            core_normalized * self.config["core_weight"] +
            dart_normalized * self.config["dart_weight"]
        ) * self.config["max_total_score"] / self.core_max_score
        
        # 4. 요소 충족 개수 계산
        core_elements_met = sum(1 for score in core_scores.values() if score > 0)
        dart_elements_met = sum(1 for score in dart_scores.values() if score > 0)
        
        # 5. 최소 조건 검증
        meets_minimum_requirements = (
            core_elements_met >= self.config["minimum_core_count"] and
            weighted_score >= self.config["minimum_total_score"]
        )
        
        # 6. 등급 계산
        grade = self._calculate_grade(weighted_score)
        
        return UnifiedScoreBreakdown(
            total_score=round(weighted_score, 2),
            core_score=round(core_normalized, 2),
            dart_score=round(dart_normalized, 2),
            core_elements_met=core_elements_met,
            dart_elements_met=dart_elements_met,
            meets_minimum_requirements=meets_minimum_requirements,
            grade=grade,
            core_scores=core_scores,
            dart_scores=dart_scores,
            weights={
                "core": self.config["core_weight"],
                "dart": self.config["dart_weight"]
            }
        )
    
    def _calculate_grade(self, score: float) -> str:
        """등급 계산"""
        percentage = (score / self.config["max_total_score"]) * 100
        
        if percentage >= 90:
            return "A+"
        elif percentage >= 85:
            return "A"
        elif percentage >= 80:
            return "B+"
        elif percentage >= 75:
            return "B"
        elif percentage >= 70:
            return "C+"
        elif percentage >= 65:
            return "C"
        elif percentage >= 60:
            return "D"
        else:
            return "F"
    
    async def _validate_pattern(self, stock_code: str, unified_score: UnifiedScoreBreakdown) -> PatternValidation:
        """패턴 검증"""
        try:
            # 60일 내 분석 이력 조회
            cutoff_date = date.today() - timedelta(days=60)
            
            # 실제로는 데이터베이스에서 조회
            # 여기서는 더미 데이터로 구현
            qualified_analyses = [
                {
                    "analysis_date": date.today() - timedelta(days=10),
                    "total_score": 7.2,
                    "meets_requirements": True
                },
                {
                    "analysis_date": date.today() - timedelta(days=35),
                    "total_score": 6.8,
                    "meets_requirements": True
                },
                {
                    "analysis_date": date.today() - timedelta(days=50),
                    "total_score": 5.9,
                    "meets_requirements": True
                }
            ]
            
            occurrence_count = len(qualified_analyses)
            pattern_validated = occurrence_count >= self.config["pattern_threshold"]
            
            # 트렌드 분석
            if len(qualified_analyses) >= 2:
                recent_scores = [a["total_score"] for a in qualified_analyses[-3:]]
                trend = "improving" if recent_scores[-1] > recent_scores[0] else "declining"
            else:
                trend = "insufficient_data"
            
            return PatternValidation(
                pattern_validated=pattern_validated,
                occurrence_count=occurrence_count,
                required_count=self.config["pattern_threshold"],
                recent_analyses_count=len(qualified_analyses),
                trend=trend,
                qualified_analyses=qualified_analyses
            )
            
        except Exception as e:
            logger.error(f"패턴 검증 실패: {stock_code}, {e}")
            return PatternValidation(
                pattern_validated=False,
                occurrence_count=0,
                required_count=self.config["pattern_threshold"],
                recent_analyses_count=0,
                trend="error"
            )
    
    def _determine_recommendation(
        self,
        unified_score: UnifiedScoreBreakdown,
        pattern_validation: PatternValidation
    ) -> RecommendationLevel:
        """최종 추천 등급 결정"""
        
        # 기본 자격 요건 확인
        if not unified_score.meets_minimum_requirements:
            return RecommendationLevel.DISQUALIFIED
        
        if not pattern_validation.pattern_validated:
            return RecommendationLevel.DISQUALIFIED
        
        # 점수 기반 추천 등급
        total_score = unified_score.total_score
        
        if total_score >= 7.5:
            return RecommendationLevel.STRONG_BUY
        elif total_score >= 6.0:
            return RecommendationLevel.BUY
        elif total_score >= 4.5:
            return RecommendationLevel.WATCH
        elif total_score >= 3.0:
            return RecommendationLevel.HOLD
        else:
            return RecommendationLevel.DISQUALIFIED
    
    def _assess_confidence_level(
        self,
        pattern_validation: PatternValidation,
        unified_score: UnifiedScoreBreakdown
    ) -> str:
        """신뢰도 평가"""
        confidence_factors = 0
        
        # 패턴 검증 신뢰도
        if pattern_validation.pattern_validated:
            confidence_factors += 1
        if pattern_validation.occurrence_count >= 3:
            confidence_factors += 1
        if pattern_validation.trend == "improving":
            confidence_factors += 1
        
        # 점수 신뢰도
        if unified_score.core_elements_met >= 4:
            confidence_factors += 1
        if unified_score.dart_elements_met >= 3:
            confidence_factors += 1
        
        if confidence_factors >= 4:
            return "high"
        elif confidence_factors >= 2:
            return "medium"
        else:
            return "low"
    
    def _assess_risk_level(
        self,
        unified_score: UnifiedScoreBreakdown,
        core_analysis: Dict[str, Any],
        dart_analysis: Dict[str, Any]
    ) -> str:
        """위험도 평가"""
        risk_factors = 0
        
        # 점수 기반 위험도
        if unified_score.total_score < 5.0:
            risk_factors += 1
        if unified_score.core_elements_met < 3:
            risk_factors += 1
        if unified_score.dart_elements_met < 2:
            risk_factors += 1
        
        # 데이터 품질 위험도
        if core_analysis.get("data_quality") != "good":
            risk_factors += 1
        if dart_analysis.get("data_quality") != "good":
            risk_factors += 1
        
        if risk_factors >= 3:
            return "high"
        elif risk_factors >= 1:
            return "medium"
        else:
            return "low"
    
    def _generate_analysis_summary(self, result: UnifiedAnalysisResult) -> Dict[str, Any]:
        """분석 요약 생성"""
        return {
            "total_elements": result.unified_score.core_elements_met + result.unified_score.dart_elements_met,
            "score_percentile": round((result.unified_score.total_score / self.config["max_total_score"]) * 100, 1),
            "strength_areas": self._identify_strength_areas(result),
            "improvement_areas": self._identify_improvement_areas(result),
            "key_indicators": {
                "pattern_frequency": result.pattern_validation.occurrence_count,
                "trend_direction": result.pattern_validation.trend,
                "core_coverage": round((result.unified_score.core_elements_met / 5) * 100, 1),
                "dart_coverage": round((result.unified_score.dart_elements_met / 6) * 100, 1)
            }
        }
    
    def _identify_strength_areas(self, result: UnifiedAnalysisResult) -> List[str]:
        """강점 영역 식별"""
        strengths = []
        
        # 코어 요소 강점
        for element, score in result.unified_score.core_scores.items():
            if score >= 1.0:
                strengths.append(f"코어_{element.split('_')[0]}")
        
        # DART 요소 강점
        for element, score in result.unified_score.dart_scores.items():
            if score >= 1.0:
                strengths.append(f"DART_{element.split('_')[0]}")
        
        return strengths[:3]  # 상위 3개만 반환
    
    def _identify_improvement_areas(self, result: UnifiedAnalysisResult) -> List[str]:
        """개선 영역 식별"""
        improvements = []
        
        # 코어 요소 개선점
        for element, score in result.unified_score.core_scores.items():
            if score == 0:
                improvements.append(f"코어_{element.split('_')[0]}")
        
        # DART 요소 개선점
        for element, score in result.unified_score.dart_scores.items():
            if score == 0:
                improvements.append(f"DART_{element.split('_')[0]}")
        
        return improvements[:3]  # 상위 3개만 반환
    
    async def _save_analysis_result(self, result: UnifiedAnalysisResult):
        """분석 결과 저장"""
        try:
            async for session in get_db_session():
                score_repo = StockScoreRepository(session)
                
                # 점수 데이터 생성
                score_data = {
                    "stock_code": result.stock_code,
                    "date": result.analysis_date,
                    "core1_score": result.unified_score.core_scores.get("core1_institution_foreign_60d", 0),
                    "core2_score": result.unified_score.core_scores.get("core2_obv_uptrend_60d", 0),
                    "core3_score": result.unified_score.core_scores.get("core3_volatility_squeeze", 0),
                    "core4_score": result.unified_score.core_scores.get("core4_relative_strength", 0),
                    "core5_score": result.unified_score.core_scores.get("core5_accumulation_candles", 0),
                    "dart1_score": result.unified_score.dart_scores.get("dart1_major_shareholding", 0),
                    "dart2_score": result.unified_score.dart_scores.get("dart2_executive_shareholding", 0),
                    "dart3_score": result.unified_score.dart_scores.get("dart3_material_events", 0),
                    "dart4_score": result.unified_score.dart_scores.get("dart4_disclosure_frequency", 0),
                    "dart5_score": result.unified_score.dart_scores.get("dart5_ownership_change_rate", 0),
                    "dart6_score": result.unified_score.dart_scores.get("dart6_disclosure_timing", 0),
                    "total_score": result.unified_score.total_score,
                    "recommendation": result.recommendation.value,
                    "confidence_level": result.confidence_level,
                    "analysis_metadata": json.dumps(result.analysis_summary, ensure_ascii=False)
                }
                
                await score_repo.create_or_update_by_stock_and_date(
                    result.stock_code,
                    result.analysis_date,
                    score_data
                )
                
                logger.info(f"분석 결과 저장 완료: {result.stock_code}")
                break
                
        except Exception as e:
            logger.error(f"분석 결과 저장 실패: {result.stock_code}, {e}")


class RecommendationEngine:
    """추천 엔진"""
    
    def __init__(self):
        """추천 엔진 초기화"""
        self.config = {
            "max_portfolio_size": 20,
            "min_score_threshold": 5.0,
            "diversification_enabled": True,
            "max_sector_concentration": 0.3  # 섹터별 최대 30%
        }
        
        logger.info("추천 엔진 초기화 완료")
    
    async def get_ranked_stocks(
        self,
        analysis_date: date = None,
        min_score: float = None,
        max_results: int = 50
    ) -> List[Dict[str, Any]]:
        """종목 랭킹 조회"""
        if analysis_date is None:
            analysis_date = date.today()
        
        if min_score is None:
            min_score = self.config["min_score_threshold"]
        
        try:
            async for session in get_db_session():
                score_repo = StockScoreRepository(session)
                
                # 최신 분석 결과 조회
                scores = await score_repo.get_latest_scores_by_date(analysis_date, min_score)
                
                # 랭킹 생성
                ranked_stocks = sorted(
                    scores,
                    key=lambda x: (x.total_score, x.core1_score + x.core2_score + x.core3_score + x.core4_score + x.core5_score),
                    reverse=True
                )[:max_results]
                
                # 랭킹 정보 추가
                result = []
                for i, stock in enumerate(ranked_stocks):
                    result.append({
                        "rank": i + 1,
                        "stock_code": stock.stock_code,
                        "total_score": stock.total_score,
                        "recommendation": stock.recommendation,
                        "confidence_level": stock.confidence_level,
                        "percentile": round((len(ranked_stocks) - i) / len(ranked_stocks) * 100, 1),
                        "analysis_date": stock.date
                    })
                
                return result
                
        except Exception as e:
            logger.error(f"종목 랭킹 조회 실패: {e}")
            return []
    
    async def generate_portfolio_recommendation(
        self,
        target_size: int = 10,
        risk_tolerance: str = "medium"
    ) -> Dict[str, Any]:
        """포트폴리오 추천 생성"""
        try:
            # 최신 랭킹 조회
            ranked_stocks = await self.get_ranked_stocks()
            
            if not ranked_stocks:
                return {
                    "portfolio_stocks": [],
                    "portfolio_size": 0,
                    "message": "추천 가능한 종목이 없습니다"
                }
            
            # 위험 허용도에 따른 필터링
            risk_filters = {
                "conservative": {"min_score": 6.5, "min_confidence": "high"},
                "medium": {"min_score": 5.5, "min_confidence": "medium"},
                "aggressive": {"min_score": 4.5, "min_confidence": "low"}
            }
            
            filter_criteria = risk_filters.get(risk_tolerance, risk_filters["medium"])
            
            # 필터링된 종목 선택
            qualified_stocks = [
                stock for stock in ranked_stocks
                if stock["total_score"] >= filter_criteria["min_score"]
            ]
            
            # 포트폴리오 구성 (상위 종목 선택)
            portfolio_stocks = qualified_stocks[:target_size]
            
            # 포트폴리오 통계 계산
            if portfolio_stocks:
                avg_score = sum(s["total_score"] for s in portfolio_stocks) / len(portfolio_stocks)
                score_range = {
                    "min": min(s["total_score"] for s in portfolio_stocks),
                    "max": max(s["total_score"] for s in portfolio_stocks)
                }
            else:
                avg_score = 0
                score_range = {"min": 0, "max": 0}
            
            return {
                "portfolio_stocks": portfolio_stocks,
                "portfolio_size": len(portfolio_stocks),
                "statistics": {
                    "average_score": round(avg_score, 2),
                    "score_range": score_range,
                    "risk_tolerance": risk_tolerance,
                    "qualified_candidates": len(qualified_stocks)
                },
                "recommendation_date": date.today(),
                "rebalancing_frequency": "weekly"
            }
            
        except Exception as e:
            logger.error(f"포트폴리오 추천 생성 실패: {e}")
            return {
                "portfolio_stocks": [],
                "portfolio_size": 0,
                "error": str(e)
            }


# 전역 분석 엔진 인스턴스
unified_analysis_engine = UnifiedAnalysisEngine()
recommendation_engine = RecommendationEngine()
