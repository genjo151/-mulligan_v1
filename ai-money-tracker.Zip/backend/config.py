# AI 머니 트래커 - 설정 관리

import os
from typing import Optional
from pydantic_settings import BaseSettings
from loguru import logger

class Settings(BaseSettings):
    """애플리케이션 설정"""
    
    # API 키
    dart_api_key: Optional[str] = None
    stock_api_key: Optional[str] = None
    
    # 한국투자증권 API
    kis_app_key: Optional[str] = None
    kis_app_secret: Optional[str] = None
    kis_account_number: Optional[str] = None
    kis_account_product: str = "01"
    kis_access_token: Optional[str] = None
    
    # 데이터베이스
    database_url: str = "sqlite:///./smart_money_tracker.db"
    
    # 로그 설정
    log_level: str = "INFO"
    
    # CORS 설정
    cors_origins: str = "*"
    
    # API 제한
    api_rate_limit: int = 100
    
    # 스캔 설정
    scan_interval_minutes: int = 60
    max_stocks_per_scan: int = 2400
    
    # 알림 설정
    max_notifications_per_hour: int = 10
    notification_retention_days: int = 30
    
    # 보안 설정
    secret_key: str = "default-secret-key-change-in-production"
    access_token_expire_minutes: int = 30
    
    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        case_sensitive = False

# 글로벌 설정 인스턴스
settings = Settings()

def get_dart_api_key() -> Optional[str]:
    """DART API 키 반환"""
    # 환경변수에서 먼저 확인
    api_key = os.getenv("DART_API_KEY")
    if api_key:
        return api_key
    
    # 설정 객체에서 확인
    if settings.dart_api_key:
        return settings.dart_api_key
    
    # 설정 파일에서 확인 (추후 구현)
    # settings_file = load_user_settings()
    # if settings_file.get("dartApiKey"):
    #     return settings_file["dartApiKey"]
    
    return None

def get_stock_api_key() -> Optional[str]:
    """증권사 API 키 반환"""
    # 환경변수에서 먼저 확인
    api_key = os.getenv("STOCK_API_KEY")
    if api_key:
        return api_key
    
    # 설정 객체에서 확인
    if settings.stock_api_key:
        return settings.stock_api_key
    
    return None

def get_kis_app_key() -> Optional[str]:
    """한국투자증권 App Key 반환"""
    api_key = os.getenv("KIS_APP_KEY") or settings.kis_app_key
    if not api_key:
        logger.warning("KIS_APP_KEY가 설정되지 않았습니다.")
    return api_key

def get_kis_app_secret() -> Optional[str]:
    """한국투자증권 App Secret 반환"""
    api_secret = os.getenv("KIS_APP_SECRET") or settings.kis_app_secret
    if not api_secret:
        logger.warning("KIS_APP_SECRET이 설정되지 않았습니다.")
    return api_secret

def get_kis_account_info() -> tuple[Optional[str], str]:
    """한국투자증권 계좌 정보 반환"""
    account_number = os.getenv("KIS_ACCOUNT_NUMBER") or settings.kis_account_number
    account_product = os.getenv("KIS_ACCOUNT_PRODUCT") or settings.kis_account_product
    
    if not account_number:
        logger.warning("KIS_ACCOUNT_NUMBER가 설정되지 않았습니다.")
    
    return account_number, account_product

def validate_kis_credentials() -> bool:
    """한국투자증권 API 인증 정보 검증"""
    app_key = get_kis_app_key()
    app_secret = get_kis_app_secret()
    account_number, _ = get_kis_account_info()
    
    if not app_key or not app_secret:
        return False
    
    # App Key 형식 검증 (PS로 시작하는 18자리)
    if not app_key.startswith("PS") or len(app_key) != 18:
        logger.error("KIS_APP_KEY 형식이 올바르지 않습니다. (PS로 시작하는 18자리)")
        return False
    
    # App Secret 형식 검증 (40자리)
    if len(app_secret) != 40:
        logger.error("KIS_APP_SECRET 형식이 올바르지 않습니다. (40자리)")
        return False
    
    # 계좌번호 형식 검증 (8자리-2자리)
    if account_number and "-" in account_number:
        parts = account_number.split("-")
        if len(parts) != 2 or len(parts[0]) != 8 or len(parts[1]) != 2:
            logger.error("KIS_ACCOUNT_NUMBER 형식이 올바르지 않습니다. (8자리-2자리)")
            return False
    
    return True

async def validate_stock_api_key(api_key: str) -> bool:
    """증권사 API 키 유효성 검증"""
    if not api_key or len(api_key) < 10:
        return False
    
    # 실제 구현에서는 증권사 API에 테스트 요청을 보내서 검증
    # 현재는 간단한 형식 검증만 수행
    if not api_key.replace("-", "").replace("_", "").isalnum():
        return False
    
    return True

def validate_api_keys() -> dict:
    """API 키 유효성 검증"""
    result = {
        "dart_api_valid": False,
        "stock_api_valid": False,
        "errors": []
    }
    
    # DART API 키 검증
    dart_key = get_dart_api_key()
    if dart_key and len(dart_key) >= 20:
        result["dart_api_valid"] = True
    else:
        result["errors"].append("DART API 키가 설정되지 않았거나 유효하지 않습니다.")
    
    # 증권사 API 키 검증
    stock_key = get_stock_api_key()
    if stock_key and len(stock_key) >= 10:
        result["stock_api_valid"] = True
    else:
        result["errors"].append("증권사 API 키가 설정되지 않았거나 유효하지 않습니다.")
    
    return result

def setup_logging():
    """로깅 설정"""
    logger.remove()  # 기본 로거 제거
    
    # 콘솔 로깅
    logger.add(
        sink=lambda msg: print(msg, end=""),
        level=settings.log_level,
        format="<green>{time:YYYY-MM-DD HH:mm:ss}</green> | <level>{level: <8}</level> | <cyan>{name}</cyan>:<cyan>{function}</cyan>:<cyan>{line}</cyan> - <level>{message}</level>",
        colorize=True
    )
    
    # 파일 로깅
    logger.add(
        "logs/smart_money_tracker.log",
        level=settings.log_level,
        format="{time:YYYY-MM-DD HH:mm:ss} | {level: <8} | {name}:{function}:{line} - {message}",
        rotation="1 day",
        retention="30 days",
        compression="zip"
    )
    
    logger.info(f"로깅 설정 완료 (레벨: {settings.log_level})")

def get_cors_origins() -> list:
    """CORS 허용 도메인 반환"""
    origins = settings.cors_origins
    if origins == "*":
        return ["*"]
    
    return [origin.strip() for origin in origins.split(",")]

# 설정 로드 및 로깅 초기화
def initialize_settings():
    """설정 초기화"""
    try:
        # 로그 디렉토리 생성
        os.makedirs("logs", exist_ok=True)
        
        # 로깅 설정
        setup_logging()
        
        # API 키 검증
        api_validation = validate_api_keys()
        if api_validation["errors"]:
            logger.warning("API 키 설정 경고:")
            for error in api_validation["errors"]:
                logger.warning(f"  - {error}")
        else:
            logger.info("모든 API 키가 정상적으로 설정되었습니다.")
        
        logger.info("설정 초기화 완료")
        
    except Exception as e:
        logger.error(f"설정 초기화 실패: {e}")
        raise

# 개발 모드 체크
def is_development() -> bool:
    """개발 모드 여부 확인"""
    return os.getenv("ENVIRONMENT", "development").lower() == "development"

# 프로덕션 모드 체크
def is_production() -> bool:
    """프로덕션 모드 여부 확인"""
    return os.getenv("ENVIRONMENT", "development").lower() == "production"

# 설정 정보 출력 (민감 정보 제외)
def get_public_settings() -> dict:
    """공개 가능한 설정 정보 반환"""
    return {
        "log_level": settings.log_level,
        "cors_origins": get_cors_origins(),
        "api_rate_limit": settings.api_rate_limit,
        "scan_interval_minutes": settings.scan_interval_minutes,
        "max_stocks_per_scan": settings.max_stocks_per_scan,
        "max_notifications_per_hour": settings.max_notifications_per_hour,
        "notification_retention_days": settings.notification_retention_days,
        "environment": "development" if is_development() else "production",
        "api_keys_configured": {
            "dart_api": bool(get_dart_api_key()),
            "stock_api": bool(get_stock_api_key())
        }
    }
