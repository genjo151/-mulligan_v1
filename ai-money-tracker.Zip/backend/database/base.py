# AI 머니 트래커 - 데이터베이스 기본 설정

from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from sqlalchemy import MetaData
import os
from typing import AsyncGenerator
from loguru import logger

# 메타데이터 설정 (명명 규칙)
metadata = MetaData(naming_convention={
    "ix": "ix_%(column_0_label)s",
    "uq": "uq_%(table_name)s_%(column_0_name)s", 
    "ck": "ck_%(table_name)s_%(constraint_name)s",
    "fk": "fk_%(table_name)s_%(column_0_name)s_%(referred_table_name)s",
    "pk": "pk_%(table_name)s"
})

# 기본 모델 클래스
Base = declarative_base(metadata=metadata)

class DatabaseManager:
    """데이터베이스 연결 및 세션 관리"""
    
    def __init__(self, database_url: str = None):
        """
        데이터베이스 매니저 초기화
        
        Args:
            database_url: 데이터베이스 연결 URL
        """
        if database_url is None:
            # 환경변수 또는 기본값 사용
            database_url = os.getenv("DATABASE_URL", "sqlite+aiosqlite:///./smart_money_tracker.db")
        
        self.database_url = database_url
        self.engine = None
        self.SessionLocal = None
        
        logger.info(f"데이터베이스 매니저 초기화: {database_url}")
    
    def initialize(self):
        """데이터베이스 엔진 및 세션 팩토리 초기화"""
        try:
            # 비동기 엔진 생성
            self.engine = create_async_engine(
                self.database_url,
                echo=False,  # SQL 로깅 (개발시에만 True)
                pool_pre_ping=True,  # 연결 상태 확인
                pool_recycle=3600,   # 1시간마다 연결 재사용
            )
            
            # 비동기 세션 팩토리 생성
            self.SessionLocal = sessionmaker(
                self.engine,
                class_=AsyncSession,
                expire_on_commit=False,
                autocommit=False,
                autoflush=False
            )
            
            logger.info("데이터베이스 엔진 및 세션 팩토리 초기화 완료")
            
        except Exception as e:
            logger.error(f"데이터베이스 초기화 실패: {e}")
            raise
    
    async def create_tables(self):
        """데이터베이스 테이블 생성"""
        try:
            async with self.engine.begin() as conn:
                await conn.run_sync(Base.metadata.create_all)
            
            logger.info("데이터베이스 테이블 생성 완료")
            
        except Exception as e:
            logger.error(f"테이블 생성 실패: {e}")
            raise
    
    async def drop_tables(self):
        """데이터베이스 테이블 삭제 (개발/테스트용)"""
        try:
            async with self.engine.begin() as conn:
                await conn.run_sync(Base.metadata.drop_all)
            
            logger.warning("데이터베이스 테이블 삭제 완료")
            
        except Exception as e:
            logger.error(f"테이블 삭제 실패: {e}")
            raise
    
    async def get_session(self) -> AsyncGenerator[AsyncSession, None]:
        """비동기 데이터베이스 세션 생성"""
        if not self.SessionLocal:
            raise RuntimeError("데이터베이스가 초기화되지 않았습니다. initialize()를 먼저 호출하세요.")
        
        async with self.SessionLocal() as session:
            try:
                yield session
            except Exception as e:
                await session.rollback()
                logger.error(f"데이터베이스 세션 오류: {e}")
                raise
            finally:
                await session.close()
    
    async def close(self):
        """데이터베이스 연결 종료"""
        if self.engine:
            await self.engine.dispose()
            logger.info("데이터베이스 연결 종료")

# 글로벌 데이터베이스 매니저 인스턴스
db_manager = DatabaseManager()

async def get_db_session() -> AsyncGenerator[AsyncSession, None]:
    """FastAPI 의존성으로 사용할 데이터베이스 세션"""
    async for session in db_manager.get_session():
        yield session

async def init_database():
    """애플리케이션 시작시 데이터베이스 초기화"""
    try:
        db_manager.initialize()
        await db_manager.create_tables()
        logger.info("데이터베이스 초기화 완료")
    except Exception as e:
        logger.error(f"데이터베이스 초기화 실패: {e}")
        raise

async def close_database():
    """애플리케이션 종료시 데이터베이스 연결 해제"""
    await db_manager.close()
