# AI 머니 트래커 - SQLAlchemy 데이터베이스 모델

from sqlalchemy import Column, String, Integer, Float, DateTime, Date, Boolean, Text, ForeignKey, Index, BigInteger
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from datetime import datetime, date
from typing import Optional
import enum

from .base import Base

class MarketType(str, enum.Enum):
    """시장 구분"""
    KOSPI = "KOSPI"
    KOSDAQ = "KOSDAQ"
    KONEX = "KONEX"

class ReportType(str, enum.Enum):
    """DART 보고서 유형"""
    MAJORSTOCK = "majorstock"  # 5% 이상 대량보유상황보고서
    ELESTOCK = "elestock"      # 임원·주요주주 소유보고서

class GradeType(str, enum.Enum):
    """종목 등급"""
    STRONG = "강함"    # 🔴 6.5점 이상
    SUSPECT = "의심"   # 🟡 5.5-6.4점  
    HOLD = "보류"      # ⚪ 5.5점 미만

class NotificationType(str, enum.Enum):
    """알림 유형"""
    SCORE_ALERT = "score_alert"      # 점수 알림
    NEW_SIGNAL = "new_signal"        # 신규 시그널
    GRADE_CHANGE = "grade_change"    # 등급 변경
    DART_UPDATE = "dart_update"      # DART 업데이트

class StockInfo(Base):
    """종목 기본정보 테이블"""
    __tablename__ = "stock_info"
    
    stock_code = Column(String(6), primary_key=True, comment="종목코드 (6자리)")
    stock_name = Column(String(100), nullable=False, comment="종목명")
    market_type = Column(String(20), nullable=False, comment="시장구분")
    sector = Column(String(100), comment="업종")
    listing_date = Column(Date, comment="상장일")
    market_cap = Column(BigInteger, comment="시가총액")
    shares_outstanding = Column(BigInteger, comment="발행주식수")
    
    # 메타데이터
    created_at = Column(DateTime(timezone=True), server_default=func.now(), comment="생성일시")
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), comment="수정일시")
    
    # 관계 설정
    daily_prices = relationship("DailyPrice", back_populates="stock", cascade="all, delete-orphan")
    investor_trading = relationship("InvestorTrading", back_populates="stock", cascade="all, delete-orphan")
    dart_disclosures = relationship("DartDisclosure", back_populates="stock", cascade="all, delete-orphan")
    stock_scores = relationship("StockScore", back_populates="stock", cascade="all, delete-orphan")
    scan_results = relationship("ScanResult", back_populates="stock", cascade="all, delete-orphan")
    notifications = relationship("Notification", back_populates="stock", cascade="all, delete-orphan")
    
    # 인덱스
    __table_args__ = (
        Index('ix_stock_info_market_type', 'market_type'),
        Index('ix_stock_info_sector', 'sector'),
    )

class DailyPrice(Base):
    """일봉 데이터 테이블"""
    __tablename__ = "daily_prices"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    stock_code = Column(String(6), ForeignKey("stock_info.stock_code"), nullable=False, comment="종목코드")
    date = Column(Date, nullable=False, comment="날짜")
    
    # OHLCV 데이터
    open_price = Column(Integer, nullable=False, comment="시가")
    high_price = Column(Integer, nullable=False, comment="고가")
    low_price = Column(Integer, nullable=False, comment="저가")
    close_price = Column(Integer, nullable=False, comment="종가")
    volume = Column(BigInteger, nullable=False, comment="거래량")
    trading_value = Column(BigInteger, comment="거래대금")
    adj_close_price = Column(Integer, comment="수정종가")
    
    # 기술적 지표 (계산된 값들)
    ma5 = Column(Float, comment="5일 이동평균")
    ma20 = Column(Float, comment="20일 이동평균")
    ma60 = Column(Float, comment="60일 이동평균")
    bb_upper = Column(Float, comment="볼린저밴드 상단")
    bb_middle = Column(Float, comment="볼린저밴드 중간")
    bb_lower = Column(Float, comment="볼린저밴드 하단")
    bb_width = Column(Float, comment="볼린저밴드 폭")
    
    # 메타데이터
    created_at = Column(DateTime(timezone=True), server_default=func.now(), comment="생성일시")
    
    # 관계 설정
    stock = relationship("StockInfo", back_populates="daily_prices")
    
    # 인덱스 및 제약조건
    __table_args__ = (
        Index('ix_daily_prices_stock_date', 'stock_code', 'date'),
        Index('ix_daily_prices_date', 'date'),
        # 종목코드+날짜 유니크 제약
        {'mysql_charset': 'utf8mb4'}
    )

class InvestorTrading(Base):
    """투자자별 매매동향 테이블"""
    __tablename__ = "investor_trading"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    stock_code = Column(String(6), ForeignKey("stock_info.stock_code"), nullable=False, comment="종목코드")
    date = Column(Date, nullable=False, comment="날짜")
    
    # 개인 투자자
    individual_buy = Column(BigInteger, nullable=False, default=0, comment="개인 매수")
    individual_sell = Column(BigInteger, nullable=False, default=0, comment="개인 매도")
    individual_net = Column(BigInteger, nullable=False, default=0, comment="개인 순매수")
    
    # 기관 투자자
    institution_buy = Column(BigInteger, nullable=False, default=0, comment="기관 매수")
    institution_sell = Column(BigInteger, nullable=False, default=0, comment="기관 매도")
    institution_net = Column(BigInteger, nullable=False, default=0, comment="기관 순매수")
    
    # 외국인 투자자
    foreign_buy = Column(BigInteger, nullable=False, default=0, comment="외국인 매수")
    foreign_sell = Column(BigInteger, nullable=False, default=0, comment="외국인 매도")
    foreign_net = Column(BigInteger, nullable=False, default=0, comment="외국인 순매수")
    
    # 기타 (투자신탁, 연기금 등)
    trust_buy = Column(BigInteger, default=0, comment="투신 매수")
    trust_sell = Column(BigInteger, default=0, comment="투신 매도")
    trust_net = Column(BigInteger, default=0, comment="투신 순매수")
    
    pension_buy = Column(BigInteger, default=0, comment="연기금 매수")
    pension_sell = Column(BigInteger, default=0, comment="연기금 매도")
    pension_net = Column(BigInteger, default=0, comment="연기금 순매수")
    
    # 메타데이터
    created_at = Column(DateTime(timezone=True), server_default=func.now(), comment="생성일시")
    
    # 관계 설정
    stock = relationship("StockInfo", back_populates="investor_trading")
    
    # 인덱스
    __table_args__ = (
        Index('ix_investor_trading_stock_date', 'stock_code', 'date'),
        Index('ix_investor_trading_date', 'date'),
    )

class DartDisclosure(Base):
    """DART 공시 데이터 테이블"""
    __tablename__ = "dart_disclosures"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    stock_code = Column(String(6), ForeignKey("stock_info.stock_code"), nullable=False, comment="종목코드")
    corp_code = Column(String(8), nullable=False, comment="법인코드")
    
    # DART 공시 기본 정보
    rcept_no = Column(String(20), nullable=False, comment="접수번호")
    flr_nm = Column(String(200), comment="공시대상회사")
    report_nm = Column(String(300), comment="보고서명")
    report_date = Column(Date, nullable=False, comment="공시일자")
    report_type = Column(String(20), nullable=False, comment="공시유형")
    
    # 보고자 정보
    reporter_name = Column(String(200), comment="보고자명")
    reporter_type = Column(String(50), comment="보고자유형")  # 개인, 법인, 연기금, 헤지펀드 등
    
    # 보유 현황
    hold_ratio = Column(Float, comment="보유비율 (%)")
    hold_stock_count = Column(BigInteger, comment="보유주식수")
    
    # 변동 정보
    change_ratio = Column(Float, comment="변동비율 (%)")
    change_stock_count = Column(BigInteger, comment="변동주식수")
    change_type = Column(String(20), comment="변동구분")  # 증가, 감소
    
    # 보고 사유 및 목적
    report_reason = Column(String(100), comment="보고사유")
    purpose_before = Column(String(100), comment="변경전 보유목적")
    purpose_after = Column(String(100), comment="변경후 보유목적")
    
    # 추가 정보
    acquire_disposal_method = Column(String(100), comment="취득/처분방법")
    price_per_share = Column(Integer, comment="주당가격")
    total_amount = Column(BigInteger, comment="총 취득/처분금액")
    
    # 메타데이터
    created_at = Column(DateTime(timezone=True), server_default=func.now(), comment="생성일시")
    processed_at = Column(DateTime(timezone=True), comment="처리일시")
    
    # 관계 설정
    stock = relationship("StockInfo", back_populates="dart_disclosures")
    
    # 인덱스
    __table_args__ = (
        Index('ix_dart_disclosures_stock_date', 'stock_code', 'report_date'),
        Index('ix_dart_disclosures_rcept_no', 'rcept_no'),
        Index('ix_dart_disclosures_reporter', 'reporter_name'),
        Index('ix_dart_disclosures_type', 'report_type'),
    )

class StockScore(Base):
    """종목 점수 테이블"""
    __tablename__ = "stock_scores"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    stock_code = Column(String(6), ForeignKey("stock_info.stock_code"), nullable=False, comment="종목코드")
    date = Column(Date, nullable=False, comment="계산일자")
    
    # 코어 5요소 점수
    core1_institution_foreign = Column(Float, default=0.0, comment="코어-1: 기관·외국인 60일 누적 순매수")
    core2_obv_uptrend = Column(Float, default=0.0, comment="코어-2: OBV 정량 우상향")
    core3_volatility_squeeze = Column(Float, default=0.0, comment="코어-3: 변동성 수축")
    core4_relative_strength = Column(Float, default=0.0, comment="코어-4: 상대강도 개선")
    core5_accumulation_candles = Column(Float, default=0.0, comment="코어-5: 매집봉 패턴")
    
    # DART 6요소 점수
    dart1_new_holder = Column(Float, default=0.0, comment="DART-1: 신규 5% 보유자 등장")
    dart2_holder_increase = Column(Float, default=0.0, comment="DART-2: 5% 보유자 연속 증가")
    dart3_purpose_upgrade = Column(Float, default=0.0, comment="DART-3: 보유목적 상향")
    dart4_reporter_weight = Column(Float, default=0.0, comment="DART-4: 보고자 성격 가중치")
    dart5_exec_trading = Column(Float, default=0.0, comment="DART-5: 임원·주요주주 순매수")
    dart6_split_buying = Column(Float, default=0.0, comment="DART-6: 분할매수 패턴")
    
    # 총점
    total_core_score = Column(Float, default=0.0, comment="코어 총점 (최대 5.0)")
    total_dart_score = Column(Float, default=0.0, comment="DART 총점 (최대 4.3)")
    total_score = Column(Float, default=0.0, comment="전체 총점 (최대 8.9)")
    
    # 등급
    grade = Column(String(10), comment="등급 (강함/의심/보류)")
    
    # 추가 메트릭
    rank_in_market = Column(Integer, comment="시장 내 순위")
    percentile = Column(Float, comment="백분위")
    
    # 제약 조건 체크 결과
    pre_breakout_constraint = Column(Boolean, default=True, comment="돌파 전 제약 만족")
    trading_value_constraint = Column(Boolean, default=True, comment="거래대금 제약 만족")
    event_exclusion_constraint = Column(Boolean, default=True, comment="이벤트 제외 제약 만족")
    
    # 메타데이터
    created_at = Column(DateTime(timezone=True), server_default=func.now(), comment="생성일시")
    
    # 관계 설정
    stock = relationship("StockInfo", back_populates="stock_scores")
    
    # 인덱스
    __table_args__ = (
        Index('ix_stock_scores_stock_date', 'stock_code', 'date'),
        Index('ix_stock_scores_total_score', 'total_score'),
        Index('ix_stock_scores_grade', 'grade'),
        Index('ix_stock_scores_date', 'date'),
    )

class ScanResult(Base):
    """스캔 결과 테이블"""
    __tablename__ = "scan_results"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    scan_id = Column(String(50), nullable=False, comment="스캔 세션 ID")
    stock_code = Column(String(6), ForeignKey("stock_info.stock_code"), nullable=False, comment="종목코드")
    
    # 스캔 결과
    total_score = Column(Float, nullable=False, comment="총점")
    grade = Column(String(10), nullable=False, comment="등급")
    rank = Column(Integer, comment="순위")
    
    # 스캔 조건
    min_score_threshold = Column(Float, default=5.5, comment="최소 점수 기준")
    excluded_sectors = Column(Text, comment="제외 업종 (JSON)")
    
    # 타이밍 정보
    scan_timestamp = Column(DateTime(timezone=True), nullable=False, comment="스캔 시각")
    market_session = Column(String(20), comment="장 세션 (오전/오후/장후)")
    
    # 메타데이터
    created_at = Column(DateTime(timezone=True), server_default=func.now(), comment="생성일시")
    
    # 관계 설정
    stock = relationship("StockInfo", back_populates="scan_results")
    
    # 인덱스
    __table_args__ = (
        Index('ix_scan_results_scan_id', 'scan_id'),
        Index('ix_scan_results_timestamp', 'scan_timestamp'),
        Index('ix_scan_results_score', 'total_score'),
        Index('ix_scan_results_grade', 'grade'),
    )

class Notification(Base):
    """알림 테이블"""
    __tablename__ = "notifications"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    stock_code = Column(String(6), ForeignKey("stock_info.stock_code"), nullable=False, comment="종목코드")
    
    # 알림 내용
    title = Column(String(200), nullable=False, comment="알림 제목")
    message = Column(Text, nullable=False, comment="알림 내용")
    notification_type = Column(String(20), nullable=False, comment="알림 유형")
    
    # 관련 데이터
    score = Column(Float, comment="당시 점수")
    grade = Column(String(10), comment="등급")
    trigger_reason = Column(String(100), comment="알림 발생 사유")
    
    # 상태
    is_read = Column(Boolean, default=False, comment="읽음 여부")
    is_sent = Column(Boolean, default=False, comment="전송 여부")
    
    # 메타데이터
    created_at = Column(DateTime(timezone=True), server_default=func.now(), comment="생성일시")
    read_at = Column(DateTime(timezone=True), comment="읽은 시각")
    sent_at = Column(DateTime(timezone=True), comment="전송 시각")
    
    # 관계 설정
    stock = relationship("StockInfo", back_populates="notifications")
    
    # 인덱스
    __table_args__ = (
        Index('ix_notifications_stock_code', 'stock_code'),
        Index('ix_notifications_created_at', 'created_at'),
        Index('ix_notifications_type', 'notification_type'),
        Index('ix_notifications_is_read', 'is_read'),
    )
