# AI 머니 트래커 - 데이터베이스 리포지토리 패턴

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update, delete, and_, or_, desc, asc, func
from sqlalchemy.orm import selectinload, joinedload
from typing import List, Optional, Dict, Any, Tuple
from datetime import datetime, date, timedelta
from loguru import logger

from .models import (
    StockInfo, DailyPrice, InvestorTrading, DartDisclosure, 
    StockScore, ScanResult, Notification
)

class BaseRepository:
    """기본 리포지토리 클래스"""
    
    def __init__(self, session: AsyncSession):
        self.session = session

class StockInfoRepository(BaseRepository):
    """종목 기본정보 리포지토리"""
    
    async def get_by_code(self, stock_code: str) -> Optional[StockInfo]:
        """종목코드로 종목 정보 조회"""
        result = await self.session.execute(
            select(StockInfo).where(StockInfo.stock_code == stock_code)
        )
        return result.scalar_one_or_none()
    
    async def get_by_stock_code(self, stock_code: str) -> Optional[StockInfo]:
        """종목코드로 종목 정보 조회 (별칭)"""
        return await self.get_by_code(stock_code)
    
    async def get_all(self, market_type: str = None, sector: str = None) -> List[StockInfo]:
        """전체 종목 목록 조회"""
        query = select(StockInfo)
        
        if market_type:
            query = query.where(StockInfo.market_type == market_type)
        
        if sector:
            query = query.where(StockInfo.sector == sector)
        
        query = query.order_by(StockInfo.stock_code)
        
        result = await self.session.execute(query)
        return result.scalars().all()
    
    async def create(self, stock_data: Dict[str, Any]) -> StockInfo:
        """새 종목 생성"""
        stock = StockInfo(**stock_data)
        self.session.add(stock)
        await self.session.commit()
        await self.session.refresh(stock)
        return stock
    
    async def update(self, stock_code: str, stock_data: Dict[str, Any]) -> Optional[StockInfo]:
        """종목 정보 업데이트"""
        await self.session.execute(
            update(StockInfo)
            .where(StockInfo.stock_code == stock_code)
            .values(**stock_data)
        )
        await self.session.commit()
        return await self.get_by_code(stock_code)
    
    async def search_by_name(self, name_pattern: str) -> List[StockInfo]:
        """종목명으로 검색"""
        result = await self.session.execute(
            select(StockInfo)
            .where(StockInfo.stock_name.like(f"%{name_pattern}%"))
            .order_by(StockInfo.stock_name)
        )
        return result.scalars().all()

class DailyPriceRepository(BaseRepository):
    """일봉 데이터 리포지토리"""
    
    async def get_by_stock_and_date_range(
        self, 
        stock_code: str, 
        start_date: date, 
        end_date: date
    ) -> List[DailyPrice]:
        """종목의 특정 기간 일봉 데이터 조회"""
        result = await self.session.execute(
            select(DailyPrice)
            .where(
                and_(
                    DailyPrice.stock_code == stock_code,
                    DailyPrice.date >= start_date,
                    DailyPrice.date <= end_date
                )
            )
            .order_by(DailyPrice.date.desc())
        )
        return result.scalars().all()
    
    async def get_latest_by_stock(self, stock_code: str, limit: int = 60) -> List[DailyPrice]:
        """종목의 최근 N일 일봉 데이터 조회"""
        result = await self.session.execute(
            select(DailyPrice)
            .where(DailyPrice.stock_code == stock_code)
            .order_by(DailyPrice.date.desc())
            .limit(limit)
        )
        return result.scalars().all()
    
    async def get_by_stock_code_and_date_range(
        self, 
        stock_code: str, 
        days: int
    ) -> List[DailyPrice]:
        """종목의 최근 N일 일봉 데이터 조회"""
        end_date = date.today()
        start_date = end_date - timedelta(days=days)
        return await self.get_by_stock_and_date_range(stock_code, start_date, end_date)
    
    async def bulk_create(self, price_data_list: List[Dict[str, Any]]) -> int:
        """일봉 데이터 대량 생성"""
        prices = [DailyPrice(**data) for data in price_data_list]
        self.session.add_all(prices)
        await self.session.commit()
        return len(prices)
    
    async def get_trading_value_percentile(self, date: date, percentile: float = 0.5) -> float:
        """특정 날짜의 거래대금 백분위값 조회"""
        result = await self.session.execute(
            select(func.percentile_cont(percentile).within_group(DailyPrice.trading_value))
            .where(DailyPrice.date == date)
        )
        return result.scalar() or 0.0
    
    async def calculate_technical_indicators(self, stock_code: str, target_date: date):
        """기술적 지표 계산 및 업데이트"""
        # 최근 60일 데이터 조회
        recent_data = await self.get_latest_by_stock(stock_code, 60)
        
        if len(recent_data) < 20:
            return False
        
        # 이동평균 계산
        prices = [price.close_price for price in reversed(recent_data)]
        
        ma5 = sum(prices[-5:]) / 5 if len(prices) >= 5 else None
        ma20 = sum(prices[-20:]) / 20 if len(prices) >= 20 else None
        ma60 = sum(prices[-60:]) / 60 if len(prices) >= 60 else None
        
        # 볼린저밴드 계산 (20일 기준)
        if len(prices) >= 20:
            recent_20 = prices[-20:]
            mean = sum(recent_20) / 20
            variance = sum((x - mean) ** 2 for x in recent_20) / 20
            std_dev = variance ** 0.5
            
            bb_upper = mean + (2 * std_dev)
            bb_middle = mean
            bb_lower = mean - (2 * std_dev)
            bb_width = (bb_upper - bb_lower) / bb_middle if bb_middle > 0 else 0
        else:
            bb_upper = bb_middle = bb_lower = bb_width = None
        
        # 해당 날짜 데이터 업데이트
        await self.session.execute(
            update(DailyPrice)
            .where(
                and_(
                    DailyPrice.stock_code == stock_code,
                    DailyPrice.date == target_date
                )
            )
            .values(
                ma5=ma5,
                ma20=ma20,
                ma60=ma60,
                bb_upper=bb_upper,
                bb_middle=bb_middle,
                bb_lower=bb_lower,
                bb_width=bb_width
            )
        )
        await self.session.commit()
        return True

class InvestorTradingRepository(BaseRepository):
    """투자자별 매매동향 리포지토리"""
    
    async def get_by_stock_and_date_range(
        self, 
        stock_code: str, 
        start_date: date, 
        end_date: date
    ) -> List[InvestorTrading]:
        """종목의 특정 기간 투자자별 매매동향 조회"""
        result = await self.session.execute(
            select(InvestorTrading)
            .where(
                and_(
                    InvestorTrading.stock_code == stock_code,
                    InvestorTrading.date >= start_date,
                    InvestorTrading.date <= end_date
                )
            )
            .order_by(InvestorTrading.date.desc())
        )
        return result.scalars().all()
    
    async def get_by_stock_code_and_date_range(
        self, 
        stock_code: str, 
        days: int
    ) -> List[InvestorTrading]:
        """종목의 최근 N일 투자자별 매매동향 조회"""
        end_date = date.today()
        start_date = end_date - timedelta(days=days)
        return await self.get_by_stock_and_date_range(stock_code, start_date, end_date)
    
    async def get_net_buying_summary(
        self, 
        stock_code: str, 
        days: int = 60
    ) -> Dict[str, float]:
        """최근 N일간 순매수 집계"""
        end_date = date.today()
        start_date = end_date - timedelta(days=days)
        
        result = await self.session.execute(
            select(
                func.sum(InvestorTrading.individual_net).label('individual_total'),
                func.sum(InvestorTrading.institution_net).label('institution_total'),
                func.sum(InvestorTrading.foreign_net).label('foreign_total'),
                func.sum(InvestorTrading.trust_net).label('trust_total'),
                func.sum(InvestorTrading.pension_net).label('pension_total')
            )
            .where(
                and_(
                    InvestorTrading.stock_code == stock_code,
                    InvestorTrading.date >= start_date,
                    InvestorTrading.date <= end_date
                )
            )
        )
        
        row = result.first()
        
        return {
            'individual_net': row.individual_total or 0,
            'institution_net': row.institution_total or 0,
            'foreign_net': row.foreign_total or 0,
            'trust_net': row.trust_total or 0,
            'pension_net': row.pension_total or 0,
            'institution_foreign_net': (row.institution_total or 0) + (row.foreign_total or 0)
        }
    
    async def bulk_create(self, trading_data_list: List[Dict[str, Any]]) -> int:
        """투자자별 매매동향 대량 생성"""
        tradings = [InvestorTrading(**data) for data in trading_data_list]
        self.session.add_all(tradings)
        await self.session.commit()
        return len(tradings)

class DartDisclosureRepository(BaseRepository):
    """DART 공시 데이터 리포지토리"""
    
    async def get_by_stock_and_date_range(
        self, 
        stock_code: str, 
        start_date: date, 
        end_date: date,
        report_type: str = None
    ) -> List[DartDisclosure]:
        """종목의 특정 기간 DART 공시 조회"""
        query = select(DartDisclosure).where(
            and_(
                DartDisclosure.stock_code == stock_code,
                DartDisclosure.report_date >= start_date,
                DartDisclosure.report_date <= end_date
            )
        )
        
        if report_type:
            query = query.where(DartDisclosure.report_type == report_type)
        
        query = query.order_by(DartDisclosure.report_date.desc())
        
        result = await self.session.execute(query)
        return result.scalars().all()
    
    async def get_by_stock_code_and_date_range(
        self, 
        stock_code: str, 
        days: int
    ) -> List[DartDisclosure]:
        """종목의 최근 N일 DART 공시 조회"""
        end_date = date.today()
        start_date = end_date - timedelta(days=days)
        return await self.get_by_stock_and_date_range(stock_code, start_date, end_date)
    
    async def get_new_holders(self, stock_code: str, days: int = 60) -> List[DartDisclosure]:
        """최근 N일간 신규 5% 보유자 조회"""
        end_date = date.today()
        start_date = end_date - timedelta(days=days)
        
        result = await self.session.execute(
            select(DartDisclosure)
            .where(
                and_(
                    DartDisclosure.stock_code == stock_code,
                    DartDisclosure.report_date >= start_date,
                    DartDisclosure.report_date <= end_date,
                    DartDisclosure.report_type == "majorstock",
                    DartDisclosure.hold_ratio >= 5.0
                )
            )
            .order_by(DartDisclosure.report_date.desc())
        )
        return result.scalars().all()
    
    async def track_holder_changes(
        self, 
        stock_code: str, 
        reporter_name: str, 
        days: int = 30
    ) -> List[DartDisclosure]:
        """특정 보고자의 지분 변화 추적"""
        end_date = date.today()
        start_date = end_date - timedelta(days=days)
        
        result = await self.session.execute(
            select(DartDisclosure)
            .where(
                and_(
                    DartDisclosure.stock_code == stock_code,
                    DartDisclosure.reporter_name == reporter_name,
                    DartDisclosure.report_date >= start_date,
                    DartDisclosure.report_date <= end_date
                )
            )
            .order_by(DartDisclosure.report_date.asc())
        )
        return result.scalars().all()
    
    async def bulk_create(self, disclosure_data_list: List[Dict[str, Any]]) -> int:
        """DART 공시 데이터 대량 생성"""
        disclosures = [DartDisclosure(**data) for data in disclosure_data_list]
        self.session.add_all(disclosures)
        await self.session.commit()
        return len(disclosures)

class StockScoreRepository(BaseRepository):
    """종목 점수 리포지토리"""
    
    async def get_latest_by_stock(self, stock_code: str) -> Optional[StockScore]:
        """종목의 최신 점수 조회"""
        result = await self.session.execute(
            select(StockScore)
            .where(StockScore.stock_code == stock_code)
            .order_by(StockScore.date.desc())
            .limit(1)
        )
        return result.scalar_one_or_none()
    
    async def get_score_history(
        self, 
        stock_code: str, 
        days: int = 30
    ) -> List[StockScore]:
        """종목의 점수 히스토리 조회"""
        end_date = date.today()
        start_date = end_date - timedelta(days=days)
        
        result = await self.session.execute(
            select(StockScore)
            .where(
                and_(
                    StockScore.stock_code == stock_code,
                    StockScore.date >= start_date,
                    StockScore.date <= end_date
                )
            )
            .order_by(StockScore.date.desc())
        )
        return result.scalars().all()
    
    async def get_top_scores(
        self, 
        target_date: date = None, 
        min_score: float = 5.5,
        limit: int = 100
    ) -> List[StockScore]:
        """상위 점수 종목 조회"""
        if target_date is None:
            target_date = date.today()
        
        result = await self.session.execute(
            select(StockScore)
            .options(joinedload(StockScore.stock))
            .where(
                and_(
                    StockScore.date == target_date,
                    StockScore.total_score >= min_score
                )
            )
            .order_by(StockScore.total_score.desc())
            .limit(limit)
        )
        return result.scalars().all()
    
    async def create_or_update(self, score_data: Dict[str, Any]) -> StockScore:
        """점수 생성 또는 업데이트"""
        stock_code = score_data['stock_code']
        score_date = score_data['date']
        
        # 기존 점수 조회
        existing_score = await self.session.execute(
            select(StockScore)
            .where(
                and_(
                    StockScore.stock_code == stock_code,
                    StockScore.date == score_date
                )
            )
        )
        existing = existing_score.scalar_one_or_none()
        
        if existing:
            # 업데이트
            for key, value in score_data.items():
                if key not in ['stock_code', 'date']:
                    setattr(existing, key, value)
            
            await self.session.commit()
            await self.session.refresh(existing)
            return existing
        else:
            # 새로 생성
            new_score = StockScore(**score_data)
            self.session.add(new_score)
            await self.session.commit()
            await self.session.refresh(new_score)
            return new_score
    
    async def create_or_update_by_stock_and_date(
        self, 
        stock_code: str, 
        score_date: date, 
        score_data: Dict[str, Any]
    ) -> StockScore:
        """종목코드와 날짜로 점수 생성 또는 업데이트"""
        score_data.update({
            'stock_code': stock_code,
            'date': score_date
        })
        return await self.create_or_update(score_data)
    
    async def get_latest_scores_by_date(
        self, 
        target_date: date, 
        min_score: float = 0.0
    ) -> List[StockScore]:
        """특정 날짜의 최신 점수 조회"""
        result = await self.session.execute(
            select(StockScore)
            .where(
                and_(
                    StockScore.date == target_date,
                    StockScore.total_score >= min_score
                )
            )
            .order_by(StockScore.total_score.desc())
        )
        return result.scalars().all()

class ScanResultRepository(BaseRepository):
    """스캔 결과 리포지토리"""
    
    async def create_scan_session(self, scan_id: str) -> str:
        """새 스캔 세션 생성"""
        logger.info(f"새 스캔 세션 생성: {scan_id}")
        return scan_id
    
    async def add_scan_result(self, result_data: Dict[str, Any]) -> ScanResult:
        """스캔 결과 추가"""
        result = ScanResult(**result_data)
        self.session.add(result)
        await self.session.commit()
        await self.session.refresh(result)
        return result
    
    async def get_latest_scan_results(
        self, 
        limit: int = 100,
        min_score: float = 5.5
    ) -> List[ScanResult]:
        """최신 스캔 결과 조회"""
        # 가장 최근 스캔 ID 조회
        latest_scan_result = await self.session.execute(
            select(ScanResult.scan_id)
            .order_by(ScanResult.scan_timestamp.desc())
            .limit(1)
        )
        latest_scan_id = latest_scan_result.scalar()
        
        if not latest_scan_id:
            return []
        
        # 해당 스캔의 결과 조회
        result = await self.session.execute(
            select(ScanResult)
            .options(joinedload(ScanResult.stock))
            .where(
                and_(
                    ScanResult.scan_id == latest_scan_id,
                    ScanResult.total_score >= min_score
                )
            )
            .order_by(ScanResult.total_score.desc())
            .limit(limit)
        )
        return result.scalars().all()

class NotificationRepository(BaseRepository):
    """알림 리포지토리"""
    
    async def create(self, notification_data: Dict[str, Any]) -> Notification:
        """새 알림 생성"""
        notification = Notification(**notification_data)
        self.session.add(notification)
        await self.session.commit()
        await self.session.refresh(notification)
        return notification
    
    async def get_unread(self, limit: int = 50) -> List[Notification]:
        """읽지 않은 알림 조회"""
        result = await self.session.execute(
            select(Notification)
            .options(joinedload(Notification.stock))
            .where(Notification.is_read == False)
            .order_by(Notification.created_at.desc())
            .limit(limit)
        )
        return result.scalars().all()
    
    async def mark_as_read(self, notification_id: int) -> bool:
        """알림을 읽음으로 표시"""
        await self.session.execute(
            update(Notification)
            .where(Notification.id == notification_id)
            .values(is_read=True, read_at=datetime.now())
        )
        await self.session.commit()
        return True
    
    async def cleanup_old_notifications(self, days: int = 30) -> int:
        """오래된 알림 정리"""
        cutoff_date = datetime.now() - timedelta(days=days)
        
        result = await self.session.execute(
            delete(Notification)
            .where(Notification.created_at < cutoff_date)
        )
        await self.session.commit()
        return result.rowcount
