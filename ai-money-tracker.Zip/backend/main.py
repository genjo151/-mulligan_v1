# AI 머니 트래커 (Smart Money Tracker) - FastAPI Backend
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
import os

# 설정 및 라우터 임포트
from backend.config import initialize_settings, get_cors_origins, get_public_settings
from backend.database.base import init_database, close_database
from backend.routers import stocks, scan, settings, notifications, dart, database, data_collection, integrity, analysis

# 설정 초기화
initialize_settings()

app = FastAPI(
    title="AI 머니 트래커 API",
    description="세력 움직임 감지 및 주식 추천 시스템",
    version="1.0.0",
    docs_url="/api/docs",  # Swagger UI 경로
    redoc_url="/api/redoc"  # ReDoc 경로
)

# 애플리케이션 시작/종료 이벤트
@app.on_event("startup")
async def startup_event():
    """애플리케이션 시작시 실행"""
    await init_database()

@app.on_event("shutdown") 
async def shutdown_event():
    """애플리케이션 종료시 실행"""
    await close_database()

# CORS 설정
app.add_middleware(
    CORSMiddleware,
    allow_origins=get_cors_origins(),  # 설정에서 가져옴
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# API 라우터 등록
app.include_router(stocks.router)
app.include_router(scan.router)
app.include_router(settings.router)
app.include_router(notifications.router)
app.include_router(dart.router)
app.include_router(database.router)
app.include_router(data_collection.router)
app.include_router(integrity.router)
app.include_router(analysis.router)

# 정적 파일 서빙 (프론트엔드 PWA)
if os.path.exists("frontend"):
    app.mount("/static", StaticFiles(directory="frontend"), name="static")

@app.get("/")
async def read_root():
    """루트 엔드포인트 - PWA 앱 서빙"""
    if os.path.exists("frontend/index.html"):
        return FileResponse("frontend/index.html")
    return {"message": "AI 머니 트래커 API", "version": "1.0.0"}

@app.get("/health")
async def health_check():
    """헬스 체크 엔드포인트"""
    return {"status": "healthy", "service": "ai-money-tracker"}

@app.get("/api/v1/info")
async def api_info():
    """API 정보 및 설정 상태"""
    return {
        "name": "AI 머니 트래커 API",
        "version": "1.0.0",
        "description": "세력 움직임 감지 및 주식 추천 시스템",
        "endpoints": {
            "stocks": "/api/v1/stocks",
            "scan": "/api/v1/scan", 
            "settings": "/api/v1/settings",
            "notifications": "/api/v1/notifications",
            "dart": "/api/v1/dart"
        },
        "docs": "/api/docs",
        "config": get_public_settings()
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
