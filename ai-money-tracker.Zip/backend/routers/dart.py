# AI 머니 트래커 - DART API 라우터

from fastapi import APIRouter, HTTPException, Query, Depends
from typing import List, Dict, Optional
from datetime import datetime, timedelta
import asyncio

from backend.services.dart_api import DartApiClient, DartDataProcessor
from backend.models.schemas import ErrorResponse
from backend.config import get_dart_api_key as get_dart_key_from_config

router = APIRouter(prefix="/dart", tags=["dart"])

# DART API 키 의존성 주입
async def get_dart_api_key() -> str:
    """DART API 키 반환 (환경변수나 설정에서 가져옴)"""
    api_key = get_dart_key_from_config()
    
    if not api_key:
        raise HTTPException(
            status_code=503,
            detail="DART API 키가 설정되지 않았습니다. 환경변수 DART_API_KEY를 설정하거나 설정 페이지에서 API 키를 입력해주세요."
        )
    
    if len(api_key) < 20:
        raise HTTPException(
            status_code=503,
            detail="DART API 키 형식이 올바르지 않습니다. 유효한 API 키를 설정해주세요."
        )
    
    return api_key

@router.get("/corp-codes")
async def get_corp_codes(
    api_key: str = Depends(get_dart_api_key),
    search: Optional[str] = Query(None, description="회사명 검색어")
):
    """종목코드 조회"""
    try:
        async with DartApiClient(api_key) as dart_client:
            corp_codes = await dart_client.fetch_corp_code()
            
            # 검색어가 있으면 필터링
            if search:
                filtered_codes = {}
                search_lower = search.lower()
                for code, info in corp_codes.items():
                    if search_lower in info["corp_name"].lower():
                        filtered_codes[code] = info
                corp_codes = filtered_codes
            
            return {
                "total_count": len(corp_codes),
                "corp_codes": dict(list(corp_codes.items())[:100])  # 최대 100개만 반환
            }
            
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"종목코드 조회 실패: {str(e)}")

@router.get("/majorstock/{stock_code}")
async def get_majorstock_reports(
    stock_code: str,
    api_key: str = Depends(get_dart_api_key),
    days: int = Query(60, ge=1, le=365, description="조회할 일수")
):
    """대량보유상황보고서 조회"""
    try:
        async with DartApiClient(api_key) as dart_client:
            # 종목코드로 회사 고유번호 찾기
            corp_codes = await dart_client.fetch_corp_code()
            
            if stock_code not in corp_codes:
                raise HTTPException(
                    status_code=404,
                    detail=f"종목코드 '{stock_code}'를 찾을 수 없습니다."
                )
            
            corp_code = corp_codes[stock_code]["corp_code"]
            
            # 날짜 범위 설정
            end_date = datetime.now().strftime("%Y%m%d")
            begin_date = (datetime.now() - timedelta(days=days)).strftime("%Y%m%d")
            
            # 대량보유상황보고서 조회
            reports = await dart_client.fetch_majorstock(corp_code, begin_date, end_date)
            
            # 최근 보고서만 필터링
            recent_reports = DartDataProcessor.filter_recent_reports(reports, days)
            
            return {
                "stock_code": stock_code,
                "corp_name": corp_codes[stock_code]["corp_name"],
                "total_reports": len(recent_reports),
                "reports": recent_reports
            }
            
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"대량보유상황보고서 조회 실패: {str(e)}")

@router.get("/elestock/{stock_code}")
async def get_elestock_reports(
    stock_code: str,
    api_key: str = Depends(get_dart_api_key),
    days: int = Query(60, ge=1, le=365, description="조회할 일수")
):
    """임원·주요주주 보유현황 조회"""
    try:
        async with DartApiClient(api_key) as dart_client:
            # 종목코드로 회사 고유번호 찾기
            corp_codes = await dart_client.fetch_corp_code()
            
            if stock_code not in corp_codes:
                raise HTTPException(
                    status_code=404,
                    detail=f"종목코드 '{stock_code}'를 찾을 수 없습니다."
                )
            
            corp_code = corp_codes[stock_code]["corp_code"]
            
            # 날짜 범위 설정
            end_date = datetime.now().strftime("%Y%m%d")
            begin_date = (datetime.now() - timedelta(days=days)).strftime("%Y%m%d")
            
            # 임원·주요주주 보유현황 조회
            reports = await dart_client.fetch_elestock(corp_code, begin_date, end_date)
            
            # 최근 보고서만 필터링
            recent_reports = DartDataProcessor.filter_recent_reports(reports, days)
            
            return {
                "stock_code": stock_code,
                "corp_name": corp_codes[stock_code]["corp_name"],
                "total_reports": len(recent_reports),
                "reports": recent_reports
            }
            
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"임원·주요주주 보유현황 조회 실패: {str(e)}")

@router.get("/dart-scores/{stock_code}")
async def calculate_dart_scores(
    stock_code: str,
    api_key: str = Depends(get_dart_api_key),
    days: int = Query(60, ge=1, le=365, description="조회할 일수")
):
    """DART 기반 세력 감지 점수 계산"""
    try:
        async with DartApiClient(api_key) as dart_client:
            # 종목코드로 회사 고유번호 찾기
            corp_codes = await dart_client.fetch_corp_code()
            
            if stock_code not in corp_codes:
                raise HTTPException(
                    status_code=404,
                    detail=f"종목코드 '{stock_code}'를 찾을 수 없습니다."
                )
            
            corp_code = corp_codes[stock_code]["corp_code"]
            
            # 날짜 범위 설정
            end_date = datetime.now().strftime("%Y%m%d")
            begin_date = (datetime.now() - timedelta(days=days)).strftime("%Y%m%d")
            
            # 병렬로 데이터 조회
            majorstock_task = dart_client.fetch_majorstock(corp_code, begin_date, end_date)
            elestock_task = dart_client.fetch_elestock(corp_code, begin_date, end_date)
            
            majorstock_reports, elestock_reports = await asyncio.gather(
                majorstock_task, elestock_task, return_exceptions=True
            )
            
            # 예외 처리
            if isinstance(majorstock_reports, Exception):
                majorstock_reports = []
            if isinstance(elestock_reports, Exception):
                elestock_reports = []
            
            # 최근 보고서만 필터링
            recent_majorstock = DartDataProcessor.filter_recent_reports(majorstock_reports, days)
            recent_elestock = DartDataProcessor.filter_recent_reports(elestock_reports, days)
            
            # DART 점수 계산
            dart_scores = DartDataProcessor.calculate_dart_scores(
                recent_majorstock, recent_elestock
            )
            
            # 총 DART 점수 계산
            total_dart_score = sum(dart_scores.values())
            
            return {
                "stock_code": stock_code,
                "corp_name": corp_codes[stock_code]["corp_name"],
                "analysis_period_days": days,
                "total_dart_score": round(total_dart_score, 1),
                "max_possible_score": 4.3,  # PRD의 DART 최대 점수
                "score_breakdown": {
                    "dart1_new_holder": {
                        "score": dart_scores["dart1_new_holder"],
                        "max_score": 1.0,
                        "description": "신규 5% 보유자 등장"
                    },
                    "dart2_continuous_increase": {
                        "score": dart_scores["dart2_continuous_increase"],
                        "max_score": 0.8,
                        "description": "5% 보유자 연속 증가"
                    },
                    "dart3_purpose_upgrade": {
                        "score": dart_scores["dart3_purpose_upgrade"],
                        "max_score": 0.6,
                        "description": "보유목적 상향"
                    },
                    "dart4_investor_type": {
                        "score": dart_scores["dart4_investor_type"],
                        "max_score": 0.5,
                        "description": "보고자 성격 가중치"
                    },
                    "dart5_insider_buy": {
                        "score": dart_scores["dart5_insider_buy"],
                        "max_score": 0.6,
                        "description": "임원·주요주주 순매수"
                    },
                    "dart6_split_purchase": {
                        "score": dart_scores["dart6_split_purchase"],
                        "max_score": 0.4,
                        "description": "분할매수 패턴"
                    }
                },
                "data_sources": {
                    "majorstock_reports": len(recent_majorstock),
                    "elestock_reports": len(recent_elestock)
                }
            }
            
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"DART 점수 계산 실패: {str(e)}")

@router.post("/test-connection")
async def test_dart_connection(api_key: str = Depends(get_dart_api_key)):
    """DART API 연결 테스트"""
    try:
        async with DartApiClient(api_key) as dart_client:
            # API 키 형식 검증
            is_valid, message = dart_client.validate_api_key()
            if not is_valid:
                return {
                    "success": False,
                    "message": message,
                    "error_code": "INVALID_API_KEY"
                }
            
            # 실제 API 연결 테스트
            success, result_message = await dart_client.test_api_connection()
            
            return {
                "success": success,
                "message": result_message,
                "api_key_valid": True,
                "tested_at": datetime.now().isoformat()
            }
            
    except Exception as e:
        return {
            "success": False,
            "message": f"연결 테스트 실패: {str(e)}",
            "error_code": "CONNECTION_FAILED",
            "tested_at": datetime.now().isoformat()
        }

@router.get("/test-data/{stock_code}")
async def get_test_dart_data(stock_code: str = "005930"):
    """DART API 테스트 데이터 (API 키 없이 사용 가능)"""
    # 실제 API 호출 없이 샘플 데이터 반환
    sample_dart_scores = {
        "005930": {  # 삼성전자
            "dart1_new_holder": 1.0,
            "dart2_continuous_increase": 0.8,
            "dart3_purpose_upgrade": 0.0,
            "dart4_investor_type": 0.5,
            "dart5_insider_buy": 0.6,
            "dart6_split_purchase": 0.0
        },
        "000660": {  # SK하이닉스
            "dart1_new_holder": 0.0,
            "dart2_continuous_increase": 0.8,
            "dart3_purpose_upgrade": 0.6,
            "dart4_investor_type": 0.3,
            "dart5_insider_buy": 0.0,
            "dart6_split_purchase": 0.4
        }
    }
    
    scores = sample_dart_scores.get(stock_code, {
        "dart1_new_holder": 0.0,
        "dart2_continuous_increase": 0.0,
        "dart3_purpose_upgrade": 0.0,
        "dart4_investor_type": 0.0,
        "dart5_insider_buy": 0.0,
        "dart6_split_purchase": 0.0
    })
    
    total_score = sum(scores.values())
    
    return {
        "stock_code": stock_code,
        "corp_name": "테스트 회사",
        "is_test_data": True,
        "total_dart_score": round(total_score, 1),
        "max_possible_score": 4.3,
        "score_breakdown": scores,
        "message": "실제 DART API 연동을 위해서는 API 키 설정이 필요합니다."
    }
