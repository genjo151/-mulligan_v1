# AI 머니 트래커 - 데이터 수집 API 엔드포인트

from fastapi import APIRouter, Depends, HTTPException, Query, BackgroundTasks
from sqlalchemy.ext.asyncio import AsyncSession
from typing import List, Dict, Any, Optional
from datetime import datetime, date
from loguru import logger

from backend.database.base import get_db_session
from backend.models.schemas import ApiResponse
from backend.config import get_stock_api_key, get_dart_api_key
from backend.services.data_collection.ohlcv_collector import (
    OHLCVDataCollector, OHLCVCollectionScheduler
)
from backend.services.data_collection.investor_trading_collector import (
    InvestorTradingCollector, InvestorTradingScheduler
)
from backend.services.data_collection.dart_collector import (
    DartDataCollector, DartCollectionScheduler
)

router = APIRouter(prefix="/api/v1/data-collection", tags=["data-collection"])

# 전역 수집기 인스턴스 (메모리에 상태 유지)
_ohlcv_collectors = {}
_investor_trading_collectors = {}
_dart_collectors = {}
_collection_status = {}

def get_ohlcv_collector(api_key: str = Depends(get_stock_api_key)) -> OHLCVDataCollector:
    """OHLCV 수집기 의존성"""
    if api_key not in _ohlcv_collectors:
        _ohlcv_collectors[api_key] = OHLCVDataCollector(
            api_key=api_key,
            batch_size=50
        )
        logger.info(f"새 OHLCV 수집기 생성: {api_key[:10]}...")
    
    return _ohlcv_collectors[api_key]

def get_investor_trading_collector(api_key: str = Depends(get_stock_api_key)) -> InvestorTradingCollector:
    """투자자별 매매동향 수집기 의존성"""
    if api_key not in _investor_trading_collectors:
        _investor_trading_collectors[api_key] = InvestorTradingCollector(
            api_key=api_key,
            batch_size=30
        )
        logger.info(f"새 투자자별 매매동향 수집기 생성: {api_key[:10]}...")
    
    return _investor_trading_collectors[api_key]

def get_dart_collector(api_key: str = Depends(get_dart_api_key)) -> DartDataCollector:
    """DART 공시 수집기 의존성"""
    if api_key not in _dart_collectors:
        _dart_collectors[api_key] = DartDataCollector(
            api_key=api_key,
            batch_size=20
        )
        logger.info(f"새 DART 공시 수집기 생성: {api_key[:10]}...")
    
    return _dart_collectors[api_key]

@router.post("/ohlcv/collect", response_model=ApiResponse)
async def trigger_ohlcv_collection(
    background_tasks: BackgroundTasks,
    stock_codes: Optional[List[str]] = Query(None, description="수집할 종목코드 목록 (전체: null)"),
    days: int = Query(60, ge=1, le=365, description="수집할 일수"),
    save_to_db: bool = Query(True, description="데이터베이스 저장 여부"),
    collector: OHLCVDataCollector = Depends(get_ohlcv_collector)
):
    """
    OHLCV 데이터 수집 트리거
    
    Args:
        background_tasks: 백그라운드 작업
        stock_codes: 수집할 종목코드 목록
        days: 수집할 일수
        save_to_db: 데이터베이스 저장 여부
        collector: OHLCV 수집기
    
    Returns:
        수집 작업 시작 응답
    """
    try:
        collection_id = f"ohlcv_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        
        logger.info(f"OHLCV 수집 요청: {collection_id}, 종목: {len(stock_codes) if stock_codes else '전체'}, {days}일")
        
        # 수집 상태 초기화
        _collection_status[collection_id] = {
            "collection_id": collection_id,
            "type": "ohlcv",
            "status": "started",
            "start_time": datetime.now().isoformat(),
            "stock_codes": stock_codes,
            "days": days,
            "save_to_db": save_to_db
        }
        
        # 백그라운드에서 수집 실행
        background_tasks.add_task(
            _run_ohlcv_collection,
            collection_id,
            collector,
            stock_codes,
            days,
            save_to_db
        )
        
        return ApiResponse(
            success=True,
            message=f"OHLCV 데이터 수집 시작: {collection_id}",
            data={
                "collection_id": collection_id,
                "target_stocks": len(stock_codes) if stock_codes else "all",
                "days": days,
                "save_to_db": save_to_db
            }
        )
        
    except Exception as e:
        logger.error(f"OHLCV 수집 요청 실패: {e}")
        raise HTTPException(status_code=500, detail=f"수집 요청 실패: {str(e)}")

async def _run_ohlcv_collection(
    collection_id: str,
    collector: OHLCVDataCollector,
    stock_codes: Optional[List[str]],
    days: int,
    save_to_db: bool
):
    """백그라운드 OHLCV 수집 실행"""
    try:
        logger.info(f"OHLCV 수집 시작: {collection_id}")
        
        # 상태 업데이트
        _collection_status[collection_id]["status"] = "collecting"
        
        # 데이터 수집
        async with collector:
            data = await collector.collect_data(
                stock_codes=stock_codes,
                days=days
            )
        
        # 데이터베이스 저장
        save_result = None
        if save_to_db:
            save_result = await collector.save_to_database(data)
        
        # 상태 업데이트
        _collection_status[collection_id].update({
            "status": "completed",
            "end_time": datetime.now().isoformat(),
            "data_count": len(data),
            "save_result": save_result
        })
        
        logger.info(f"OHLCV 수집 완료: {collection_id}, {len(data)}건")
        
    except Exception as e:
        logger.error(f"OHLCV 수집 실패: {collection_id}, {e}")
        
        _collection_status[collection_id].update({
            "status": "failed",
            "end_time": datetime.now().isoformat(),
            "error": str(e)
        })

@router.get("/ohlcv/status/{collection_id}")
async def get_ohlcv_collection_status(collection_id: str):
    """
    OHLCV 수집 상태 조회
    
    Args:
        collection_id: 수집 작업 ID
    
    Returns:
        수집 상태 정보
    """
    if collection_id not in _collection_status:
        raise HTTPException(status_code=404, detail="수집 작업을 찾을 수 없습니다")
    
    return _collection_status[collection_id]

@router.get("/ohlcv/status")
async def get_all_ohlcv_collection_status(
    limit: int = Query(10, ge=1, le=100, description="조회할 개수")
):
    """
    전체 OHLCV 수집 상태 조회
    
    Args:
        limit: 조회할 개수
    
    Returns:
        수집 상태 목록
    """
    # 최신 순으로 정렬
    status_list = sorted(
        _collection_status.values(),
        key=lambda x: x["start_time"],
        reverse=True
    )
    
    return {
        "total_collections": len(status_list),
        "collections": status_list[:limit]
    }

@router.post("/ohlcv/schedule", response_model=ApiResponse)
async def schedule_daily_ohlcv_collection(
    background_tasks: BackgroundTasks,
    target_time: str = Query("18:00", description="수집 시간 (HH:MM)"),
    stock_codes: Optional[List[str]] = Query(None, description="대상 종목코드"),
    days: int = Query(60, ge=1, le=365, description="수집할 일수"),
    collector: OHLCVDataCollector = Depends(get_ohlcv_collector)
):
    """
    일일 OHLCV 수집 스케줄 등록
    
    Args:
        background_tasks: 백그라운드 작업
        target_time: 수집 시간
        stock_codes: 대상 종목코드
        days: 수집할 일수
        collector: OHLCV 수집기
    
    Returns:
        스케줄 등록 결과
    """
    try:
        scheduler = OHLCVCollectionScheduler(collector)
        
        # 스케줄 ID 생성
        schedule_id = f"daily_ohlcv_{target_time.replace(':', '')}"
        
        logger.info(f"일일 OHLCV 수집 스케줄 등록: {schedule_id}, 시간: {target_time}")
        
        # 즉시 실행 (실제로는 스케줄러가 시간을 체크해야 함)
        background_tasks.add_task(
            _run_scheduled_ohlcv_collection,
            scheduler,
            target_time,
            stock_codes,
            days
        )
        
        return ApiResponse(
            success=True,
            message=f"일일 OHLCV 수집 스케줄 등록: {target_time}",
            data={
                "schedule_id": schedule_id,
                "target_time": target_time,
                "target_stocks": len(stock_codes) if stock_codes else "all",
                "days": days
            }
        )
        
    except Exception as e:
        logger.error(f"OHLCV 스케줄 등록 실패: {e}")
        raise HTTPException(status_code=500, detail=f"스케줄 등록 실패: {str(e)}")

async def _run_scheduled_ohlcv_collection(
    scheduler: OHLCVCollectionScheduler,
    target_time: str,
    stock_codes: Optional[List[str]],
    days: int
):
    """스케줄된 OHLCV 수집 실행"""
    try:
        logger.info(f"스케줄된 OHLCV 수집 실행: {target_time}")
        
        result = await scheduler.run_daily_collection(
            target_time=target_time,
            stock_codes=stock_codes,
            days=days
        )
        
        logger.info(f"스케줄된 OHLCV 수집 완료: {result['success']}")
        
    except Exception as e:
        logger.error(f"스케줄된 OHLCV 수집 실패: {e}")

@router.get("/ohlcv/test")
async def test_ohlcv_collection(
    stock_codes: List[str] = Query(["005930", "000660"], description="테스트 종목코드"),
    days: int = Query(5, ge=1, le=30, description="테스트 일수"),
    collector: OHLCVDataCollector = Depends(get_ohlcv_collector)
):
    """
    OHLCV 수집 테스트 (즉시 실행, 결과 반환)
    
    Args:
        stock_codes: 테스트 종목코드
        days: 테스트 일수
        collector: OHLCV 수집기
    
    Returns:
        수집된 테스트 데이터
    """
    try:
        logger.info(f"OHLCV 수집 테스트: {stock_codes}, {days}일")
        
        start_time = datetime.now()
        
        # 데이터 수집
        async with collector:
            data = await collector.collect_data(
                stock_codes=stock_codes,
                days=days
            )
        
        end_time = datetime.now()
        duration = (end_time - start_time).total_seconds()
        
        # 데이터 검증
        validation_results = {}
        for item in data:
            errors = collector.validate_data(item)
            if errors:
                validation_results[f"{item['stock_code']}_{item['date']}"] = errors
        
        return {
            "test_result": "success",
            "collection_time": duration,
            "data_count": len(data),
            "validation_errors": validation_results,
            "sample_data": data[:5] if data else [],  # 처음 5개만 반환
            "summary": {
                "stocks_collected": len(set(item["stock_code"] for item in data)),
                "date_range": {
                    "start": min(item["date"] for item in data) if data else None,
                    "end": max(item["date"] for item in data) if data else None
                }
            }
        }
        
    except Exception as e:
        logger.error(f"OHLCV 수집 테스트 실패: {e}")
        raise HTTPException(status_code=500, detail=f"테스트 실패: {str(e)}")

@router.get("/stats")
async def get_collection_stats():
    """
    데이터 수집 통계 조회
    
    Returns:
        수집 통계 정보
    """
    try:
        # 수집 상태별 통계
        status_counts = {}
        for status in _collection_status.values():
            status_type = status["status"]
            status_counts[status_type] = status_counts.get(status_type, 0) + 1
        
        # 최근 수집 작업
        recent_collections = sorted(
            _collection_status.values(),
            key=lambda x: x["start_time"],
            reverse=True
        )[:5]
        
        return {
            "total_collections": len(_collection_status),
            "status_summary": status_counts,
            "active_collectors": len(_ohlcv_collectors) + len(_investor_trading_collectors) + len(_dart_collectors),
            "recent_collections": recent_collections,
            "collection_types": {
                "ohlcv": len([s for s in _collection_status.values() if s["type"] == "ohlcv"]),
                "investor_trading": len([s for s in _collection_status.values() if s["type"] == "investor_trading"]),
                "dart": len([s for s in _collection_status.values() if s["type"] == "dart"])
            }
        }
        
    except Exception as e:
        logger.error(f"수집 통계 조회 실패: {e}")
        raise HTTPException(status_code=500, detail=f"통계 조회 실패: {str(e)}")

# ========== 투자자별 매매동향 API 엔드포인트 ==========

@router.post("/investor-trading/collect", response_model=ApiResponse)
async def trigger_investor_trading_collection(
    background_tasks: BackgroundTasks,
    stock_codes: Optional[List[str]] = Query(None, description="수집할 종목코드 목록 (전체: null)"),
    days: int = Query(60, ge=1, le=365, description="수집할 일수"),
    save_to_db: bool = Query(True, description="데이터베이스 저장 여부"),
    collector: InvestorTradingCollector = Depends(get_investor_trading_collector)
):
    """투자자별 매매동향 데이터 수집 트리거"""
    try:
        collection_id = f"investor_trading_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        
        logger.info(f"투자자별 매매동향 수집 요청: {collection_id}, 종목: {len(stock_codes) if stock_codes else '전체'}, {days}일")
        
        # 수집 상태 초기화
        _collection_status[collection_id] = {
            "collection_id": collection_id,
            "type": "investor_trading",
            "status": "started",
            "start_time": datetime.now().isoformat(),
            "stock_codes": stock_codes,
            "days": days,
            "save_to_db": save_to_db
        }
        
        # 백그라운드에서 수집 실행
        background_tasks.add_task(
            _run_investor_trading_collection,
            collection_id,
            collector,
            stock_codes,
            days,
            save_to_db
        )
        
        return ApiResponse(
            success=True,
            message=f"투자자별 매매동향 데이터 수집 시작: {collection_id}",
            data={
                "collection_id": collection_id,
                "target_stocks": len(stock_codes) if stock_codes else "all",
                "days": days,
                "save_to_db": save_to_db
            }
        )
        
    except Exception as e:
        logger.error(f"투자자별 매매동향 수집 요청 실패: {e}")
        raise HTTPException(status_code=500, detail=f"수집 요청 실패: {str(e)}")

async def _run_investor_trading_collection(
    collection_id: str,
    collector: InvestorTradingCollector,
    stock_codes: Optional[List[str]],
    days: int,
    save_to_db: bool
):
    """백그라운드 투자자별 매매동향 수집 실행"""
    try:
        logger.info(f"투자자별 매매동향 수집 시작: {collection_id}")
        
        # 상태 업데이트
        _collection_status[collection_id]["status"] = "collecting"
        
        # 데이터 수집
        async with collector:
            data = await collector.collect_data(
                stock_codes=stock_codes,
                days=days
            )
        
        # 패턴 분석
        pattern_analysis = collector.analyze_trading_patterns(data)
        
        # 데이터베이스 저장
        save_result = None
        if save_to_db:
            save_result = await collector.save_to_database(data)
        
        # 상태 업데이트
        _collection_status[collection_id].update({
            "status": "completed",
            "end_time": datetime.now().isoformat(),
            "data_count": len(data),
            "save_result": save_result,
            "pattern_analysis": pattern_analysis
        })
        
        logger.info(f"투자자별 매매동향 수집 완료: {collection_id}, {len(data)}건")
        
    except Exception as e:
        logger.error(f"투자자별 매매동향 수집 실패: {collection_id}, {e}")
        
        _collection_status[collection_id].update({
            "status": "failed",
            "end_time": datetime.now().isoformat(),
            "error": str(e)
        })

@router.get("/investor-trading/test")
async def test_investor_trading_collection(
    stock_codes: List[str] = Query(["005930", "000660"], description="테스트 종목코드"),
    days: int = Query(5, ge=1, le=30, description="테스트 일수"),
    collector: InvestorTradingCollector = Depends(get_investor_trading_collector)
):
    """투자자별 매매동향 수집 테스트 (즉시 실행, 결과 반환)"""
    try:
        logger.info(f"투자자별 매매동향 수집 테스트: {stock_codes}, {days}일")
        
        start_time = datetime.now()
        
        # 데이터 수집
        async with collector:
            data = await collector.collect_data(
                stock_codes=stock_codes,
                days=days
            )
        
        end_time = datetime.now()
        duration = (end_time - start_time).total_seconds()
        
        # 데이터 검증
        validation_results = {}
        for item in data:
            errors = collector.validate_data(item)
            if errors:
                validation_results[f"{item['stock_code']}_{item['date']}"] = errors
        
        # 패턴 분석
        pattern_analysis = collector.analyze_trading_patterns(data)
        
        return {
            "test_result": "success",
            "collection_time": duration,
            "data_count": len(data),
            "validation_errors": validation_results,
            "pattern_analysis": pattern_analysis,
            "sample_data": data[:3] if data else [],  # 처음 3개만 반환
            "summary": {
                "stocks_collected": len(set(item["stock_code"] for item in data)),
                "date_range": {
                    "start": min(item["date"] for item in data) if data else None,
                    "end": max(item["date"] for item in data) if data else None
                }
            }
        }
        
    except Exception as e:
        logger.error(f"투자자별 매매동향 수집 테스트 실패: {e}")
        raise HTTPException(status_code=500, detail=f"테스트 실패: {str(e)}")

@router.get("/investor-trading/status/{collection_id}")
async def get_investor_trading_collection_status(collection_id: str):
    """투자자별 매매동향 수집 상태 조회"""
    if collection_id not in _collection_status:
        raise HTTPException(status_code=404, detail="수집 작업을 찾을 수 없습니다")
    
    return _collection_status[collection_id]

# =============================================================================
# DART 공시 데이터 수집 엔드포인트
# =============================================================================

@router.post("/dart/collect", response_model=ApiResponse)
async def trigger_dart_collection(
    background_tasks: BackgroundTasks,
    stock_codes: Optional[List[str]] = Query(None, description="수집할 종목코드 목록 (전체: null)"),
    date_range: int = Query(30, description="수집 기간 (일)", ge=1, le=90),
    save_to_db: bool = Query(True, description="데이터베이스 저장 여부"),
    collector: DartDataCollector = Depends(get_dart_collector)
):
    """DART 공시 데이터 배치 수집 트리거"""
    try:
        # 기본 종목 목록
        if not stock_codes:
            stock_codes = ["005930", "000660", "035420", "005380", "051910"]  # 대형주 위주
        
        collection_id = f"dart_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        
        # 배치 수집 백그라운드 실행
        background_tasks.add_task(
            _run_dart_collection,
            collection_id,
            stock_codes,
            date_range,
            save_to_db,
            collector
        )
        
        logger.info(f"DART 공시 수집 요청: {collection_id}, 종목: {len(stock_codes)}, {date_range}일")
        
        return {
            "success": True,
            "data": {
                "collection_id": collection_id,
                "status": "started",
                "stock_codes": stock_codes,
                "date_range": date_range,
                "estimated_completion": "5-10분"
            },
            "message": f"DART 공시 수집이 시작되었습니다 (ID: {collection_id})"
        }
        
    except Exception as e:
        logger.error(f"DART 공시 수집 요청 실패: {e}")
        raise HTTPException(status_code=500, detail=f"수집 요청 실패: {str(e)}")

async def _run_dart_collection(
    collection_id: str,
    stock_codes: List[str],
    date_range: int,
    save_to_db: bool,
    collector: DartDataCollector
):
    """DART 공시 수집 백그라운드 실행"""
    try:
        # 상태 초기화
        _collection_status[collection_id] = {
            "status": "running",
            "started_at": datetime.now().isoformat(),
            "progress": 0,
            "stock_codes": stock_codes,
            "date_range": date_range,
            "total_stocks": len(stock_codes),
            "collected_disclosures": 0,
            "errors": []
        }
        
        logger.info(f"DART 공시 수집 시작: {collection_id}")
        
        # 배치 데이터 수집
        items = [{"stock_code": code, "date_range": date_range} for code in stock_codes]
        results = await collector.collect_batch_data(items)
        
        # 결과 처리
        total_disclosures = 0
        saved_count = 0
        
        if results:
            for result in results:
                if result:
                    disclosures = result.get("disclosures", [])
                    total_disclosures += len(disclosures)
                    
                    # 데이터베이스 저장
                    if save_to_db and disclosures:
                        try:
                            count = await collector.save_to_database(result)
                            saved_count += count
                        except Exception as e:
                            logger.error(f"DART 데이터 저장 실패 ({result.get('stock_code')}): {e}")
                            _collection_status[collection_id]["errors"].append({
                                "stock_code": result.get('stock_code'),
                                "error": str(e)
                            })
        
        # 상태 업데이트
        _collection_status[collection_id].update({
            "status": "completed",
            "completed_at": datetime.now().isoformat(),
            "progress": 100,
            "collected_disclosures": total_disclosures,
            "saved_disclosures": saved_count if save_to_db else 0,
            "success": True
        })
        
        logger.info(f"DART 공시 수집 완료: {collection_id}, {total_disclosures}건")
        
    except Exception as e:
        logger.error(f"DART 공시 수집 실패: {collection_id}, {e}")
        _collection_status[collection_id].update({
            "status": "failed",
            "completed_at": datetime.now().isoformat(),
            "error": str(e),
            "success": False
        })

@router.get("/dart/test")
async def test_dart_collection(
    stock_codes: Optional[List[str]] = Query(["005930"], description="테스트할 종목코드"),
    date_range: int = Query(7, description="수집 기간 (일)", ge=1, le=30),
    collector: DartDataCollector = Depends(get_dart_collector)
):
    """DART 공시 수집 즉시 테스트"""
    try:
        logger.info(f"DART 공시 수집 테스트: {stock_codes}, {date_range}일")
        
        start_time = datetime.now()
        
        # 즉시 수집 실행
        items = [{"stock_code": code, "date_range": date_range} for code in stock_codes]
        results = await collector.collect_batch_data(items)
        
        end_time = datetime.now()
        collection_time = (end_time - start_time).total_seconds()
        
        # 결과 분석
        total_disclosures = 0
        all_disclosures = []
        dart_scores = {}
        
        if results:
            for result in results:
                if result:
                    stock_code = result.get("stock_code")
                    disclosures = result.get("disclosures", [])
                    total_disclosures += len(disclosures)
                    all_disclosures.extend(disclosures)
                    
                    # DART 점수 계산
                    if disclosures:
                        scores = collector.calculate_dart_scores(disclosures)
                        dart_scores[stock_code] = scores
        
        return {
            "test_result": "success",
            "collection_time": round(collection_time, 3),
            "data_count": total_disclosures,
            "stock_codes": stock_codes,
            "date_range": date_range,
            "results": {
                "total_disclosures": total_disclosures,
                "dart_scores": dart_scores,
                "sample_disclosures": all_disclosures[:3] if all_disclosures else []
            },
            "summary": {
                "stocks_analyzed": len([r for r in results if r and r.get("disclosures")]),
                "avg_disclosures_per_stock": round(total_disclosures / len(stock_codes), 1) if stock_codes else 0,
                "disclosure_types": list(set(d.get("report_nm", "") for d in all_disclosures))
            }
        }
        
    except Exception as e:
        logger.error(f"DART 공시 수집 테스트 실패: {e}")
        raise HTTPException(status_code=500, detail=f"테스트 실패: {str(e)}")

@router.get("/dart/status/{collection_id}")
async def get_dart_collection_status(collection_id: str):
    """DART 공시 수집 상태 조회"""
    if collection_id not in _collection_status:
        raise HTTPException(status_code=404, detail="수집 작업을 찾을 수 없습니다")
    
    return _collection_status[collection_id]
