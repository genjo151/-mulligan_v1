# AI 머니 트래커 - 스캔 관련 API 라우터

from fastapi import APIRouter, HTTPException
from datetime import datetime, timedelta
import asyncio
import uuid

from backend.models.schemas import ScanStatus, ScanResponse

router = APIRouter(prefix="/scan", tags=["scan"])

# 글로벌 스캔 상태 (실제로는 Redis나 데이터베이스 사용)
SCAN_STATE = {
    "isRunning": False,
    "progress": 0.0,
    "lastScanTime": None,
    "totalStocks": 2400,
    "processedStocks": 0,
    "scanId": None,
    "startTime": None
}

@router.get("/status", response_model=ScanStatus)
async def get_scan_status():
    """현재 스캔 상태 조회"""
    try:
        # 예상 남은 시간 계산
        estimated_time = None
        if SCAN_STATE["isRunning"] and SCAN_STATE["startTime"]:
            elapsed = (datetime.now() - SCAN_STATE["startTime"]).total_seconds()
            if SCAN_STATE["processedStocks"] > 0:
                rate = SCAN_STATE["processedStocks"] / elapsed  # 초당 처리 종목 수
                remaining_stocks = SCAN_STATE["totalStocks"] - SCAN_STATE["processedStocks"]
                estimated_time = int(remaining_stocks / rate) if rate > 0 else None
        
        return ScanStatus(
            isRunning=SCAN_STATE["isRunning"],
            progress=SCAN_STATE["progress"],
            lastScanTime=SCAN_STATE["lastScanTime"],
            totalStocks=SCAN_STATE["totalStocks"],
            processedStocks=SCAN_STATE["processedStocks"],
            estimatedTimeRemaining=estimated_time
        )
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"스캔 상태 조회 중 오류 발생: {str(e)}")

@router.post("/start", response_model=ScanResponse)
async def start_scan():
    """스캔 시작"""
    try:
        if SCAN_STATE["isRunning"]:
            return ScanResponse(
                message="스캔이 이미 실행 중입니다.",
                status="already_running",
                scanId=SCAN_STATE["scanId"]
            )
        
        # 스캔 시작
        scan_id = str(uuid.uuid4())
        SCAN_STATE.update({
            "isRunning": True,
            "progress": 0.0,
            "processedStocks": 0,
            "scanId": scan_id,
            "startTime": datetime.now()
        })
        
        # 백그라운드에서 스캔 시뮬레이션 실행
        asyncio.create_task(simulate_scan())
        
        return ScanResponse(
            message="스캔이 시작되었습니다.",
            status="started",
            scanId=scan_id
        )
        
    except Exception as e:
        # 오류 발생 시 상태 복구
        SCAN_STATE["isRunning"] = False
        raise HTTPException(status_code=500, detail=f"스캔 시작 중 오류 발생: {str(e)}")

@router.post("/stop", response_model=ScanResponse)
async def stop_scan():
    """스캔 중지"""
    try:
        if not SCAN_STATE["isRunning"]:
            return ScanResponse(
                message="실행 중인 스캔이 없습니다.",
                status="not_running"
            )
        
        # 스캔 중지
        SCAN_STATE.update({
            "isRunning": False,
            "progress": 0.0,
            "processedStocks": 0,
            "scanId": None,
            "startTime": None
        })
        
        return ScanResponse(
            message="스캔이 중지되었습니다.",
            status="stopped"
        )
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"스캔 중지 중 오류 발생: {str(e)}")

@router.get("/history")
async def get_scan_history(limit: int = 10):
    """스캔 히스토리 조회 (추후 구현)"""
    # 실제로는 데이터베이스에서 과거 스캔 기록 조회
    sample_history = []
    
    for i in range(min(limit, 5)):  # 최대 5개 샘플
        scan_time = datetime.now() - timedelta(hours=i+1)
        sample_history.append({
            "scanId": str(uuid.uuid4()),
            "startTime": scan_time,
            "endTime": scan_time + timedelta(minutes=45),
            "totalStocks": 2400,
            "processedStocks": 2400,
            "foundStocks": 12 - i*2,  # 발견된 종목 수
            "status": "completed"
        })
    
    return {"history": sample_history}

async def simulate_scan():
    """스캔 프로세스 시뮬레이션 (실제로는 복잡한 분석 로직)"""
    try:
        total_stocks = SCAN_STATE["totalStocks"]
        
        # 45분 동안 시뮬레이션 (실제 스캔 시간)
        total_duration = 45 * 60  # 45분을 초로 변환
        update_interval = 5  # 5초마다 업데이트
        
        for i in range(0, total_duration, update_interval):
            if not SCAN_STATE["isRunning"]:
                break  # 중지된 경우
                
            # 진행률 계산
            progress = (i / total_duration) * 100
            processed = int((i / total_duration) * total_stocks)
            
            SCAN_STATE.update({
                "progress": round(progress, 1),
                "processedStocks": processed
            })
            
            await asyncio.sleep(update_interval)
        
        # 스캔 완료
        if SCAN_STATE["isRunning"]:
            SCAN_STATE.update({
                "isRunning": False,
                "progress": 100.0,
                "processedStocks": total_stocks,
                "lastScanTime": datetime.now(),
                "scanId": None,
                "startTime": None
            })
            
    except Exception as e:
        # 오류 발생 시 스캔 중지
        SCAN_STATE.update({
            "isRunning": False,
            "progress": 0.0,
            "processedStocks": 0,
            "scanId": None,
            "startTime": None
        })
        print(f"스캔 시뮬레이션 오류: {e}")

@router.get("/progress")
async def get_scan_progress():
    """실시간 스캔 진행률 조회 (WebSocket 대용)"""
    if not SCAN_STATE["isRunning"]:
        return {"message": "실행 중인 스캔이 없습니다."}
    
    return {
        "progress": SCAN_STATE["progress"],
        "processedStocks": SCAN_STATE["processedStocks"],
        "totalStocks": SCAN_STATE["totalStocks"],
        "estimatedTimeRemaining": None  # 추후 계산 로직 추가
    }
