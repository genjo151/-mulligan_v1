# AI 머니 트래커 - 알림 관련 API 라우터

from fastapi import APIRouter, HTTPException, Query
from typing import List, Optional
from datetime import datetime, timedelta
import uuid

from backend.models.schemas import NotificationHistory

router = APIRouter(prefix="/notifications", tags=["notifications"])

# 임시 알림 히스토리 데이터 (실제로는 데이터베이스 사용)
SAMPLE_NOTIFICATIONS = []

def generate_sample_notifications():
    """샘플 알림 데이터 생성"""
    global SAMPLE_NOTIFICATIONS
    
    if SAMPLE_NOTIFICATIONS:  # 이미 생성된 경우
        return
    
    sample_data = [
        {
            "title": "🔴 강력한 세력 감지",
            "message": "삼성전자(005930)에서 기관 대량 매수 포착 - 스코어: 7.2",
            "stockCode": "005930",
            "score": 7.2
        },
        {
            "title": "🟡 세력 움직임 의심",
            "message": "SK하이닉스(000660)에서 DART 신규 보고 - 스코어: 6.8",
            "stockCode": "000660",
            "score": 6.8
        },
        {
            "title": "🔴 강력한 세력 감지",
            "message": "카카오(035720)에서 연속 지분 증가 포착 - 스코어: 6.9",
            "stockCode": "035720",
            "score": 6.9
        },
        {
            "title": "🟡 세력 움직임 의심",
            "message": "NAVER(035420)에서 OBV 상승세 지속 - 스코어: 5.9",
            "stockCode": "035420",
            "score": 5.9
        },
        {
            "title": "📊 스캔 완료",
            "message": "오후 2시 정기 스캔 완료 - 12개 종목 포착",
            "stockCode": None,
            "score": None
        }
    ]
    
    # 최근 7일간의 알림 생성
    for i, data in enumerate(sample_data):
        for day_offset in range(7):
            notification_time = datetime.now() - timedelta(days=day_offset, hours=i)
            
            notification = NotificationHistory(
                id=str(uuid.uuid4()),
                title=data["title"],
                message=data["message"],
                stockCode=data["stockCode"],
                score=data["score"],
                createdAt=notification_time,
                clicked=day_offset > 3  # 오래된 알림은 클릭된 것으로 처리
            )
            
            SAMPLE_NOTIFICATIONS.append(notification)
    
    # 시간순 정렬 (최신순)
    SAMPLE_NOTIFICATIONS.sort(key=lambda x: x.createdAt, reverse=True)

@router.get("/history", response_model=List[NotificationHistory])
async def get_notification_history(
    limit: int = Query(50, ge=1, le=200, description="최대 결과 수"),
    offset: int = Query(0, ge=0, description="시작 위치"),
    stock_code: Optional[str] = Query(None, description="특정 종목의 알림만 조회"),
    days: int = Query(30, ge=1, le=365, description="조회할 일수")
):
    """알림 히스토리 조회"""
    try:
        # 샘플 데이터 생성
        generate_sample_notifications()
        
        # 필터링
        filtered_notifications = SAMPLE_NOTIFICATIONS.copy()
        
        # 날짜 필터
        cutoff_date = datetime.now() - timedelta(days=days)
        filtered_notifications = [
            n for n in filtered_notifications 
            if n.createdAt >= cutoff_date
        ]
        
        # 종목 필터
        if stock_code:
            filtered_notifications = [
                n for n in filtered_notifications 
                if n.stockCode == stock_code
            ]
        
        # 페이지네이션
        total_count = len(filtered_notifications)
        filtered_notifications = filtered_notifications[offset:offset + limit]
        
        return filtered_notifications
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"알림 히스토리 조회 중 오류 발생: {str(e)}")

@router.get("/stats")
async def get_notification_stats():
    """알림 통계 조회"""
    try:
        generate_sample_notifications()
        
        # 최근 24시간 통계
        last_24h = datetime.now() - timedelta(hours=24)
        recent_notifications = [
            n for n in SAMPLE_NOTIFICATIONS 
            if n.createdAt >= last_24h
        ]
        
        # 최근 7일 통계
        last_7d = datetime.now() - timedelta(days=7)
        week_notifications = [
            n for n in SAMPLE_NOTIFICATIONS 
            if n.createdAt >= last_7d
        ]
        
        # 클릭률 계산
        clicked_count = sum(1 for n in SAMPLE_NOTIFICATIONS if n.clicked)
        total_count = len(SAMPLE_NOTIFICATIONS)
        click_rate = (clicked_count / total_count * 100) if total_count > 0 else 0
        
        return {
            "totalNotifications": total_count,
            "last24Hours": len(recent_notifications),
            "last7Days": len(week_notifications),
            "clickRate": round(click_rate, 1),
            "topStocks": get_top_notified_stocks()
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"알림 통계 조회 중 오류 발생: {str(e)}")

@router.post("/{notification_id}/mark-read")
async def mark_notification_read(notification_id: str):
    """알림을 읽음으로 표시"""
    try:
        generate_sample_notifications()
        
        # 알림 찾기
        notification = next(
            (n for n in SAMPLE_NOTIFICATIONS if n.id == notification_id), 
            None
        )
        
        if not notification:
            raise HTTPException(
                status_code=404, 
                detail=f"알림 ID '{notification_id}'를 찾을 수 없습니다."
            )
        
        # 읽음 표시
        notification.clicked = True
        
        return {"message": "알림이 읽음으로 표시되었습니다."}
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"알림 읽음 처리 중 오류 발생: {str(e)}")

@router.delete("/{notification_id}")
async def delete_notification(notification_id: str):
    """알림 삭제"""
    try:
        generate_sample_notifications()
        
        # 알림 찾아서 삭제
        global SAMPLE_NOTIFICATIONS
        original_count = len(SAMPLE_NOTIFICATIONS)
        
        SAMPLE_NOTIFICATIONS = [
            n for n in SAMPLE_NOTIFICATIONS 
            if n.id != notification_id
        ]
        
        if len(SAMPLE_NOTIFICATIONS) == original_count:
            raise HTTPException(
                status_code=404,
                detail=f"알림 ID '{notification_id}'를 찾을 수 없습니다."
            )
        
        return {"message": "알림이 삭제되었습니다."}
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"알림 삭제 중 오류 발생: {str(e)}")

@router.delete("/")
async def clear_all_notifications():
    """모든 알림 삭제"""
    try:
        global SAMPLE_NOTIFICATIONS
        deleted_count = len(SAMPLE_NOTIFICATIONS)
        SAMPLE_NOTIFICATIONS = []
        
        return {
            "message": f"{deleted_count}개의 알림이 모두 삭제되었습니다.",
            "deletedCount": deleted_count
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"알림 전체 삭제 중 오류 발생: {str(e)}")

def get_top_notified_stocks(limit: int = 5):
    """가장 많이 알림된 종목 Top N"""
    try:
        generate_sample_notifications()
        
        # 종목별 알림 카운트
        stock_counts = {}
        for notification in SAMPLE_NOTIFICATIONS:
            if notification.stockCode:
                stock_counts[notification.stockCode] = stock_counts.get(notification.stockCode, 0) + 1
        
        # 상위 종목 정렬
        top_stocks = sorted(stock_counts.items(), key=lambda x: x[1], reverse=True)[:limit]
        
        return [
            {"stockCode": code, "count": count} 
            for code, count in top_stocks
        ]
        
    except Exception:
        return []

# 실시간 알림 전송 (추후 WebSocket 구현)
@router.post("/send")
async def send_notification(
    title: str,
    message: str,
    stock_code: Optional[str] = None,
    score: Optional[float] = None
):
    """새 알림 전송 (관리자용)"""
    try:
        new_notification = NotificationHistory(
            id=str(uuid.uuid4()),
            title=title,
            message=message,
            stockCode=stock_code,
            score=score,
            createdAt=datetime.now(),
            clicked=False
        )
        
        SAMPLE_NOTIFICATIONS.insert(0, new_notification)  # 최신순으로 추가
        
        return {
            "message": "알림이 전송되었습니다.",
            "notificationId": new_notification.id
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"알림 전송 중 오류 발생: {str(e)}")
