# AI 머니 트래커 - 설정 관련 API 라우터

from fastapi import APIRouter, HTTPException
from datetime import datetime
import json
import os

from backend.models.schemas import UserSettings, SettingsResponse, ApiKeyTest, ApiKeyTestResponse, ApiKeyTestResult

router = APIRouter(prefix="/settings", tags=["settings"])

# 설정 파일 경로 (실제로는 데이터베이스 사용)
SETTINGS_FILE = "user_settings.json"

def load_default_settings():
    """기본 설정 로드"""
    return {
        "minScore": 5.5,
        "pushNotifications": False,
        "excludedSectors": [],
        "maxNotificationsPerHour": 10,
        "lastUpdated": datetime.now().isoformat()
    }

def load_settings():
    """설정 파일에서 설정 로드"""
    try:
        if os.path.exists(SETTINGS_FILE):
            with open(SETTINGS_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
        else:
            return load_default_settings()
    except Exception as e:
        print(f"설정 로드 오류: {e}")
        return load_default_settings()

def save_settings(settings_dict):
    """설정을 파일에 저장"""
    try:
        settings_dict["lastUpdated"] = datetime.now().isoformat()
        with open(SETTINGS_FILE, 'w', encoding='utf-8') as f:
            json.dump(settings_dict, f, ensure_ascii=False, indent=2)
        return True
    except Exception as e:
        print(f"설정 저장 오류: {e}")
        return False

@router.get("/", response_model=UserSettings)
async def get_settings():
    """현재 설정 조회"""
    try:
        settings_data = load_settings()
        
        # lastUpdated 필드 제거 (UserSettings 모델에 없음)
        if "lastUpdated" in settings_data:
            del settings_data["lastUpdated"]
            
        return UserSettings(**settings_data)
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"설정 조회 중 오류 발생: {str(e)}")

@router.post("/", response_model=SettingsResponse)
async def save_user_settings(settings: UserSettings):
    """사용자 설정 저장"""
    try:
        # 설정 검증
        if settings.minScore < 0 or settings.minScore > 10:
            raise HTTPException(status_code=400, detail="최소 스코어는 0-10 범위여야 합니다.")
        
        if settings.maxNotificationsPerHour < 1 or settings.maxNotificationsPerHour > 100:
            raise HTTPException(status_code=400, detail="시간당 최대 알림 수는 1-100 범위여야 합니다.")
        
        # 설정 저장
        settings_dict = settings.model_dump()
        success = save_settings(settings_dict)
        
        if not success:
            raise HTTPException(status_code=500, detail="설정 저장에 실패했습니다.")
        
        return SettingsResponse(message="설정이 저장되었습니다.")
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"설정 저장 중 오류 발생: {str(e)}")

@router.post("/reset", response_model=SettingsResponse)
async def reset_settings():
    """설정 초기화"""
    try:
        default_settings = load_default_settings()
        success = save_settings(default_settings)
        
        if not success:
            raise HTTPException(status_code=500, detail="설정 초기화에 실패했습니다.")
        
        return SettingsResponse(message="설정이 초기화되었습니다.")
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"설정 초기화 중 오류 발생: {str(e)}")

@router.get("/export")
async def export_settings():
    """설정 내보내기"""
    try:
        settings_data = load_settings()
        
        # 민감한 정보 제거
        export_data = settings_data.copy()
        export_data["exportedAt"] = datetime.now().isoformat()
        export_data["version"] = "1.0.0"
        
        return {
            "message": "설정을 성공적으로 내보냈습니다.",
            "data": export_data
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"설정 내보내기 중 오류 발생: {str(e)}")

@router.post("/import", response_model=SettingsResponse)
async def import_settings(import_data: dict):
    """설정 가져오기"""
    try:
        # 필수 필드 검증
        required_fields = ["minScore", "pushNotifications", "excludedSectors"]
        for field in required_fields:
            if field not in import_data:
                raise HTTPException(status_code=400, detail=f"필수 필드 '{field}'가 누락되었습니다.")
        
        # 설정 객체 생성 및 검증
        settings = UserSettings(
            minScore=import_data["minScore"],
            pushNotifications=import_data["pushNotifications"],
            excludedSectors=import_data["excludedSectors"],
            maxNotificationsPerHour=import_data.get("maxNotificationsPerHour", 10)
        )
        
        # 설정 저장
        settings_dict = settings.model_dump()
        success = save_settings(settings_dict)
        
        if not success:
            raise HTTPException(status_code=500, detail="설정 가져오기에 실패했습니다.")
        
        return SettingsResponse(message="설정을 성공적으로 가져왔습니다.")
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"설정 가져오기 중 오류 발생: {str(e)}")

# API 키 테스트 관련
@router.post("/test-api-keys", response_model=ApiKeyTestResponse)
async def test_api_keys(api_keys: ApiKeyTest):
    """API 키 유효성 테스트"""
    try:
        # DART API 키 테스트
        dart_result = await test_dart_api_key(api_keys.dartApiKey)
        
        # 증권사 API 키 테스트
        stock_result = await test_stock_api_key(api_keys.stockApiKey)
        
        return ApiKeyTestResponse(
            dartApi=dart_result,
            stockApi=stock_result
        )
        
    except Exception as e:
        # 오류 발생 시 모든 테스트 실패로 처리
        error_result = ApiKeyTestResult(
            success=False,
            error=f"API 키 테스트 중 오류 발생: {str(e)}"
        )
        
        return ApiKeyTestResponse(
            dartApi=error_result,
            stockApi=error_result
        )

async def test_dart_api_key(api_key: str) -> ApiKeyTestResult:
    """DART API 키 테스트"""
    try:
        if not api_key or len(api_key) < 10:
            return ApiKeyTestResult(
                success=False,
                error="DART API 키가 너무 짧습니다. (최소 10자)"
            )
        
        # 실제로는 DART API 호출 테스트
        # 현재는 키 형식만 검증
        if not api_key.isalnum():
            return ApiKeyTestResult(
                success=False,
                error="DART API 키 형식이 올바르지 않습니다."
            )
        
        return ApiKeyTestResult(success=True)
        
    except Exception as e:
        return ApiKeyTestResult(
            success=False,
            error=f"DART API 키 테스트 실패: {str(e)}"
        )

async def test_stock_api_key(api_key: str) -> ApiKeyTestResult:
    """증권사 API 키 테스트"""
    try:
        if not api_key or len(api_key) < 10:
            return ApiKeyTestResult(
                success=False,
                error="증권사 API 키가 너무 짧습니다. (최소 10자)"
            )
        
        # 실제로는 증권사 API 호출 테스트
        # 현재는 키 형식만 검증
        cleaned_key = api_key.replace("-", "").replace("_", "")
        if not cleaned_key.isalnum() or len(cleaned_key) < 10:
            return ApiKeyTestResult(
                success=False,
                error="증권사 API 키 형식이 올바르지 않습니다."
            )
        
        return ApiKeyTestResult(success=True)
        
    except Exception as e:
        return ApiKeyTestResult(
            success=False,
            error=f"증권사 API 키 테스트 실패: {str(e)}"
        )
