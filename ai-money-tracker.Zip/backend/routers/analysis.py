# AI 머니 트래커 - 통합 분석 API 엔드포인트

from fastapi import APIRouter, Query, HTTPException, BackgroundTasks, Depends
from typing import List, Optional, Dict, Any
from datetime import datetime, date, timedelta
from loguru import logger

from backend.models.schemas import ApiResponse
from backend.services.unified_analysis import (
    unified_analysis_engine, recommendation_engine,
    RecommendationLevel, UnifiedAnalysisResult
)

router = APIRouter(prefix="/api/v1/analysis", tags=["unified-analysis"])

# 전역 분석 작업 상태 저장
_analysis_jobs = {}


@router.post("/analyze/{stock_code}", response_model=ApiResponse)
async def trigger_stock_analysis(
    stock_code: str,
    background_tasks: BackgroundTasks,
    analysis_date: Optional[str] = Query(None, description="분석 기준일 (YYYY-MM-DD, 기본: 오늘)"),
    force_analysis: bool = Query(False, description="이벤트 제외 조건 무시하고 강제 분석")
):
    """종목 통합 분석 트리거 (백그라운드 실행)"""
    try:
        # 분석 기준일 파싱
        target_date = date.today()
        if analysis_date:
            try:
                target_date = datetime.strptime(analysis_date, "%Y-%m-%d").date()
            except ValueError:
                raise HTTPException(status_code=400, detail="날짜 형식이 올바르지 않습니다 (YYYY-MM-DD)")
        
        job_id = f"analysis_{stock_code}_{target_date.strftime('%Y%m%d')}_{datetime.now().strftime('%H%M%S')}"
        
        # 백그라운드에서 분석 실행
        background_tasks.add_task(
            _run_stock_analysis,
            job_id,
            stock_code,
            target_date,
            force_analysis
        )
        
        logger.info(f"종목 분석 요청: {stock_code}, 기준일: {target_date}, 작업ID: {job_id}")
        
        return {
            "success": True,
            "data": {
                "job_id": job_id,
                "stock_code": stock_code,
                "analysis_date": target_date.isoformat(),
                "status": "started",
                "force_analysis": force_analysis,
                "estimated_completion": "1-3분"
            },
            "message": f"종목 {stock_code} 통합 분석이 시작되었습니다"
        }
        
    except Exception as e:
        logger.error(f"종목 분석 요청 실패: {stock_code}, {e}")
        raise HTTPException(status_code=500, detail=f"분석 요청 실패: {str(e)}")


async def _run_stock_analysis(
    job_id: str,
    stock_code: str,
    analysis_date: date,
    force_analysis: bool
):
    """종목 분석 백그라운드 실행"""
    try:
        # 상태 초기화
        _analysis_jobs[job_id] = {
            "status": "running",
            "started_at": datetime.now().isoformat(),
            "progress": 0,
            "stock_code": stock_code,
            "analysis_date": analysis_date.isoformat(),
            "current_step": "분석 준비 중..."
        }
        
        logger.info(f"종목 분석 시작: {job_id}")
        
        # 진행 상황 업데이트
        _analysis_jobs[job_id]["current_step"] = "통합 분석 실행 중..."
        _analysis_jobs[job_id]["progress"] = 30
        
        # 통합 분석 실행
        result = await unified_analysis_engine.analyze_stock(
            stock_code=stock_code,
            analysis_date=analysis_date,
            force_analysis=force_analysis
        )
        
        # 진행 상황 업데이트
        _analysis_jobs[job_id]["current_step"] = "결과 처리 중..."
        _analysis_jobs[job_id]["progress"] = 80
        
        # 상태 업데이트
        _analysis_jobs[job_id].update({
            "status": "completed",
            "completed_at": datetime.now().isoformat(),
            "progress": 100,
            "current_step": "완료",
            "result": {
                "stock_code": result.stock_code,
                "stock_name": result.stock_name,
                "analysis_date": result.analysis_date.isoformat(),
                "status": result.status,
                "total_score": result.unified_score.total_score if result.unified_score else 0,
                "recommendation": result.recommendation.value if result.recommendation else "부적격",
                "confidence_level": result.confidence_level,
                "risk_level": result.risk_level,
                "core_elements_met": result.unified_score.core_elements_met if result.unified_score else 0,
                "dart_elements_met": result.unified_score.dart_elements_met if result.unified_score else 0,
                "pattern_validated": result.pattern_validation.pattern_validated if result.pattern_validation else False,
                "analysis_summary": result.analysis_summary,
                "error_message": result.error_message
            },
            "success": result.status == "completed"
        })
        
        logger.info(f"종목 분석 완료: {job_id}, 상태: {result.status}, 점수: {result.unified_score.total_score if result.unified_score else 0}")
        
    except Exception as e:
        logger.error(f"종목 분석 실패: {job_id}, {e}")
        _analysis_jobs[job_id].update({
            "status": "failed",
            "completed_at": datetime.now().isoformat(),
            "error": str(e),
            "success": False
        })


@router.get("/job/{job_id}")
async def get_analysis_job_status(job_id: str):
    """분석 작업 상태 및 결과 조회"""
    if job_id not in _analysis_jobs:
        raise HTTPException(status_code=404, detail="분석 작업을 찾을 수 없습니다")
    
    return _analysis_jobs[job_id]


@router.get("/quick/{stock_code}")
async def quick_stock_analysis(
    stock_code: str,
    analysis_date: Optional[str] = Query(None, description="분석 기준일 (YYYY-MM-DD, 기본: 오늘)"),
    force_analysis: bool = Query(False, description="강제 분석 실행")
):
    """종목 빠른 분석 (즉시 실행)"""
    try:
        # 분석 기준일 파싱
        target_date = date.today()
        if analysis_date:
            try:
                target_date = datetime.strptime(analysis_date, "%Y-%m-%d").date()
            except ValueError:
                raise HTTPException(status_code=400, detail="날짜 형식이 올바르지 않습니다 (YYYY-MM-DD)")
        
        logger.info(f"빠른 분석: {stock_code}, 기준일: {target_date}")
        
        start_time = datetime.now()
        
        # 통합 분석 실행
        result = await unified_analysis_engine.analyze_stock(
            stock_code=stock_code,
            analysis_date=target_date,
            force_analysis=force_analysis
        )
        
        end_time = datetime.now()
        execution_time = (end_time - start_time).total_seconds()
        
        return {
            "analysis_result": "success",
            "execution_time": round(execution_time, 3),
            "stock_code": result.stock_code,
            "stock_name": result.stock_name,
            "analysis_date": result.analysis_date.isoformat(),
            "analysis_status": result.status,
            "unified_score": {
                "total_score": result.unified_score.total_score if result.unified_score else 0,
                "core_score": result.unified_score.core_score if result.unified_score else 0,
                "dart_score": result.unified_score.dart_score if result.unified_score else 0,
                "grade": result.unified_score.grade if result.unified_score else "F",
                "core_elements_met": result.unified_score.core_elements_met if result.unified_score else 0,
                "dart_elements_met": result.unified_score.dart_elements_met if result.unified_score else 0,
                "meets_minimum_requirements": result.unified_score.meets_minimum_requirements if result.unified_score else False
            },
            "recommendation": result.recommendation.value if result.recommendation else "부적격",
            "confidence_level": result.confidence_level,
            "risk_level": result.risk_level,
            "pattern_validation": {
                "pattern_validated": result.pattern_validation.pattern_validated if result.pattern_validation else False,
                "occurrence_count": result.pattern_validation.occurrence_count if result.pattern_validation else 0,
                "trend": result.pattern_validation.trend if result.pattern_validation else "unknown"
            } if result.pattern_validation else None,
            "event_exclusion": {
                "should_exclude": result.event_exclusion.should_exclude if result.event_exclusion else False,
                "exclusion_reasons": result.event_exclusion.exclusion_reasons if result.event_exclusion else []
            } if result.event_exclusion else None,
            "analysis_summary": result.analysis_summary,
            "error_message": result.error_message
        }
        
    except Exception as e:
        logger.error(f"빠른 분석 실패: {stock_code}, {e}")
        raise HTTPException(status_code=500, detail=f"분석 실패: {str(e)}")


@router.get("/ranking")
async def get_stock_ranking(
    analysis_date: Optional[str] = Query(None, description="분석 기준일 (YYYY-MM-DD, 기본: 오늘)"),
    min_score: float = Query(5.0, description="최소 점수", ge=0, le=8.9),
    max_results: int = Query(50, description="최대 결과 수", ge=1, le=100),
    recommendation_filter: Optional[str] = Query(None, description="추천 등급 필터 (강력추천, 추천, 관심)")
):
    """종목 랭킹 조회"""
    try:
        # 분석 기준일 파싱
        target_date = date.today()
        if analysis_date:
            try:
                target_date = datetime.strptime(analysis_date, "%Y-%m-%d").date()
            except ValueError:
                raise HTTPException(status_code=400, detail="날짜 형식이 올바르지 않습니다 (YYYY-MM-DD)")
        
        logger.info(f"종목 랭킹 조회: 기준일: {target_date}, 최소점수: {min_score}")
        
        # 랭킹 조회
        ranked_stocks = await recommendation_engine.get_ranked_stocks(
            analysis_date=target_date,
            min_score=min_score,
            max_results=max_results
        )
        
        # 추천 등급 필터링
        if recommendation_filter:
            ranked_stocks = [
                stock for stock in ranked_stocks
                if stock.get("recommendation") == recommendation_filter
            ]
        
        return {
            "ranking_date": target_date.isoformat(),
            "total_stocks": len(ranked_stocks),
            "filter_criteria": {
                "min_score": min_score,
                "recommendation_filter": recommendation_filter,
                "max_results": max_results
            },
            "ranking": ranked_stocks,
            "statistics": {
                "average_score": round(sum(s["total_score"] for s in ranked_stocks) / len(ranked_stocks), 2) if ranked_stocks else 0,
                "score_range": {
                    "min": min(s["total_score"] for s in ranked_stocks) if ranked_stocks else 0,
                    "max": max(s["total_score"] for s in ranked_stocks) if ranked_stocks else 0
                },
                "recommendation_distribution": _calculate_recommendation_distribution(ranked_stocks)
            }
        }
        
    except Exception as e:
        logger.error(f"종목 랭킹 조회 실패: {e}")
        raise HTTPException(status_code=500, detail=f"랭킹 조회 실패: {str(e)}")


@router.get("/portfolio")
async def get_portfolio_recommendation(
    target_size: int = Query(10, description="포트폴리오 목표 크기", ge=1, le=20),
    risk_tolerance: str = Query("medium", description="위험 허용도 (conservative, medium, aggressive)"),
    sector_diversification: bool = Query(True, description="섹터 다양화 적용")
):
    """포트폴리오 추천"""
    try:
        if risk_tolerance not in ["conservative", "medium", "aggressive"]:
            raise HTTPException(status_code=400, detail="위험 허용도는 conservative, medium, aggressive 중 하나여야 합니다")
        
        logger.info(f"포트폴리오 추천: 크기: {target_size}, 위험허용도: {risk_tolerance}")
        
        # 포트폴리오 추천 생성
        portfolio = await recommendation_engine.generate_portfolio_recommendation(
            target_size=target_size,
            risk_tolerance=risk_tolerance
        )
        
        if portfolio.get("error"):
            raise HTTPException(status_code=500, detail=portfolio["error"])
        
        return {
            "portfolio_recommendation": "success",
            "recommendation_date": portfolio.get("recommendation_date", date.today()).isoformat(),
            "portfolio": {
                "stocks": portfolio["portfolio_stocks"],
                "size": portfolio["portfolio_size"],
                "target_size": target_size,
                "risk_tolerance": risk_tolerance,
                "diversification_applied": sector_diversification
            },
            "statistics": portfolio.get("statistics", {}),
            "rebalancing": {
                "frequency": portfolio.get("rebalancing_frequency", "weekly"),
                "next_rebalancing": (date.today() + timedelta(days=7)).isoformat()
            },
            "performance_expectations": _calculate_performance_expectations(portfolio["portfolio_stocks"]) if portfolio["portfolio_stocks"] else {}
        }
        
    except Exception as e:
        logger.error(f"포트폴리오 추천 실패: {e}")
        raise HTTPException(status_code=500, detail=f"포트폴리오 추천 실패: {str(e)}")


@router.get("/batch-analyze")
async def trigger_batch_analysis(
    background_tasks: BackgroundTasks,
    stock_codes: List[str] = Query(..., description="분석할 종목 코드 목록"),
    analysis_date: Optional[str] = Query(None, description="분석 기준일 (YYYY-MM-DD, 기본: 오늘)"),
    force_analysis: bool = Query(False, description="강제 분석 실행")
):
    """여러 종목 일괄 분석"""
    try:
        if len(stock_codes) > 50:
            raise HTTPException(status_code=400, detail="한 번에 최대 50개 종목까지 분석 가능합니다")
        
        # 분석 기준일 파싱
        target_date = date.today()
        if analysis_date:
            try:
                target_date = datetime.strptime(analysis_date, "%Y-%m-%d").date()
            except ValueError:
                raise HTTPException(status_code=400, detail="날짜 형식이 올바르지 않습니다 (YYYY-MM-DD)")
        
        batch_id = f"batch_{target_date.strftime('%Y%m%d')}_{datetime.now().strftime('%H%M%S')}"
        
        # 백그라운드에서 일괄 분석 실행
        background_tasks.add_task(
            _run_batch_analysis,
            batch_id,
            stock_codes,
            target_date,
            force_analysis
        )
        
        logger.info(f"일괄 분석 요청: {len(stock_codes)}개 종목, 기준일: {target_date}, 배치ID: {batch_id}")
        
        return {
            "success": True,
            "data": {
                "batch_id": batch_id,
                "stock_codes": stock_codes,
                "stock_count": len(stock_codes),
                "analysis_date": target_date.isoformat(),
                "status": "started",
                "force_analysis": force_analysis,
                "estimated_completion": f"{len(stock_codes) * 2}-{len(stock_codes) * 5}분"
            },
            "message": f"{len(stock_codes)}개 종목 일괄 분석이 시작되었습니다"
        }
        
    except Exception as e:
        logger.error(f"일괄 분석 요청 실패: {e}")
        raise HTTPException(status_code=500, detail=f"일괄 분석 요청 실패: {str(e)}")


async def _run_batch_analysis(
    batch_id: str,
    stock_codes: List[str],
    analysis_date: date,
    force_analysis: bool
):
    """일괄 분석 백그라운드 실행"""
    try:
        # 상태 초기화
        _analysis_jobs[batch_id] = {
            "status": "running",
            "started_at": datetime.now().isoformat(),
            "progress": 0,
            "stock_codes": stock_codes,
            "total_stocks": len(stock_codes),
            "completed_stocks": 0,
            "analysis_date": analysis_date.isoformat(),
            "current_step": "일괄 분석 준비 중...",
            "results": {}
        }
        
        logger.info(f"일괄 분석 시작: {batch_id}")
        
        # 각 종목 순차 분석
        for i, stock_code in enumerate(stock_codes):
            try:
                _analysis_jobs[batch_id]["current_step"] = f"종목 분석 중: {stock_code} ({i+1}/{len(stock_codes)})"
                _analysis_jobs[batch_id]["progress"] = int((i / len(stock_codes)) * 90)
                
                # 개별 종목 분석
                result = await unified_analysis_engine.analyze_stock(
                    stock_code=stock_code,
                    analysis_date=analysis_date,
                    force_analysis=force_analysis
                )
                
                # 결과 저장
                _analysis_jobs[batch_id]["results"][stock_code] = {
                    "status": result.status,
                    "total_score": result.unified_score.total_score if result.unified_score else 0,
                    "recommendation": result.recommendation.value if result.recommendation else "부적격",
                    "error_message": result.error_message
                }
                
                _analysis_jobs[batch_id]["completed_stocks"] += 1
                
                logger.info(f"종목 분석 완료: {stock_code} ({i+1}/{len(stock_codes)})")
                
            except Exception as e:
                logger.error(f"종목 분석 실패: {stock_code}, {e}")
                _analysis_jobs[batch_id]["results"][stock_code] = {
                    "status": "error",
                    "error_message": str(e)
                }
        
        # 최종 상태 업데이트
        _analysis_jobs[batch_id].update({
            "status": "completed",
            "completed_at": datetime.now().isoformat(),
            "progress": 100,
            "current_step": "완료",
            "success": True,
            "summary": {
                "total_analyzed": len(stock_codes),
                "successful": len([r for r in _analysis_jobs[batch_id]["results"].values() if r["status"] == "completed"]),
                "failed": len([r for r in _analysis_jobs[batch_id]["results"].values() if r["status"] == "error"]),
                "excluded": len([r for r in _analysis_jobs[batch_id]["results"].values() if r["status"] == "excluded"])
            }
        })
        
        logger.info(f"일괄 분석 완료: {batch_id}")
        
    except Exception as e:
        logger.error(f"일괄 분석 실패: {batch_id}, {e}")
        _analysis_jobs[batch_id].update({
            "status": "failed",
            "completed_at": datetime.now().isoformat(),
            "error": str(e),
            "success": False
        })


@router.get("/stats")
async def get_analysis_stats():
    """분석 통계 조회"""
    try:
        # 분석 작업 통계
        total_jobs = len(_analysis_jobs)
        status_counts = {}
        for job in _analysis_jobs.values():
            status = job["status"]
            status_counts[status] = status_counts.get(status, 0) + 1
        
        # 성공률 계산
        successful_jobs = len([j for j in _analysis_jobs.values() if j.get("success", False)])
        success_rate = successful_jobs / total_jobs if total_jobs > 0 else 0
        
        # 최근 작업들
        recent_jobs = sorted(
            _analysis_jobs.values(),
            key=lambda x: x["started_at"],
            reverse=True
        )[:10]
        
        return {
            "analysis_service_status": {
                "engine_active": True,
                "total_jobs": total_jobs,
                "success_rate": round(success_rate, 3),
                "status_distribution": status_counts
            },
            "recent_jobs": recent_jobs,
            "engine_configuration": {
                "max_total_score": 8.9,
                "core_weight": 0.6,
                "dart_weight": 0.4,
                "pattern_threshold": 2,
                "minimum_core_count": 3
            },
            "supported_features": [
                "unified_scoring",
                "pattern_validation", 
                "event_exclusion",
                "portfolio_recommendation",
                "batch_analysis"
            ]
        }
        
    except Exception as e:
        logger.error(f"분석 통계 조회 실패: {e}")
        raise HTTPException(status_code=500, detail=f"통계 조회 실패: {str(e)}")


def _calculate_recommendation_distribution(stocks: List[Dict[str, Any]]) -> Dict[str, int]:
    """추천 등급 분포 계산"""
    distribution = {}
    for stock in stocks:
        recommendation = stock.get("recommendation", "부적격")
        distribution[recommendation] = distribution.get(recommendation, 0) + 1
    return distribution


def _calculate_performance_expectations(stocks: List[Dict[str, Any]]) -> Dict[str, Any]:
    """포트폴리오 성과 예상치 계산"""
    if not stocks:
        return {}
    
    avg_score = sum(s.get("total_score", 0) for s in stocks) / len(stocks)
    
    # 점수 기반 성과 예상 (간단한 모델)
    if avg_score >= 7.0:
        expected_return = "high"
        risk_level = "medium"
    elif avg_score >= 5.5:
        expected_return = "medium"
        risk_level = "medium"
    else:
        expected_return = "low"
        risk_level = "high"
    
    return {
        "expected_return": expected_return,
        "risk_level": risk_level,
        "confidence": "medium",
        "time_horizon": "3-6개월"
    }
