# AI 머니 트래커 - 데이터 무결성 검증 API 엔드포인트

from fastapi import APIRouter, Query, HTTPException, BackgroundTasks
from typing import List, Optional, Dict, Any
from datetime import datetime
from loguru import logger

from backend.models.schemas import ApiResponse
from backend.services.data_integrity import integrity_service

router = APIRouter(prefix="/api/v1/integrity", tags=["data-integrity"])

# 전역 무결성 검사 상태 저장
_integrity_checks = {}


@router.post("/check", response_model=ApiResponse)
async def trigger_integrity_check(
    background_tasks: BackgroundTasks,
    stock_codes: Optional[List[str]] = Query(None, description="검사할 종목코드 목록 (전체: null)"),
    date_range: int = Query(30, description="검사할 날짜 범위 (일)", ge=1, le=90)
):
    """데이터 무결성 종합 검사 트리거"""
    try:
        check_id = f"integrity_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        
        # 백그라운드에서 무결성 검사 실행
        background_tasks.add_task(
            _run_integrity_check,
            check_id,
            stock_codes,
            date_range
        )
        
        logger.info(f"데이터 무결성 검사 요청: {check_id}, 종목: {len(stock_codes) if stock_codes else '전체'}, {date_range}일")
        
        return {
            "success": True,
            "data": {
                "check_id": check_id,
                "status": "started",
                "stock_codes": stock_codes,
                "date_range": date_range,
                "estimated_completion": "2-5분"
            },
            "message": f"데이터 무결성 검사가 시작되었습니다 (ID: {check_id})"
        }
        
    except Exception as e:
        logger.error(f"무결성 검사 요청 실패: {e}")
        raise HTTPException(status_code=500, detail=f"검사 요청 실패: {str(e)}")


async def _run_integrity_check(
    check_id: str,
    stock_codes: Optional[List[str]],
    date_range: int
):
    """무결성 검사 백그라운드 실행"""
    try:
        # 상태 초기화
        _integrity_checks[check_id] = {
            "status": "running",
            "started_at": datetime.now().isoformat(),
            "progress": 0,
            "stock_codes": stock_codes,
            "date_range": date_range,
            "current_step": "데이터 조회 중..."
        }
        
        logger.info(f"데이터 무결성 검사 시작: {check_id}")
        
        # 무결성 검사 실행
        _integrity_checks[check_id]["current_step"] = "데이터 검증 중..."
        _integrity_checks[check_id]["progress"] = 30
        
        report = await integrity_service.run_comprehensive_integrity_check(stock_codes, date_range)
        
        # 상태 업데이트
        _integrity_checks[check_id].update({
            "status": "completed",
            "completed_at": datetime.now().isoformat(),
            "progress": 100,
            "current_step": "완료",
            "report": {
                "overall_status": report.overall_status,
                "data_types": report.data_types,
                "alerts": report.alerts,
                "recommendations": report.recommendations,
                "statistics": report.statistics
            },
            "success": True
        })
        
        logger.info(f"데이터 무결성 검사 완료: {check_id}, 상태: {report.overall_status}")
        
    except Exception as e:
        logger.error(f"데이터 무결성 검사 실패: {check_id}, {e}")
        _integrity_checks[check_id].update({
            "status": "failed",
            "completed_at": datetime.now().isoformat(),
            "error": str(e),
            "success": False
        })


@router.get("/check/{check_id}")
async def get_integrity_check_status(check_id: str):
    """무결성 검사 상태 및 결과 조회"""
    if check_id not in _integrity_checks:
        raise HTTPException(status_code=404, detail="검사 작업을 찾을 수 없습니다")
    
    return _integrity_checks[check_id]


@router.get("/quick-check")
async def quick_integrity_check(
    stock_codes: Optional[List[str]] = Query(["005930"], description="검사할 종목코드"),
    date_range: int = Query(7, description="검사할 날짜 범위 (일)", ge=1, le=30)
):
    """빠른 무결성 검사 (즉시 실행)"""
    try:
        logger.info(f"빠른 무결성 검사: {stock_codes}, {date_range}일")
        
        start_time = datetime.now()
        
        # 즉시 무결성 검사 실행
        report = await integrity_service.run_comprehensive_integrity_check(stock_codes, date_range)
        
        end_time = datetime.now()
        execution_time = (end_time - start_time).total_seconds()
        
        return {
            "check_result": "success",
            "execution_time": round(execution_time, 3),
            "overall_status": report.overall_status,
            "stock_codes": stock_codes,
            "date_range": date_range,
            "report": {
                "data_types": report.data_types,
                "alerts": report.alerts,
                "recommendations": report.recommendations,
                "statistics": report.statistics
            },
            "summary": {
                "total_records_checked": report.statistics.get("total_records_checked", 0),
                "total_alerts": report.statistics.get("total_alerts", 0),
                "completeness_overall": report.statistics.get("completeness_overall", 1.0),
                "status_by_type": {
                    data_type: metrics["status"]
                    for data_type, metrics in report.data_types.items()
                }
            }
        }
        
    except Exception as e:
        logger.error(f"빠른 무결성 검사 실패: {e}")
        raise HTTPException(status_code=500, detail=f"검사 실패: {str(e)}")


@router.get("/validation-rules")
async def get_validation_rules():
    """데이터 무결성 검증 규칙 조회"""
    try:
        validator = integrity_service.validator
        
        return {
            "validation_rules": validator.validation_rules,
            "tolerance": validator.tolerance,
            "duplicate_keys": validator.duplicate_keys,
            "supported_data_types": ["ohlcv", "investor_trading", "dart"],
            "validation_descriptions": {
                "ohlcv": {
                    "price_consistency": "고가 >= 저가, 고가 >= 시가/종가, 저가 <= 시가/종가",
                    "volume_positive": "거래량 및 거래대금 양수 검증",
                    "date_sequence": "날짜 형식 및 미래 날짜 검증",
                    "trading_value_calc": "거래대금 = 종가 × 거래량 일치성 검증"
                },
                "investor_trading": {
                    "volume_sum_consistency": "순매수량 = 매수량 - 매도량",
                    "amount_calculation": "순매수금액 = 매수금액 - 매도금액",
                    "net_balance": "매수/매도 거래량, 금액 양수 검증",
                    "investor_type_valid": "유효한 투자자 유형 검증"
                },
                "dart": {
                    "rcept_no_format": "접수번호 14자리 숫자 형식",
                    "date_format": "날짜 형식 및 범위 검증", 
                    "corp_code_format": "법인코드 8자리 숫자 형식",
                    "report_type_valid": "지원되는 보고서 유형 검증"
                }
            }
        }
        
    except Exception as e:
        logger.error(f"검증 규칙 조회 실패: {e}")
        raise HTTPException(status_code=500, detail=f"규칙 조회 실패: {str(e)}")


@router.get("/health-score")
async def get_data_health_score(
    stock_codes: Optional[List[str]] = Query(["005930", "000660"], description="평가할 종목코드"),
    date_range: int = Query(30, description="평가할 날짜 범위 (일)", ge=1, le=90)
):
    """데이터 품질 건강도 점수 조회"""
    try:
        logger.info(f"데이터 건강도 점수 조회: {stock_codes}, {date_range}일")
        
        # 빠른 무결성 검사 실행
        report = await integrity_service.run_comprehensive_integrity_check(stock_codes, date_range)
        
        # 건강도 점수 계산
        health_scores = {}
        overall_score = 0.0
        
        for data_type, metrics in report.data_types.items():
            # 각 항목별 가중치
            weights = {
                "validity_rate": 0.4,      # 40%
                "completeness_rate": 0.4,   # 40%
                "duplicate_penalty": 0.2    # 20% (중복률 패널티)
            }
            
            # 중복률 패널티 (중복률이 높을수록 점수 감소)
            duplicate_penalty = max(0, 1 - metrics["duplicate_rate"] * 5)  # 20% 중복시 0점
            
            # 가중 평균 계산
            score = (
                metrics["validity_rate"] * weights["validity_rate"] +
                metrics["completeness_rate"] * weights["completeness_rate"] +
                duplicate_penalty * weights["duplicate_penalty"]
            ) * 100  # 0-100점 스케일
            
            health_scores[data_type] = {
                "score": round(score, 1),
                "grade": _get_grade(score),
                "status": metrics["status"],
                "components": {
                    "validity": round(metrics["validity_rate"] * 100, 1),
                    "completeness": round(metrics["completeness_rate"] * 100, 1),
                    "duplicates": round(metrics["duplicate_rate"] * 100, 1)
                }
            }
            
            overall_score += score
        
        # 전체 평균 점수
        overall_score = overall_score / len(health_scores) if health_scores else 0
        
        return {
            "timestamp": datetime.now().isoformat(),
            "overall_score": round(overall_score, 1),
            "overall_grade": _get_grade(overall_score),
            "overall_status": report.overall_status,
            "data_types": health_scores,
            "statistics": {
                "total_records": report.statistics.get("total_records_checked", 0),
                "total_alerts": report.statistics.get("total_alerts", 0),
                "execution_time": report.statistics.get("execution_time", 0)
            },
            "improvement_suggestions": _get_improvement_suggestions(health_scores, report.alerts)
        }
        
    except Exception as e:
        logger.error(f"건강도 점수 조회 실패: {e}")
        raise HTTPException(status_code=500, detail=f"점수 조회 실패: {str(e)}")


def _get_grade(score: float) -> str:
    """점수를 등급으로 변환"""
    if score >= 95:
        return "A+"
    elif score >= 90:
        return "A"
    elif score >= 85:
        return "B+"
    elif score >= 80:
        return "B"
    elif score >= 75:
        return "C+"
    elif score >= 70:
        return "C"
    elif score >= 60:
        return "D"
    else:
        return "F"


def _get_improvement_suggestions(
    health_scores: Dict[str, Dict],
    alerts: List[Dict[str, Any]]
) -> List[str]:
    """개선 제안사항 생성"""
    suggestions = []
    
    # 점수 기반 제안
    for data_type, metrics in health_scores.items():
        if metrics["score"] < 80:
            if metrics["components"]["completeness"] < 90:
                suggestions.append(f"{data_type} 데이터의 누락된 기간에 대한 재수집을 권장합니다.")
            
            if metrics["components"]["validity"] < 90:
                suggestions.append(f"{data_type} 데이터의 검증 오류를 수정하세요.")
            
            if metrics["components"]["duplicates"] > 5:
                suggestions.append(f"{data_type} 데이터의 중복을 제거하세요.")
    
    # 알림 기반 제안
    alert_types = set(alert["type"] for alert in alerts)
    if "low_completeness" in alert_types:
        suggestions.append("데이터 수집 스케줄러의 안정성을 점검하세요.")
    
    if "duplicates_found" in alert_types:
        suggestions.append("데이터 수집시 중복 검사 로직을 강화하세요.")
    
    if not suggestions:
        suggestions.append("현재 데이터 품질이 우수합니다. 정기적인 모니터링을 계속하세요.")
    
    return suggestions


@router.get("/stats")
async def get_integrity_check_stats():
    """무결성 검사 통계 조회"""
    try:
        # 최근 검사 결과 통계
        recent_checks = sorted(
            _integrity_checks.values(),
            key=lambda x: x["started_at"],
            reverse=True
        )[:10]
        
        # 상태별 통계
        status_counts = {}
        for check in _integrity_checks.values():
            status = check["status"]
            status_counts[status] = status_counts.get(status, 0) + 1
        
        # 성공률 계산
        total_checks = len(_integrity_checks)
        successful_checks = len([c for c in _integrity_checks.values() if c.get("success", False)])
        success_rate = successful_checks / total_checks if total_checks > 0 else 0
        
        return {
            "total_checks": total_checks,
            "status_summary": status_counts,
            "success_rate": round(success_rate, 3),
            "recent_checks": recent_checks,
            "service_status": {
                "validator_active": True,
                "last_check": max((c["started_at"] for c in _integrity_checks.values()), default=None),
                "check_frequency": "on-demand",
                "supported_data_types": ["ohlcv", "investor_trading", "dart"]
            }
        }
        
    except Exception as e:
        logger.error(f"무결성 검사 통계 조회 실패: {e}")
        raise HTTPException(status_code=500, detail=f"통계 조회 실패: {str(e)}")
