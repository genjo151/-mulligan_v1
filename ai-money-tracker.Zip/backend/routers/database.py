# AI 머니 트래커 - 데이터베이스 관련 API 엔드포인트

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from typing import List, Dict, Any
from datetime import date, datetime
from loguru import logger

from backend.database.base import get_db_session
from backend.database.repositories import (
    StockInfoRepository, DailyPriceRepository, 
    InvestorTradingRepository, StockScoreRepository
)
from backend.database.models import StockInfo, DailyPrice, StockScore
from backend.models.schemas import ApiResponse

router = APIRouter(prefix="/api/v1/database", tags=["database"])

@router.get("/stocks", response_model=List[Dict[str, Any]])
async def get_all_stocks(
    market_type: str = Query(None, description="시장 구분 (KOSPI/KOSDAQ)"),
    sector: str = Query(None, description="업종"),
    limit: int = Query(100, ge=1, le=1000, description="조회 개수"),
    db: AsyncSession = Depends(get_db_session)
):
    """
    전체 종목 목록 조회
    
    Args:
        market_type: 시장 구분 필터
        sector: 업종 필터
        limit: 조회 개수 제한
        db: 데이터베이스 세션
    
    Returns:
        종목 목록
    """
    try:
        logger.info(f"전체 종목 조회: market_type={market_type}, sector={sector}, limit={limit}")
        
        repo = StockInfoRepository(db)
        stocks = await repo.get_all(market_type=market_type, sector=sector)
        
        # 제한 적용
        stocks = stocks[:limit]
        
        # 딕셔너리로 변환
        result = []
        for stock in stocks:
            result.append({
                "stock_code": stock.stock_code,
                "stock_name": stock.stock_name,
                "market_type": stock.market_type,
                "sector": stock.sector,
                "listing_date": stock.listing_date.isoformat() if stock.listing_date else None,
                "market_cap": stock.market_cap,
                "shares_outstanding": stock.shares_outstanding,
                "created_at": stock.created_at.isoformat(),
                "updated_at": stock.updated_at.isoformat()
            })
        
        logger.info(f"종목 조회 완료: {len(result)}개")
        return result
        
    except Exception as e:
        logger.error(f"종목 조회 실패: {e}")
        raise HTTPException(status_code=500, detail=f"종목 조회 실패: {str(e)}")

@router.post("/stocks", response_model=ApiResponse)
async def create_stock(
    stock_data: Dict[str, Any],
    db: AsyncSession = Depends(get_db_session)
):
    """
    새 종목 생성
    
    Args:
        stock_data: 종목 데이터
        db: 데이터베이스 세션
    
    Returns:
        생성 결과
    """
    try:
        logger.info(f"종목 생성 요청: {stock_data.get('stock_code')}")
        
        repo = StockInfoRepository(db)
        
        # 중복 체크
        existing_stock = await repo.get_by_code(stock_data.get('stock_code'))
        if existing_stock:
            raise HTTPException(status_code=400, detail="이미 존재하는 종목코드입니다")
        
        # 종목 생성
        created_stock = await repo.create(stock_data)
        
        logger.info(f"종목 생성 완료: {created_stock.stock_code}")
        
        return ApiResponse(
            success=True,
            message=f"종목 {created_stock.stock_code} 생성 완료",
            data={
                "stock_code": created_stock.stock_code,
                "stock_name": created_stock.stock_name
            }
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"종목 생성 실패: {e}")
        raise HTTPException(status_code=500, detail=f"종목 생성 실패: {str(e)}")

@router.get("/stocks/{stock_code}/prices")
async def get_stock_prices(
    stock_code: str,
    days: int = Query(60, ge=1, le=365, description="조회할 일수"),
    db: AsyncSession = Depends(get_db_session)
):
    """
    종목의 일봉 데이터 조회
    
    Args:
        stock_code: 종목코드
        days: 조회할 일수
        db: 데이터베이스 세션
    
    Returns:
        일봉 데이터 목록
    """
    try:
        logger.info(f"일봉 데이터 조회: {stock_code}, {days}일")
        
        repo = DailyPriceRepository(db)
        prices = await repo.get_latest_by_stock(stock_code, days)
        
        result = []
        for price in prices:
            result.append({
                "date": price.date.isoformat(),
                "open": price.open_price,
                "high": price.high_price,
                "low": price.low_price,
                "close": price.close_price,
                "volume": price.volume,
                "trading_value": price.trading_value,
                "ma5": price.ma5,
                "ma20": price.ma20,
                "ma60": price.ma60,
                "bb_width": price.bb_width
            })
        
        logger.info(f"일봉 데이터 조회 완료: {len(result)}건")
        return result
        
    except Exception as e:
        logger.error(f"일봉 데이터 조회 실패: {e}")
        raise HTTPException(status_code=500, detail=f"일봉 데이터 조회 실패: {str(e)}")

@router.get("/stocks/{stock_code}/investor-trading")
async def get_investor_trading(
    stock_code: str,
    days: int = Query(60, ge=1, le=365, description="조회할 일수"),
    db: AsyncSession = Depends(get_db_session)
):
    """
    종목의 투자자별 매매동향 조회
    
    Args:
        stock_code: 종목코드
        days: 조회할 일수
        db: 데이터베이스 세션
    
    Returns:
        투자자별 매매동향 데이터
    """
    try:
        logger.info(f"투자자별 매매동향 조회: {stock_code}, {days}일")
        
        repo = InvestorTradingRepository(db)
        
        # 순매수 집계 조회
        net_summary = await repo.get_net_buying_summary(stock_code, days)
        
        logger.info(f"투자자별 매매동향 조회 완료")
        return {
            "stock_code": stock_code,
            "period_days": days,
            "summary": net_summary,
            "analysis_date": date.today().isoformat()
        }
        
    except Exception as e:
        logger.error(f"투자자별 매매동향 조회 실패: {e}")
        raise HTTPException(status_code=500, detail=f"매매동향 조회 실패: {str(e)}")

@router.get("/stocks/{stock_code}/scores")
async def get_stock_scores(
    stock_code: str,
    days: int = Query(30, ge=1, le=90, description="조회할 일수"),
    db: AsyncSession = Depends(get_db_session)
):
    """
    종목의 점수 히스토리 조회
    
    Args:
        stock_code: 종목코드
        days: 조회할 일수
        db: 데이터베이스 세션
    
    Returns:
        점수 히스토리
    """
    try:
        logger.info(f"점수 히스토리 조회: {stock_code}, {days}일")
        
        repo = StockScoreRepository(db)
        
        # 최신 점수
        latest_score = await repo.get_latest_by_stock(stock_code)
        
        # 점수 히스토리
        score_history = await repo.get_score_history(stock_code, days)
        
        result = {
            "stock_code": stock_code,
            "latest_score": None,
            "score_history": []
        }
        
        if latest_score:
            result["latest_score"] = {
                "date": latest_score.date.isoformat(),
                "total_score": latest_score.total_score,
                "core_score": latest_score.total_core_score,
                "dart_score": latest_score.total_dart_score,
                "grade": latest_score.grade,
                "core_breakdown": {
                    "core1": latest_score.core1_institution_foreign,
                    "core2": latest_score.core2_obv_uptrend,
                    "core3": latest_score.core3_volatility_squeeze,
                    "core4": latest_score.core4_relative_strength,
                    "core5": latest_score.core5_accumulation_candles
                }
            }
        
        for score in score_history:
            result["score_history"].append({
                "date": score.date.isoformat(),
                "total_score": score.total_score,
                "core_score": score.total_core_score,
                "dart_score": score.total_dart_score,
                "grade": score.grade
            })
        
        logger.info(f"점수 히스토리 조회 완료: {len(score_history)}건")
        return result
        
    except Exception as e:
        logger.error(f"점수 히스토리 조회 실패: {e}")
        raise HTTPException(status_code=500, detail=f"점수 조회 실패: {str(e)}")

@router.get("/top-scores")
async def get_top_scores(
    min_score: float = Query(5.5, ge=0.0, le=10.0, description="최소 점수"),
    limit: int = Query(50, ge=1, le=200, description="조회 개수"),
    target_date: str = Query(None, description="조회 날짜 (YYYY-MM-DD)"),
    db: AsyncSession = Depends(get_db_session)
):
    """
    상위 점수 종목 조회
    
    Args:
        min_score: 최소 점수 기준
        limit: 조회 개수
        target_date: 조회 날짜
        db: 데이터베이스 세션
    
    Returns:
        상위 점수 종목 목록
    """
    try:
        logger.info(f"상위 점수 종목 조회: min_score={min_score}, limit={limit}")
        
        repo = StockScoreRepository(db)
        
        # 날짜 파싱
        query_date = date.today()
        if target_date:
            query_date = datetime.strptime(target_date, "%Y-%m-%d").date()
        
        # 상위 점수 조회
        top_scores = await repo.get_top_scores(query_date, min_score, limit)
        
        result = []
        for score in top_scores:
            result.append({
                "stock_code": score.stock_code,
                "stock_name": score.stock.stock_name if score.stock else None,
                "total_score": score.total_score,
                "core_score": score.total_core_score,
                "dart_score": score.total_dart_score,
                "grade": score.grade,
                "date": score.date.isoformat()
            })
        
        logger.info(f"상위 점수 종목 조회 완료: {len(result)}개")
        return {
            "query_date": query_date.isoformat(),
            "min_score": min_score,
            "total_count": len(result),
            "stocks": result
        }
        
    except Exception as e:
        logger.error(f"상위 점수 조회 실패: {e}")
        raise HTTPException(status_code=500, detail=f"상위 점수 조회 실패: {str(e)}")

@router.get("/stats")
async def get_database_stats(db: AsyncSession = Depends(get_db_session)):
    """
    데이터베이스 통계 조회
    
    Args:
        db: 데이터베이스 세션
    
    Returns:
        데이터베이스 통계
    """
    try:
        logger.info("데이터베이스 통계 조회")
        
        from sqlalchemy import func, select
        from backend.database.models import StockInfo, DailyPrice, InvestorTrading, StockScore
        
        # 각 테이블의 레코드 수 조회
        stock_count = await db.execute(select(func.count(StockInfo.stock_code)))
        stock_count = stock_count.scalar()
        
        price_count = await db.execute(select(func.count(DailyPrice.id)))
        price_count = price_count.scalar()
        
        trading_count = await db.execute(select(func.count(InvestorTrading.id)))
        trading_count = trading_count.scalar()
        
        score_count = await db.execute(select(func.count(StockScore.id)))
        score_count = score_count.scalar()
        
        result = {
            "database_stats": {
                "stocks_count": stock_count,
                "daily_prices_count": price_count,
                "investor_trading_count": trading_count,
                "stock_scores_count": score_count
            },
            "last_updated": datetime.now().isoformat()
        }
        
        logger.info("데이터베이스 통계 조회 완료")
        return result
        
    except Exception as e:
        logger.error(f"데이터베이스 통계 조회 실패: {e}")
        raise HTTPException(status_code=500, detail=f"통계 조회 실패: {str(e)}")
