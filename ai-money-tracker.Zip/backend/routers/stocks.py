# AI 머니 트래커 - 주식 관련 API 엔드포인트

from fastapi import APIRouter, HTTPException, Depends, Query
from typing import List, Dict, Optional
from datetime import datetime, timedelta
import asyncio
from loguru import logger

from backend.models.schemas import (
    StockRecommendation, StockDetail, StockScoreHistory,
    StockAnalysisResult, CoreScores, OHLCVData,
    InvestorTradingData, ApiResponse
)
from backend.config import get_stock_api_key
from backend.services.stock_api import StockApiClient, StockDataProcessor

router = APIRouter(prefix="/api/v1/stocks", tags=["stocks"])

async def get_stock_api_client(api_key: str = Depends(get_stock_api_key)) -> StockApiClient:
    """증권사 API 클라이언트 의존성"""
    # 테스트/개발 환경에서는 더미 키 허용
    if not api_key:
        api_key = "TEST_STOCK_API_KEY_1234567890"
        logger.warning("API 키가 없어 테스트용 키 사용")
    
    client = StockApiClient(api_key)
    
    # 연결 테스트 (실패해도 진행)
    try:
        is_connected, message = await client.test_connection()
        if not is_connected:
            logger.warning(f"증권사 API 연결 경고: {message}")
    except Exception as e:
        logger.warning(f"API 연결 테스트 실패, 계속 진행: {e}")
    
    return client

@router.get("/recommended", response_model=List[StockRecommendation])
async def get_recommended_stocks(
    limit: int = Query(default=10, ge=1, le=50),
    min_score: float = Query(default=3.0, ge=0.0, le=5.0)
) -> List[StockRecommendation]:
    """
    추천 종목 목록 조회
    
    Args:
        limit: 조회할 종목 수 (1-50)
        min_score: 최소 점수 필터 (0.0-5.0)
    
    Returns:
        추천 종목 목록
    """
    try:
        logger.info(f"추천 종목 조회 요청: limit={limit}, min_score={min_score}")
        
        # 실제 구현에서는 데이터베이스에서 조회하거나 실시간 스캔 결과 반환
        # 현재는 테스트 데이터 반환
        test_recommendations = [
            StockRecommendation(
                stock_code="005930",
                stock_name="삼성전자",
                current_price=76000,
                total_score=4.2,
                core_score=3.8,
                dart_score=2.1,
                last_updated=datetime.now(),
                recommendation_reason="기관·외국인 순매수 강세, 변동성 수축 확인"
            ),
            StockRecommendation(
                stock_code="000660",
                stock_name="SK하이닉스",
                current_price=128000,
                total_score=3.9,
                core_score=3.5,
                dart_score=1.9,
                last_updated=datetime.now(),
                recommendation_reason="OBV 우상향, 상대강도 개선"
            ),
            StockRecommendation(
                stock_code="035420",
                stock_name="NAVER",
                current_price=195000,
                total_score=3.6,
                core_score=3.2,
                dart_score=1.8,
                last_updated=datetime.now(),
                recommendation_reason="매집봉 패턴 확인, 기관 매수세"
            )
        ]
        
        # 최소 점수 필터 적용
        filtered_stocks = [
            stock for stock in test_recommendations 
            if stock.total_score >= min_score
        ]
        
        # 점수 순으로 정렬하고 제한 적용
        filtered_stocks.sort(key=lambda x: x.total_score, reverse=True)
        result = filtered_stocks[:limit]
        
        logger.info(f"추천 종목 조회 완료: {len(result)}개 종목")
        return result
        
    except Exception as e:
        logger.error(f"추천 종목 조회 실패: {e}")
        raise HTTPException(status_code=500, detail=f"추천 종목 조회 실패: {str(e)}")

@router.get("/{stock_code}", response_model=StockDetail)
async def get_stock_detail(
    stock_code: str,
    client: StockApiClient = Depends(get_stock_api_client)
) -> StockDetail:
    """
    종목 상세 정보 조회
    
    Args:
        stock_code: 종목코드 (예: 005930)
        client: 증권사 API 클라이언트
    
    Returns:
        종목 상세 정보
    """
    try:
        logger.info(f"종목 상세 정보 조회: {stock_code}")
        
        # 데이터 처리기 생성
        processor = StockDataProcessor(client)
        
        # 완전한 분석 데이터 조회
        analysis_result = await processor.get_complete_stock_analysis(stock_code)
        
        # 실제 구현에서는 종목명 등 추가 정보를 다른 API에서 조회
        stock_name_map = {
            "005930": "삼성전자",
            "000660": "SK하이닉스",
            "035420": "NAVER"
        }
        
        stock_name = stock_name_map.get(stock_code, f"종목{stock_code}")
        current_price = analysis_result["ohlcv_data"][0]["close"] if analysis_result["ohlcv_data"] else 0
        
        # StockDetail 객체 생성
        detail = StockDetail(
            stock_code=stock_code,
            stock_name=stock_name,
            current_price=current_price,
            total_score=analysis_result["total_core_score"],
            core_score=analysis_result["total_core_score"],  # 현재는 코어 점수만
            dart_score=0.0,  # DART 점수는 별도 계산 필요
            price_change=0,  # 실제 구현에서는 전일 대비 계산
            price_change_rate=0.0,
            volume=analysis_result["ohlcv_data"][0]["volume"] if analysis_result["ohlcv_data"] else 0,
            market_cap=0,  # 실제 구현에서는 시가총액 계산
            sector="기술주",  # 실제 구현에서는 섹터 정보 조회
            core_scores=CoreScores(**analysis_result["core_scores"]),
            recent_ohlcv=analysis_result["ohlcv_data"][:5],  # 최근 5일
            last_updated=datetime.now()
        )
        
        logger.info(f"종목 상세 정보 조회 완료: {stock_code}")
        return detail
        
    except Exception as e:
        logger.error(f"종목 상세 정보 조회 실패: {stock_code}, 오류: {e}")
        raise HTTPException(status_code=500, detail=f"종목 상세 정보 조회 실패: {str(e)}")

@router.get("/{stock_code}/score-history", response_model=List[StockScoreHistory])
async def get_stock_score_history(
    stock_code: str,
    days: int = Query(default=30, ge=1, le=90)
) -> List[StockScoreHistory]:
    """
    종목 점수 히스토리 조회
    
    Args:
        stock_code: 종목코드
        days: 조회할 일수 (1-90일)
    
    Returns:
        점수 히스토리 목록
    """
    try:
        logger.info(f"종목 점수 히스토리 조회: {stock_code}, 기간: {days}일")
        
        # 실제 구현에서는 데이터베이스에서 히스토리 조회
        # 현재는 테스트 데이터 생성
        history = []
        base_score = 3.5
        
        for i in range(days):
            date_obj = datetime.now() - timedelta(days=i)
            
            # 점수 변동 시뮬레이션
            score_variation = (i % 10 - 5) * 0.1  # -0.5 ~ +0.4 범위
            total_score = max(0.0, min(5.0, base_score + score_variation))
            
            history.append(StockScoreHistory(
                date=date_obj.date(),
                total_score=total_score,
                core_score=total_score * 0.7,  # 코어 점수가 70%
                dart_score=total_score * 0.3,  # DART 점수가 30%
                price=76000 + (i % 20 - 10) * 1000  # 가격 변동 시뮬레이션
            ))
        
        # 날짜 순으로 정렬 (오래된 것부터)
        history.sort(key=lambda x: x.date)
        
        logger.info(f"종목 점수 히스토리 조회 완료: {len(history)}건")
        return history
        
    except Exception as e:
        logger.error(f"종목 점수 히스토리 조회 실패: {stock_code}, 오류: {e}")
        raise HTTPException(status_code=500, detail=f"점수 히스토리 조회 실패: {str(e)}")

@router.get("/{stock_code}/analysis", response_model=StockAnalysisResult)
async def get_stock_analysis(
    stock_code: str,
    client: StockApiClient = Depends(get_stock_api_client)
) -> StockAnalysisResult:
    """
    종목 심화 분석 결과 조회
    
    Args:
        stock_code: 종목코드
        client: 증권사 API 클라이언트
    
    Returns:
        심화 분석 결과
    """
    try:
        logger.info(f"종목 심화 분석 시작: {stock_code}")
        
        # 데이터 처리기 생성
        processor = StockDataProcessor(client)
        
        # 완전한 분석 데이터 조회
        analysis_result = await processor.get_complete_stock_analysis(stock_code)
        
        # 분석 결과를 StockAnalysisResult 형태로 변환
        result = StockAnalysisResult(
            stock_code=stock_code,
            analysis_timestamp=datetime.fromisoformat(analysis_result["analysis_timestamp"]),
            core_scores=CoreScores(**analysis_result["core_scores"]),
            total_core_score=analysis_result["total_core_score"],
            ohlcv_data=[OHLCVData(**item) for item in analysis_result["ohlcv_data"][:10]],
            investor_data=[InvestorTradingData(**item) for item in analysis_result["investor_data"][:10]],
            analysis_summary=f"총 {analysis_result['total_core_score']:.1f}/5.0점 달성",
            recommendations=[
                "기관·외국인 순매수 모니터링 지속",
                "변동성 수축 구간 진입 확인",
                "매집봉 패턴 발생 시 매수 타이밍 고려"
            ]
        )
        
        logger.info(f"종목 심화 분석 완료: {stock_code}")
        return result
        
    except Exception as e:
        logger.error(f"종목 심화 분석 실패: {stock_code}, 오류: {e}")
        raise HTTPException(status_code=500, detail=f"심화 분석 실패: {str(e)}")

@router.get("/{stock_code}/core-scores", response_model=CoreScores)
async def get_core_scores(
    stock_code: str,
    client: StockApiClient = Depends(get_stock_api_client)
) -> CoreScores:
    """
    종목의 코어 5요소 점수만 조회
    
    Args:
        stock_code: 종목코드
        client: 증권사 API 클라이언트
    
    Returns:
        코어 5요소 점수
    """
    try:
        logger.info(f"코어 5요소 점수 조회: {stock_code}")
        
        # 데이터 처리기 생성
        processor = StockDataProcessor(client)
        
        # 완전한 분석 데이터 조회
        analysis_result = await processor.get_complete_stock_analysis(stock_code)
        
        # 코어 점수만 반환
        core_scores = CoreScores(**analysis_result["core_scores"])
        
        logger.info(f"코어 5요소 점수 조회 완료: {stock_code}")
        return core_scores
        
    except Exception as e:
        logger.error(f"코어 5요소 점수 조회 실패: {stock_code}, 오류: {e}")
        raise HTTPException(status_code=500, detail=f"코어 점수 조회 실패: {str(e)}")

@router.post("/{stock_code}/test-analysis")
async def test_stock_analysis(
    stock_code: str,
    client: StockApiClient = Depends(get_stock_api_client)
) -> ApiResponse:
    """
    종목 분석 테스트 (개발용)
    
    Args:
        stock_code: 종목코드
        client: 증권사 API 클라이언트
    
    Returns:
        테스트 결과
    """
    try:
        logger.info(f"종목 분석 테스트 시작: {stock_code}")
        
        # 모든 데이터 조회 테스트
        tasks = [
            client.fetch_ohlcv_data(stock_code, 60),
            client.fetch_investor_trading_data(stock_code, 60),
            client.fetch_benchmark_data("KS11", 60)
        ]
        
        ohlcv_data, investor_data, benchmark_data = await asyncio.gather(*tasks)
        
        # 데이터 검증
        test_results = {
            "ohlcv_count": len(ohlcv_data),
            "investor_count": len(investor_data),
            "benchmark_count": len(benchmark_data),
            "data_validation": {
                "ohlcv_valid": all("close" in item for item in ohlcv_data[:5]),
                "investor_valid": all("institution_net" in item for item in investor_data[:5]),
                "benchmark_valid": all("close" in item for item in benchmark_data[:5])
            }
        }
        
        logger.info(f"종목 분석 테스트 완료: {stock_code}")
        
        return ApiResponse(
            success=True,
            message=f"종목 {stock_code} 분석 테스트 성공",
            data=test_results
        )
        
    except Exception as e:
        logger.error(f"종목 분석 테스트 실패: {stock_code}, 오류: {e}")
        return ApiResponse(
            success=False,
            message=f"분석 테스트 실패: {str(e)}",
            data=None
        )