@echo off
echo ========================================
echo    🚀 AI 머니 트래커 배포 도구
echo ========================================
echo.

:MENU
echo 배포 방법을 선택하세요:
echo.
echo [1] 🐙 GitHub에 코드 업로드
echo [2] 🐳 Docker 이미지 빌드
echo [3] 📦 배포 파일 압축
echo [4] 🔧 환경변수 설정
echo [5] ❌ 종료
echo.
set /p choice="선택 (1-5): "

if "%choice%"=="1" goto GITHUB
if "%choice%"=="2" goto DOCKER
if "%choice%"=="3" goto PACKAGE
if "%choice%"=="4" goto ENV_SETUP
if "%choice%"=="5" goto EXIT
goto MENU

:GITHUB
cls
echo 🐙 GitHub에 코드 업로드 중...
echo.
git init
git add .
git commit -m "AI Money Tracker deployment ready"
echo.
echo GitHub 저장소 URL을 입력하세요:
set /p repo_url="URL: "
git remote add origin %repo_url%
git branch -M main
git push -u origin main
echo.
echo ✅ GitHub 업로드 완료!
echo 이제 Railway나 Render에서 이 저장소를 연결하세요.
pause
goto MENU

:DOCKER
cls
echo 🐳 Docker 이미지 빌드 중...
echo.
docker build -t ai-money-tracker .
echo.
echo Docker 이미지 빌드 완료!
echo 실행하려면: docker run -p 8018:8018 ai-money-tracker
pause
goto MENU

:PACKAGE
cls
echo 📦 배포용 파일 압축 중...
echo.
powershell Compress-Archive -Path *.py,*.txt,*.toml,*.yml,*.yaml,Dockerfile,Procfile,backend,frontend -DestinationPath ai-money-tracker-deploy.zip -Force
echo.
echo ✅ ai-money-tracker-deploy.zip 파일이 생성되었습니다!
echo 이 파일을 서버에 업로드하여 사용하세요.
pause
goto MENU

:ENV_SETUP
cls
echo 🔧 환경변수 설정
echo.
echo 현재 .env 파일:
type .env 2>nul || echo .env 파일이 없습니다.
echo.
echo DART API 키를 입력하세요:
set /p dart_key="DART_API_KEY: "
echo DART_API_KEY=%dart_key% > .env
echo.
echo 주식 API 키를 입력하세요 (선택사항, Enter로 건너뛰기):
set /p stock_key="STOCK_API_KEY: "
if not "%stock_key%"=="" echo STOCK_API_KEY=%stock_key% >> .env
echo.
echo ✅ 환경변수 설정 완료!
pause
goto MENU

:EXIT
echo 👋 배포 도구를 종료합니다.
exit
