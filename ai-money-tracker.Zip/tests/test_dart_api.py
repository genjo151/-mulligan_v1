# AI 머니 트래커 - DART API 연동 테스트

import pytest
import asyncio
from unittest.mock import Mock, patch, AsyncMock
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta

# DART API 클라이언트 테스트를 위한 mock 준비
class TestDartApiClient:
    """DART API 클라이언트 테스트"""
    
    def setup_method(self):
        """각 테스트 전에 실행"""
        self.sample_corp_code_xml = """<?xml version="1.0" encoding="UTF-8"?>
<root>
    <corp_code>005930</corp_code>
    <corp_name>삼성전자</corp_name>
    <stock_code>005930</stock_code>
    <modify_date>20240101</modify_date>
</root>"""
        
        self.sample_majorstock_response = {
            "status": "000",
            "message": "정상",
            "list": [
                {
                    "rcept_no": "20240101000001",
                    "corp_code": "00126380",
                    "corp_name": "삼성전자",
                    "stock_code": "005930",
                    "report_tp": "신규보고",
                    "repror": "테스트펀드",
                    "stkrt": "5.12",
                    "stkrt_irds": "+0.50"
                }
            ]
        }
    
    def test_dart_api_client_initialization(self):
        """DART API 클라이언트 초기화 테스트"""
        # DART API 클라이언트 클래스가 올바르게 초기화되는지 확인
        api_key = "test-dart-api-key-12345"
        
        # 실제 구현에서는 이런 식으로 초기화될 것
        expected_base_url = "https://opendart.fss.or.kr/api"
        expected_api_key = api_key
        
        assert expected_base_url.startswith("https://opendart.fss.or.kr")
        assert len(expected_api_key) > 10
    
    @pytest.mark.asyncio
    @patch('aiohttp.ClientSession.get')
    async def test_fetch_corp_code_success(self, mock_get):
        """종목코드 조회 성공 테스트"""
        # Mock 응답 설정
        mock_response = Mock()
        mock_response.status = 200
        mock_response.text.return_value = self.sample_corp_code_xml
        mock_get.return_value.__aenter__.return_value = mock_response
        
        # 테스트할 함수 호출 (실제 구현에서)
        # result = await dart_client.fetch_corp_code()
        
        # 예상 결과 검증
        expected_corp_codes = ["005930"]  # 파싱된 종목코드들
        assert len(expected_corp_codes) > 0
        assert "005930" in expected_corp_codes
    
    @pytest.mark.asyncio
    @patch('aiohttp.ClientSession.get')
    async def test_fetch_corp_code_api_error(self, mock_get):
        """종목코드 조회 API 오류 테스트"""
        # Mock 응답 설정 (에러 상황)
        mock_response = Mock()
        mock_response.status = 500
        mock_response.text.return_value = "Internal Server Error"
        mock_get.return_value.__aenter__.return_value = mock_response
        
        # 에러 상황에서 적절한 예외가 발생하는지 확인
        # 실제 구현에서는 적절한 예외 처리가 필요
        with pytest.raises(Exception):
            # await dart_client.fetch_corp_code()
            if mock_response.status != 200:
                raise Exception(f"API Error: {mock_response.status}")
    
    def test_parse_corp_code_xml(self):
        """종목코드 XML 파싱 테스트"""
        # XML 파싱 함수 테스트
        def parse_corp_code_xml(xml_content):
            root = ET.fromstring(xml_content)
            corp_codes = []
            
            for corp in root.findall('.//corp_code'):
                if corp.text:
                    corp_codes.append(corp.text)
            
            return corp_codes
        
        result = parse_corp_code_xml(self.sample_corp_code_xml)
        
        assert len(result) > 0
        assert "005930" in result
    
    @pytest.mark.asyncio
    @patch('aiohttp.ClientSession.get')
    async def test_fetch_majorstock_success(self, mock_get):
        """대량보유상황보고서 조회 성공 테스트"""
        # Mock 응답 설정
        mock_response = Mock()
        mock_response.status = 200
        mock_response.json.return_value = self.sample_majorstock_response
        mock_get.return_value.__aenter__.return_value = mock_response
        
        # 테스트할 함수 호출
        # result = await dart_client.fetch_majorstock("005930")
        
        # 예상 결과 검증
        expected_reports = self.sample_majorstock_response["list"]
        assert len(expected_reports) > 0
        assert expected_reports[0]["corp_name"] == "삼성전자"
        assert expected_reports[0]["report_tp"] == "신규보고"
    
    def test_validate_api_key_format(self):
        """DART API 키 형식 검증 테스트"""
        def validate_dart_api_key(api_key):
            if not api_key:
                return False, "API 키가 필요합니다."
            
            if len(api_key) < 20:
                return False, "API 키가 너무 짧습니다."
            
            if not api_key.replace("-", "").isalnum():
                return False, "API 키 형식이 올바르지 않습니다."
            
            return True, "유효한 API 키입니다."
        
        # 유효한 키 테스트
        valid_key = "a" * 40  # 40자리 키
        is_valid, message = validate_dart_api_key(valid_key)
        assert is_valid is True
        
        # 무효한 키 테스트
        invalid_key = "short"
        is_valid, message = validate_dart_api_key(invalid_key)
        assert is_valid is False
        assert "짧습니다" in message
    
    def test_filter_recent_reports(self):
        """최근 보고서 필터링 테스트"""
        def filter_recent_reports(reports, days=60):
            """최근 N일 이내의 보고서만 필터링"""
            cutoff_date = datetime.now() - timedelta(days=days)
            filtered_reports = []
            
            for report in reports:
                # 실제 구현에서는 보고서의 날짜 필드를 파싱해야 함
                # 여기서는 테스트용으로 최근 데이터로 가정
                filtered_reports.append(report)
            
            return filtered_reports
        
        sample_reports = self.sample_majorstock_response["list"]
        result = filter_recent_reports(sample_reports, days=60)
        
        assert len(result) >= 0
        assert isinstance(result, list)
    
    def test_calculate_dart_score_components(self):
        """DART 점수 구성요소 계산 테스트"""
        def calculate_dart_scores(reports):
            """PRD의 DART 6요소 기반 점수 계산"""
            scores = {
                "dart1_new_holder": 0.0,      # 신규 5% 보유자 등장
                "dart2_continuous_increase": 0.0,  # 연속 증가
                "dart3_purpose_upgrade": 0.0,      # 보유목적 상향
                "dart4_investor_type": 0.0,        # 보고자 성격
                "dart5_insider_buy": 0.0,          # 임원·주요주주 순매수
                "dart6_split_purchase": 0.0        # 분할매수 패턴
            }
            
            for report in reports:
                # DART-1: 신규 5% 보유자 등장
                if report.get("report_tp") == "신규보고":
                    scores["dart1_new_holder"] = 1.0
                
                # DART-2: 연속 증가 (실제로는 복잡한 로직 필요)
                stkrt_irds = report.get("stkrt_irds", "")
                if stkrt_irds.startswith("+"):
                    scores["dart2_continuous_increase"] = 0.8
            
            return scores
        
        sample_reports = self.sample_majorstock_response["list"]
        scores = calculate_dart_scores(sample_reports)
        
        assert "dart1_new_holder" in scores
        assert scores["dart1_new_holder"] == 1.0  # 신규보고가 있으므로
        assert "dart2_continuous_increase" in scores
        assert scores["dart2_continuous_increase"] == 0.8  # 증가가 있으므로

class TestDartApiIntegration:
    """DART API 통합 테스트"""
    
    def test_api_endpoint_url_construction(self):
        """API 엔드포인트 URL 구성 테스트"""
        base_url = "https://opendart.fss.or.kr/api"
        api_key = "test-key"
        
        # corpCode.xml URL 구성
        corp_code_url = f"{base_url}/corpCode.xml?crtfc_key={api_key}"
        assert "corpCode.xml" in corp_code_url
        assert api_key in corp_code_url
        
        # majorstock.json URL 구성
        majorstock_url = f"{base_url}/majorstock.json?crtfc_key={api_key}&corp_code=00126380"
        assert "majorstock.json" in majorstock_url
        assert "corp_code=" in majorstock_url
    
    def test_error_handling_scenarios(self):
        """다양한 오류 상황 처리 테스트"""
        error_scenarios = [
            {"status": "013", "message": "API 키가 등록되지 않았습니다."},
            {"status": "020", "message": "요청 제한을 초과했습니다."},
            {"status": "100", "message": "회사 고유번호가 없습니다."}
        ]
        
        for scenario in error_scenarios:
            # 각 오류 상황에 대한 적절한 처리가 있는지 확인
            assert "status" in scenario
            assert "message" in scenario
            assert scenario["status"] != "000"  # 000은 정상 상태

if __name__ == "__main__":
    pytest.main([__file__, "-v"])
