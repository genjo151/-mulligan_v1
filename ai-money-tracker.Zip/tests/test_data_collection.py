# AI 머니 트래커 - 데이터 수집 모듈 테스트

import pytest
import asyncio
from datetime import datetime, date, timedelta
from unittest.mock import Mock, AsyncMock, patch
from typing import List, Dict, Any
import json

# 데이터 수집 모듈 테스트
class TestDataCollectionStrategy:
    """데이터 수집 전략 테스트"""
    
    def test_collection_schedule_requirements(self):
        """데이터 수집 스케줄 요구사항"""
        collection_schedule = {
            "daily_prices": {
                "frequency": "daily",
                "time": "18:00",  # 장 마감 후
                "retry_attempts": 3,
                "retry_delay": 300  # 5분
            },
            "investor_trading": {
                "frequency": "daily", 
                "time": "19:00",  # 일봉 데이터 수집 후
                "retry_attempts": 3,
                "retry_delay": 600  # 10분
            },
            "dart_disclosures": {
                "frequency": "hourly",  # 실시간 모니터링
                "business_hours_only": True,
                "retry_attempts": 5,
                "retry_delay": 180  # 3분
            }
        }
        
        for data_type, schedule in collection_schedule.items():
            assert "frequency" in schedule
            assert "retry_attempts" in schedule
            assert "retry_delay" in schedule
    
    def test_data_source_requirements(self):
        """데이터 소스 요구사항"""
        data_sources = {
            "stock_prices": {
                "primary": "korea_investment_api",
                "backup": "public_data_portal",
                "timeout": 30,
                "rate_limit": 100  # 초당 요청 수
            },
            "investor_trading": {
                "primary": "krx_data_api",
                "backup": "korea_investment_api", 
                "timeout": 60,
                "rate_limit": 50
            },
            "dart_disclosures": {
                "primary": "dart_api",
                "backup": None,
                "timeout": 45,
                "rate_limit": 10000  # 일일 요청 수
            }
        }
        
        for source_type, config in data_sources.items():
            assert "primary" in config
            assert "timeout" in config
            assert "rate_limit" in config

class TestOHLCVDataCollector:
    """일봉 OHLCV 데이터 수집기 테스트"""
    
    def setup_method(self):
        """테스트 설정"""
        self.sample_ohlcv_response = {
            "status": "success",
            "data": [
                {
                    "date": "20241201",
                    "open": "75000",
                    "high": "76500", 
                    "low": "74500",
                    "close": "76000",
                    "volume": "15000000",
                    "value": "1140000000000"
                },
                {
                    "date": "20241130",
                    "open": "74500",
                    "high": "75200",
                    "low": "74000", 
                    "close": "75000",
                    "volume": "12000000",
                    "value": "900000000000"
                }
            ]
        }
    
    def test_ohlcv_collector_initialization(self):
        """OHLCV 수집기 초기화 테스트"""
        collector_config = {
            "api_key": "test_api_key",
            "base_url": "https://openapi.koreainvestment.com",
            "timeout": 30,
            "max_retries": 3,
            "stocks_per_batch": 100,
            "collection_time": "18:00"
        }
        
        for key, value in collector_config.items():
            assert key is not None
            assert value is not None
    
    @pytest.mark.asyncio
    async def test_collect_single_stock_ohlcv(self):
        """단일 종목 OHLCV 수집 테스트"""
        
        async def mock_collect_ohlcv(stock_code: str, days: int = 60):
            """모의 OHLCV 데이터 수집"""
            if stock_code == "005930":
                return self.sample_ohlcv_response["data"]
            return []
        
        # 테스트 실행
        result = await mock_collect_ohlcv("005930", 60)
        
        assert len(result) == 2
        assert result[0]["date"] == "20241201"
        assert result[0]["close"] == "76000"
        assert result[0]["volume"] == "15000000"
    
    @pytest.mark.asyncio
    async def test_collect_multiple_stocks_ohlcv(self):
        """다중 종목 OHLCV 일괄 수집 테스트"""
        
        async def mock_batch_collect_ohlcv(stock_codes: List[str]):
            """모의 일괄 OHLCV 데이터 수집"""
            results = {}
            for code in stock_codes:
                if code in ["005930", "000660"]:
                    results[code] = self.sample_ohlcv_response["data"]
                else:
                    results[code] = []
            return results
        
        stock_codes = ["005930", "000660", "035420"]
        results = await mock_batch_collect_ohlcv(stock_codes)
        
        assert len(results) == 3
        assert len(results["005930"]) == 2
        assert len(results["000660"]) == 2
        assert len(results["035420"]) == 0  # 데이터 없음
    
    def test_ohlcv_data_validation(self):
        """OHLCV 데이터 검증 테스트"""
        
        def validate_ohlcv_data(data: Dict[str, Any]) -> List[str]:
            """OHLCV 데이터 유효성 검증"""
            errors = []
            
            required_fields = ["date", "open", "high", "low", "close", "volume"]
            for field in required_fields:
                if field not in data:
                    errors.append(f"필수 필드 '{field}' 누락")
            
            if "open" in data and "high" in data and "low" in data and "close" in data:
                try:
                    open_price = int(data["open"])
                    high_price = int(data["high"])
                    low_price = int(data["low"])
                    close_price = int(data["close"])
                    
                    if not (low_price <= open_price <= high_price):
                        errors.append("시가가 고가-저가 범위를 벗어남")
                    if not (low_price <= close_price <= high_price):
                        errors.append("종가가 고가-저가 범위를 벗어남")
                except ValueError:
                    errors.append("가격 데이터가 숫자가 아님")
            
            return errors
        
        # 유효한 데이터 테스트
        valid_data = self.sample_ohlcv_response["data"][0]
        errors = validate_ohlcv_data(valid_data)
        assert len(errors) == 0
        
        # 무효한 데이터 테스트
        invalid_data = {
            "date": "20241201",
            "open": "77000",  # 고가보다 높음
            "high": "76000",
            "low": "74000",
            "close": "75000",
            "volume": "10000000"
        }
        errors = validate_ohlcv_data(invalid_data)
        assert len(errors) > 0

class TestInvestorTradingCollector:
    """투자자별 매매동향 수집기 테스트"""
    
    def setup_method(self):
        """테스트 설정"""
        self.sample_trading_response = {
            "status": "success",
            "data": [
                {
                    "date": "20241201",
                    "stock_code": "005930",
                    "individual_buy": "500000000",
                    "individual_sell": "450000000",
                    "institution_buy": "300000000",
                    "institution_sell": "280000000",
                    "foreign_buy": "200000000",
                    "foreign_sell": "180000000"
                }
            ]
        }
    
    @pytest.mark.asyncio
    async def test_collect_investor_trading_data(self):
        """투자자별 매매동향 데이터 수집 테스트"""
        
        async def mock_collect_trading_data(stock_code: str, date: str):
            """모의 매매동향 데이터 수집"""
            if stock_code == "005930":
                return self.sample_trading_response["data"][0]
            return None
        
        result = await mock_collect_trading_data("005930", "20241201")
        
        assert result is not None
        assert result["stock_code"] == "005930"
        assert "individual_buy" in result
        assert "institution_buy" in result
        assert "foreign_buy" in result
    
    def test_calculate_net_trading_amounts(self):
        """순매수 금액 계산 테스트"""
        
        def calculate_net_amounts(trading_data: Dict[str, Any]) -> Dict[str, int]:
            """순매수 금액 계산"""
            individual_net = int(trading_data["individual_buy"]) - int(trading_data["individual_sell"])
            institution_net = int(trading_data["institution_buy"]) - int(trading_data["institution_sell"])
            foreign_net = int(trading_data["foreign_buy"]) - int(trading_data["foreign_sell"])
            
            return {
                "individual_net": individual_net,
                "institution_net": institution_net,
                "foreign_net": foreign_net,
                "institution_foreign_net": institution_net + foreign_net
            }
        
        trading_data = self.sample_trading_response["data"][0]
        net_amounts = calculate_net_amounts(trading_data)
        
        assert net_amounts["individual_net"] == 50000000  # 5천만원 순매수
        assert net_amounts["institution_net"] == 20000000  # 2천만원 순매수
        assert net_amounts["foreign_net"] == 20000000  # 2천만원 순매수
        assert net_amounts["institution_foreign_net"] == 40000000  # 4천만원 순매수

class TestDartDataCollector:
    """DART 공시 데이터 수집기 테스트"""
    
    def setup_method(self):
        """테스트 설정"""
        self.sample_dart_response = {
            "status": "000",
            "message": "정상",
            "list": [
                {
                    "rcept_no": "20241201000001",
                    "flr_nm": "삼성전자",
                    "rcept_dt": "20241201",
                    "rm": "대량보유상황보고서",
                    "stock_code": "005930"
                }
            ]
        }
        
        self.sample_majorstock_response = {
            "status": "000",
            "list": [
                {
                    "rcept_no": "20241201000001",
                    "flr_nm": "삼성전자",
                    "rcept_dt": "20241201",
                    "isu_nm": "삼성전자",
                    "reporter_nm": "테스트투자",
                    "hold_stock_co": "100000000",
                    "hold_stock_rt": "5.25"
                }
            ]
        }
    
    @pytest.mark.asyncio
    async def test_collect_recent_disclosures(self):
        """최근 공시 수집 테스트"""
        
        async def mock_collect_disclosures(date_from: str, date_to: str):
            """모의 공시 데이터 수집"""
            return self.sample_dart_response["list"]
        
        today = date.today().strftime("%Y%m%d")
        result = await mock_collect_disclosures(today, today)
        
        assert len(result) == 1
        assert result[0]["flr_nm"] == "삼성전자"
        assert result[0]["stock_code"] == "005930"
    
    @pytest.mark.asyncio
    async def test_collect_majorstock_details(self):
        """대량보유 상세 정보 수집 테스트"""
        
        async def mock_collect_majorstock(rcept_no: str):
            """모의 대량보유 상세 정보 수집"""
            return self.sample_majorstock_response["list"]
        
        result = await mock_collect_majorstock("20241201000001")
        
        assert len(result) == 1
        assert result[0]["reporter_nm"] == "테스트투자"
        assert float(result[0]["hold_stock_rt"]) >= 5.0  # 5% 이상 보유
    
    def test_filter_relevant_disclosures(self):
        """관련 공시 필터링 테스트"""
        
        def filter_disclosures(disclosures: List[Dict], keywords: List[str]) -> List[Dict]:
            """관련 공시 필터링"""
            filtered = []
            for disclosure in disclosures:
                report_name = disclosure.get("rm", "").lower()
                if any(keyword.lower() in report_name for keyword in keywords):
                    filtered.append(disclosure)
            return filtered
        
        keywords = ["대량보유", "주요사항보고", "임원"]
        test_disclosures = [
            {"rm": "대량보유상황보고서", "rcept_no": "1"},
            {"rm": "주요사항보고서", "rcept_no": "2"},
            {"rm": "분기보고서", "rcept_no": "3"},  # 제외될 것
            {"rm": "임원소유보고서", "rcept_no": "4"}
        ]
        
        filtered = filter_disclosures(test_disclosures, keywords)
        
        assert len(filtered) == 3  # 분기보고서 제외
        rcept_nos = [d["rcept_no"] for d in filtered]
        assert "3" not in rcept_nos

class TestDataIntegrityChecker:
    """데이터 무결성 검증 테스트"""
    
    def test_duplicate_detection(self):
        """중복 데이터 탐지 테스트"""
        
        def detect_duplicates(data_list: List[Dict], key_fields: List[str]) -> List[Dict]:
            """중복 데이터 탐지"""
            seen = set()
            duplicates = []
            
            for item in data_list:
                key = tuple(item.get(field) for field in key_fields)
                if key in seen:
                    duplicates.append(item)
                else:
                    seen.add(key)
            
            return duplicates
        
        test_data = [
            {"stock_code": "005930", "date": "20241201", "close": 76000},
            {"stock_code": "005930", "date": "20241201", "close": 76100},  # 중복
            {"stock_code": "005930", "date": "20241130", "close": 75000},
            {"stock_code": "000660", "date": "20241201", "close": 128000}
        ]
        
        duplicates = detect_duplicates(test_data, ["stock_code", "date"])
        
        assert len(duplicates) == 1
        assert duplicates[0]["close"] == 76100
    
    def test_data_completeness_check(self):
        """데이터 완전성 검사 테스트"""
        
        def check_data_completeness(stock_codes: List[str], date_range: List[str], 
                                   collected_data: List[Dict]) -> Dict[str, List[str]]:
            """데이터 완전성 검사"""
            missing_data = {"stocks": [], "dates": []}
            
            # 수집된 데이터의 종목코드와 날짜 추출
            collected_stocks = set(item["stock_code"] for item in collected_data)
            collected_dates = set(item["date"] for item in collected_data)
            
            # 누락된 종목 확인
            for stock in stock_codes:
                if stock not in collected_stocks:
                    missing_data["stocks"].append(stock)
            
            # 누락된 날짜 확인
            for date_str in date_range:
                if date_str not in collected_dates:
                    missing_data["dates"].append(date_str)
            
            return missing_data
        
        expected_stocks = ["005930", "000660", "035420"]
        expected_dates = ["20241201", "20241130", "20241129"]
        
        incomplete_data = [
            {"stock_code": "005930", "date": "20241201"},
            {"stock_code": "000660", "date": "20241201"},
            # 035420과 일부 날짜 누락
        ]
        
        missing = check_data_completeness(expected_stocks, expected_dates, incomplete_data)
        
        assert "035420" in missing["stocks"]
        assert "20241130" in missing["dates"]
        assert "20241129" in missing["dates"]
    
    def test_data_consistency_validation(self):
        """데이터 일관성 검증 테스트"""
        
        def validate_data_consistency(data: Dict[str, Any]) -> List[str]:
            """데이터 일관성 검증"""
            errors = []
            
            # 날짜 형식 검증
            if "date" in data:
                try:
                    datetime.strptime(data["date"], "%Y%m%d")
                except ValueError:
                    errors.append("날짜 형식이 올바르지 않음")
            
            # 가격 데이터 일관성 검증
            if all(key in data for key in ["open", "high", "low", "close"]):
                prices = [int(data[key]) for key in ["open", "high", "low", "close"]]
                if min(prices) != int(data["low"]) or max(prices) != int(data["high"]):
                    errors.append("가격 데이터 일관성 오류")
            
            # 거래량 검증
            if "volume" in data:
                try:
                    volume = int(data["volume"])
                    if volume < 0:
                        errors.append("거래량이 음수")
                except ValueError:
                    errors.append("거래량이 숫자가 아님")
            
            return errors
        
        # 일관성 있는 데이터
        consistent_data = {
            "date": "20241201",
            "open": "75000",
            "high": "76000", 
            "low": "74000",
            "close": "75500",
            "volume": "10000000"
        }
        
        errors = validate_data_consistency(consistent_data)
        assert len(errors) == 0
        
        # 일관성 없는 데이터
        inconsistent_data = {
            "date": "2024-12-01",  # 잘못된 형식
            "open": "75000",
            "high": "74000",  # 시가보다 낮은 고가
            "low": "76000",   # 고가보다 높은 저가
            "close": "75500",
            "volume": "-1000"  # 음수 거래량
        }
        
        errors = validate_data_consistency(inconsistent_data)
        assert len(errors) > 0

if __name__ == "__main__":
    pytest.main([__file__, "-v"])
