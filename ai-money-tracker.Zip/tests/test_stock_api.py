# AI 머니 트래커 - 증권사 API 연동 테스트

import pytest
import asyncio
from unittest.mock import Mock, patch, AsyncMock
from datetime import datetime, timedelta
import json

# PRD 코어 5요소 테스트
class TestStockApiClient:
    """증권사 API 클라이언트 테스트"""
    
    def setup_method(self):
        """각 테스트 전에 실행"""
        # 샘플 일봉 데이터 (OHLCV)
        self.sample_ohlcv_data = [
            {
                "date": "20241201",
                "open": 75000,
                "high": 76500,
                "low": 74500,
                "close": 76000,
                "volume": 15000000,
                "value": 1140000000000  # 거래대금
            },
            {
                "date": "20241130",
                "open": 74500,
                "high": 75200,
                "low": 74000,
                "close": 75000,
                "volume": 12000000,
                "value": 900000000000
            }
        ]
        
        # 샘플 투자자별 매매동향 데이터
        self.sample_investor_data = [
            {
                "date": "20241201",
                "individual_buy": 500000000,
                "individual_sell": 450000000,
                "individual_net": 50000000,
                "institution_buy": 300000000,
                "institution_sell": 280000000,
                "institution_net": 20000000,
                "foreign_buy": 200000000,
                "foreign_sell": 250000000,
                "foreign_net": -50000000
            }
        ]
        
        # 샘플 벤치마크 데이터 (KOSPI)
        self.sample_benchmark_data = [
            {"date": "20241201", "close": 2500.50},
            {"date": "20241130", "close": 2480.25}
        ]
    
    def test_stock_api_client_initialization(self):
        """증권사 API 클라이언트 초기화 테스트"""
        api_key = "test-stock-api-key-12345"
        
        # 클라이언트 초기화 요구사항
        expected_base_url = "https://openapi.koreainvestment.com"  # 예시
        expected_headers = {
            "Content-Type": "application/json",
            "authorization": f"Bearer {api_key}"
        }
        
        assert len(api_key) > 10
        assert expected_base_url.startswith("https://")
        assert "authorization" in expected_headers
    
    @patch('aiohttp.ClientSession.get')
    @pytest.mark.asyncio
    async def test_fetch_ohlcv_data_success(self, mock_get):
        """일봉 OHLCV 데이터 조회 성공 테스트"""
        # Mock 응답 설정
        mock_response = Mock()
        mock_response.status = 200
        mock_response.json.return_value = {
            "status": "success",
            "data": self.sample_ohlcv_data
        }
        mock_get.return_value.__aenter__.return_value = mock_response
        
        # 실제 구현에서는 이런 식으로 호출될 것
        # result = await stock_client.fetch_ohlcv("005930", period=60)
        
        # 예상 결과 검증
        expected_data = self.sample_ohlcv_data
        assert len(expected_data) > 0
        assert "date" in expected_data[0]
        assert "close" in expected_data[0]
        assert "volume" in expected_data[0]
    
    @patch('aiohttp.ClientSession.get')
    @pytest.mark.asyncio
    async def test_fetch_investor_data_success(self, mock_get):
        """투자자별 매매동향 조회 성공 테스트"""
        # Mock 응답 설정
        mock_response = Mock()
        mock_response.status = 200
        mock_response.json.return_value = {
            "status": "success",
            "data": self.sample_investor_data
        }
        mock_get.return_value.__aenter__.return_value = mock_response
        
        # 예상 결과 검증
        expected_data = self.sample_investor_data[0]
        assert "institution_net" in expected_data
        assert "foreign_net" in expected_data
        assert expected_data["institution_net"] > 0  # 기관 순매수
    
    def test_calculate_core_elements(self):
        """PRD 코어 5요소 계산 테스트"""
        
        def calculate_core_scores(ohlcv_data, investor_data, benchmark_data):
            """코어 5요소 점수 계산 함수"""
            scores = {
                "core1_institution_foreign_60d": 0.0,  # 기관·외국인 60일 누적 순매수
                "core2_obv_uptrend_60d": 0.0,          # OBV 정량 우상향
                "core3_volatility_squeeze": 0.0,        # 변동성 수축 (BBW)
                "core4_relative_strength": 0.0,         # 상대강도(RS) 개선
                "core5_accumulation_candles": 0.0       # 매집봉 패턴
            }
            
            # 코어-1: 기관·외국인 60일 누적 순매수 계산
            total_net_buy = 0
            adv_20 = 0  # 20일 평균 거래대금
            
            for data in investor_data[-60:]:  # 최근 60일
                institution_net = data.get("institution_net", 0)
                foreign_net = data.get("foreign_net", 0)
                total_net_buy += (institution_net + foreign_net)
            
            # ADV_20 계산 (최근 20일 평균 거래대금)
            for data in ohlcv_data[-20:]:
                adv_20 += data.get("value", 0)
            adv_20 = adv_20 / 20 if len(ohlcv_data) >= 20 else 1
            
            # NetBuy_60_norm 계산
            netbuy_60_norm = total_net_buy / (adv_20 * 20) if adv_20 > 0 else 0
            
            if netbuy_60_norm >= 1.0:
                scores["core1_institution_foreign_60d"] = 1.0
            
            # 코어-2: OBV 계산 (간단한 버전)
            obv_values = []
            obv = 0
            
            for i, data in enumerate(ohlcv_data):
                if i > 0:
                    prev_close = ohlcv_data[i-1]["close"]
                    curr_close = data["close"]
                    volume = data["volume"]
                    
                    if curr_close > prev_close:
                        obv += volume
                    elif curr_close < prev_close:
                        obv -= volume
                
                obv_values.append(obv)
            
            # OBV 기울기 및 조건 확인 (간단 버전)
            if len(obv_values) >= 60:
                recent_obv = obv_values[-30:]  # 최근 30일 OBV
                early_obv = obv_values[-60:-30]  # 이전 30일 OBV
                
                recent_avg = sum(recent_obv) / len(recent_obv)
                early_avg = sum(early_obv) / len(early_obv)
                
                if recent_avg > early_avg:  # 상승 추세
                    scores["core2_obv_uptrend_60d"] = 1.0
            
            return scores
        
        # 테스트 실행
        scores = calculate_core_scores(
            self.sample_ohlcv_data, 
            self.sample_investor_data,
            self.sample_benchmark_data
        )
        
        # 결과 검증
        assert "core1_institution_foreign_60d" in scores
        assert "core2_obv_uptrend_60d" in scores
        assert isinstance(scores["core1_institution_foreign_60d"], float)
        assert 0 <= scores["core1_institution_foreign_60d"] <= 1.0
    
    def test_bollinger_bands_calculation(self):
        """볼린저밴드 및 BBW 계산 테스트 (코어-3)"""
        
        def calculate_bollinger_bands(prices, period=20, std_dev=2):
            """볼린저밴드 계산"""
            if len(prices) < period:
                return None, None, None, None
            
            # 이동평균 계산
            ma = sum(prices[-period:]) / period
            
            # 표준편차 계산
            variance = sum([(price - ma) ** 2 for price in prices[-period:]]) / period
            std = variance ** 0.5
            
            # 볼린저밴드 계산
            upper_band = ma + (std_dev * std)
            lower_band = ma - (std_dev * std)
            
            # BBW (Bollinger Band Width) 계산
            bbw = (upper_band - lower_band) / ma if ma > 0 else 0
            
            return upper_band, ma, lower_band, bbw
        
        # 테스트 데이터
        test_prices = [75000, 74500, 76000, 75500, 76500, 77000, 76800, 76200, 75800, 76400,
                      76900, 77200, 76600, 76100, 75900, 76300, 76700, 77100, 76500, 76000]
        
        upper, middle, lower, bbw = calculate_bollinger_bands(test_prices)
        
        assert upper is not None
        assert middle is not None
        assert lower is not None
        assert bbw is not None
        assert upper > middle > lower
        assert bbw > 0
    
    def test_relative_strength_calculation(self):
        """상대강도(RS) 계산 테스트 (코어-4)"""
        
        def calculate_relative_strength(stock_prices, benchmark_prices, period=20):
            """상대강도 계산"""
            if len(stock_prices) < period or len(benchmark_prices) < period:
                return 0
            
            # 20일 수익률 계산
            stock_return = (stock_prices[-1] - stock_prices[-period]) / stock_prices[-period]
            benchmark_return = (benchmark_prices[-1] - benchmark_prices[-period]) / benchmark_prices[-period]
            
            # 상대강도 계산
            rs = stock_return - benchmark_return
            
            return rs
        
        # 테스트 데이터
        stock_prices = [75000, 76000, 77000, 76500, 76800]
        benchmark_prices = [2480, 2485, 2490, 2488, 2492]
        
        rs = calculate_relative_strength(stock_prices, benchmark_prices, period=4)
        
        assert isinstance(rs, float)
        # 상대강도는 양수 또는 음수 가능
    
    def test_accumulation_candle_detection(self):
        """매집봉 패턴 탐지 테스트 (코어-5)"""
        
        def detect_accumulation_candles(ohlcv_data, period=60):
            """매집봉 패턴 탐지"""
            accumulation_count = 0
            
            for data in ohlcv_data[-period:]:
                open_price = data["open"]
                high_price = data["high"]
                low_price = data["low"]
                close_price = data["close"]
                volume = data["volume"]
                
                # 캔들 전체 길이
                candle_body = abs(close_price - open_price)
                candle_total = high_price - low_price
                
                # 윗꼬리 길이
                upper_shadow = high_price - max(open_price, close_price)
                
                # 윗꼬리 비율 (60% 이상)
                if candle_total > 0:
                    upper_shadow_ratio = upper_shadow / candle_total
                    
                    # 긴 윗꼬리 + 거래량 조건 (간단 버전)
                    if upper_shadow_ratio >= 0.6 and volume > 1000000:  # 임시 거래량 기준
                        accumulation_count += 1
            
            return accumulation_count
        
        # 매집봉 패턴이 있는 테스트 데이터
        test_data = [
            {"open": 75000, "high": 77000, "low": 74500, "close": 75200, "volume": 15000000},  # 긴 윗꼬리
            {"open": 76000, "high": 78000, "low": 75800, "close": 76100, "volume": 12000000}   # 긴 윗꼬리
        ]
        
        count = detect_accumulation_candles(test_data)
        
        assert isinstance(count, int)
        assert count >= 0

class TestStockApiIntegration:
    """증권사 API 통합 테스트"""
    
    def test_api_key_validation(self):
        """증권사 API 키 검증 테스트"""
        
        def validate_stock_api_key(api_key):
            """증권사 API 키 유효성 검증"""
            if not api_key:
                return False, "API 키가 필요합니다."
            
            if len(api_key) < 10:
                return False, "API 키가 너무 짧습니다."
            
            # 한국투자증권의 경우 특정 패턴이 있을 수 있음
            if not api_key.replace("-", "").replace("_", "").isalnum():
                return False, "API 키 형식이 올바르지 않습니다."
            
            return True, "유효한 API 키입니다."
        
        # 유효한 키 테스트
        valid_key = "KIS_API_KEY_1234567890"
        is_valid, message = validate_stock_api_key(valid_key)
        assert is_valid is True
        
        # 무효한 키 테스트
        invalid_key = "short"
        is_valid, message = validate_stock_api_key(invalid_key)
        assert is_valid is False
    
    def test_error_handling_scenarios(self):
        """다양한 오류 상황 처리 테스트"""
        error_scenarios = [
            {"status": 401, "message": "인증 실패"},
            {"status": 429, "message": "요청 한도 초과"},
            {"status": 500, "message": "서버 오류"}
        ]
        
        for scenario in error_scenarios:
            assert "status" in scenario
            assert "message" in scenario
            assert scenario["status"] >= 400  # HTTP 오류 코드
    
    def test_data_consistency_validation(self):
        """데이터 일관성 검증 테스트"""
        
        def validate_ohlcv_data(data):
            """OHLCV 데이터 일관성 검증"""
            errors = []
            
            for item in data:
                # 필수 필드 확인
                required_fields = ["date", "open", "high", "low", "close", "volume"]
                for field in required_fields:
                    if field not in item:
                        errors.append(f"필수 필드 '{field}' 누락")
                
                # 가격 논리 검증
                if all(key in item for key in ["open", "high", "low", "close"]):
                    if not (item["low"] <= item["open"] <= item["high"]):
                        errors.append("시가가 고가-저가 범위를 벗어남")
                    if not (item["low"] <= item["close"] <= item["high"]):
                        errors.append("종가가 고가-저가 범위를 벗어남")
                
                # 거래량 검증
                if "volume" in item and item["volume"] < 0:
                    errors.append("거래량이 음수입니다")
            
            return errors
        
        # 유효한 데이터 테스트
        valid_data = [
            {"date": "20241201", "open": 75000, "high": 76000, "low": 74500, "close": 75500, "volume": 1000000}
        ]
        errors = validate_ohlcv_data(valid_data)
        assert len(errors) == 0
        
        # 무효한 데이터 테스트
        invalid_data = [
            {"date": "20241201", "open": 77000, "high": 76000, "low": 74500, "close": 75500, "volume": -1000}
        ]
        errors = validate_ohlcv_data(invalid_data)
        assert len(errors) > 0

if __name__ == "__main__":
    pytest.main([__file__, "-v"])
