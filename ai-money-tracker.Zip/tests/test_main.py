# AI 머니 트래커 - 백엔드 메인 테스트

import pytest
import asyncio
from fastapi.testclient import TestClient
from backend.main import app

# 테스트 클라이언트 생성
client = TestClient(app)

class TestMainEndpoints:
    """메인 엔드포인트 테스트 클래스"""
    
    def test_read_root(self):
        """루트 엔드포인트 테스트"""
        response = client.get("/")
        assert response.status_code == 200
        
        # JSON 응답인 경우 (프론트엔드 파일이 없을 때)
        if response.headers.get("content-type") == "application/json":
            data = response.json()
            assert "message" in data
            assert "version" in data
            assert data["message"] == "AI 머니 트래커 API"
            assert data["version"] == "1.0.0"
    
    def test_health_check(self):
        """헬스 체크 엔드포인트 테스트"""
        response = client.get("/health")
        assert response.status_code == 200
        
        data = response.json()
        assert data["status"] == "healthy"
        assert data["service"] == "ai-money-tracker"
    
    def test_cors_headers(self):
        """CORS 미들웨어 설정 확인 (실제 브라우저에서만 작동)"""
        # TestClient는 CORS 헤더를 자동으로 추가하지 않음
        # 대신 응답이 정상적으로 오는지 확인
        response = client.get("/health")
        assert response.status_code == 200
        
        # JSON 응답 확인
        data = response.json()
        assert "status" in data

class TestAPIIntegration:
    """API 통합 테스트 클래스"""
    
    def test_api_not_found(self):
        """존재하지 않는 엔드포인트 테스트"""
        response = client.get("/nonexistent-endpoint")
        assert response.status_code == 404
    
    def test_method_not_allowed(self):
        """허용되지 않는 HTTP 메서드 테스트"""
        response = client.post("/health")
        # POST는 허용되지 않으므로 405 또는 400 응답
        assert response.status_code in [405, 422]

if __name__ == "__main__":
    # 테스트 실행
    pytest.main([__file__, "-v"])
