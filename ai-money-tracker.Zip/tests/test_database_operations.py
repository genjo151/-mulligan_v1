# AI 머니 트래커 - 데이터베이스 실제 작업 테스트

import pytest
import asyncio
from datetime import datetime, date, timedelta
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.orm import sessionmaker
import tempfile
import os

from backend.database.base import Base
from backend.database.models import StockInfo, DailyPrice, InvestorTrading, StockScore
from backend.database.repositories import (
    StockInfoRepository, DailyPriceRepository, 
    InvestorTradingRepository, StockScoreRepository
)

class TestDatabaseCRUD:
    """데이터베이스 CRUD 작업 테스트"""
    
    @pytest.fixture
    def async_session(self):
        """비동기 테스트 세션 픽스처"""
        # 임시 SQLite 데이터베이스 생성
        temp_file = tempfile.NamedTemporaryFile(delete=False, suffix=".db")
        temp_file.close()
        
        database_url = f"sqlite+aiosqlite:///{temp_file.name}"
        engine = create_async_engine(database_url, echo=False)
        
        # 테이블 생성
        async with engine.begin() as conn:
            await conn.run_sync(Base.metadata.create_all)
        
        # 세션 팩토리 생성
        SessionLocal = sessionmaker(
            engine, class_=AsyncSession, expire_on_commit=False
        )
        
        session = SessionLocal()
        try:
            yield session
        finally:
            await session.close()
            await engine.dispose()
            os.unlink(temp_file.name)
    
    @pytest.mark.asyncio
    async def test_stock_info_crud(self, async_session):
        """종목 정보 CRUD 테스트"""
        repo = StockInfoRepository(async_session)
        
        # 종목 생성
        stock_data = {
            "stock_code": "005930",
            "stock_name": "삼성전자",
            "market_type": "KOSPI",
            "sector": "전자제품",
            "listing_date": date(1975, 6, 11),
            "market_cap": 500000000000000,
            "shares_outstanding": 5969782550
        }
        
        created_stock = await repo.create(stock_data)
        assert created_stock.stock_code == "005930"
        assert created_stock.stock_name == "삼성전자"
        
        # 종목 조회
        retrieved_stock = await repo.get_by_code("005930")
        assert retrieved_stock is not None
        assert retrieved_stock.stock_name == "삼성전자"
        
        # 종목 업데이트
        updated_stock = await repo.update("005930", {"market_cap": 600000000000000})
        assert updated_stock.market_cap == 600000000000000
        
        # 종목 검색
        search_results = await repo.search_by_name("삼성")
        assert len(search_results) == 1
        assert search_results[0].stock_name == "삼성전자"
    
    @pytest.mark.asyncio
    async def test_daily_price_operations(self, async_session):
        """일봉 데이터 작업 테스트"""
        # 먼저 종목 생성
        stock_repo = StockInfoRepository(async_session)
        await stock_repo.create({
            "stock_code": "005930",
            "stock_name": "삼성전자",
            "market_type": "KOSPI"
        })
        
        price_repo = DailyPriceRepository(async_session)
        
        # 일봉 데이터 생성
        price_data_list = []
        base_date = date.today()
        
        for i in range(10):
            price_data_list.append({
                "stock_code": "005930",
                "date": base_date - timedelta(days=i),
                "open_price": 75000 + i * 100,
                "high_price": 76000 + i * 100,
                "low_price": 74000 + i * 100,
                "close_price": 75500 + i * 100,
                "volume": 10000000 + i * 100000,
                "trading_value": (75500 + i * 100) * (10000000 + i * 100000)
            })
        
        # 대량 생성
        created_count = await price_repo.bulk_create(price_data_list)
        assert created_count == 10
        
        # 특정 기간 조회
        start_date = base_date - timedelta(days=5)
        end_date = base_date
        
        price_list = await price_repo.get_by_stock_and_date_range(
            "005930", start_date, end_date
        )
        assert len(price_list) == 6  # 6일간 데이터
        
        # 최근 N일 조회
        recent_prices = await price_repo.get_latest_by_stock("005930", 5)
        assert len(recent_prices) == 5
        
        # 기술적 지표 계산
        success = await price_repo.calculate_technical_indicators("005930", base_date)
        assert success is True
    
    @pytest.mark.asyncio
    async def test_investor_trading_operations(self, async_session):
        """투자자별 매매동향 작업 테스트"""
        # 종목 생성
        stock_repo = StockInfoRepository(async_session)
        await stock_repo.create({
            "stock_code": "005930",
            "stock_name": "삼성전자",
            "market_type": "KOSPI"
        })
        
        trading_repo = InvestorTradingRepository(async_session)
        
        # 매매동향 데이터 생성
        trading_data_list = []
        base_date = date.today()
        
        for i in range(60):
            trading_data_list.append({
                "stock_code": "005930",
                "date": base_date - timedelta(days=i),
                "individual_buy": 500000000,
                "individual_sell": 450000000,
                "individual_net": 50000000,
                "institution_buy": 300000000 + i * 1000000,
                "institution_sell": 280000000,
                "institution_net": 20000000 + i * 1000000,
                "foreign_buy": 200000000,
                "foreign_sell": 180000000 + i * 500000,
                "foreign_net": 20000000 - i * 500000
            })
        
        # 대량 생성
        created_count = await trading_repo.bulk_create(trading_data_list)
        assert created_count == 60
        
        # 순매수 집계 조회
        net_buying_summary = await trading_repo.get_net_buying_summary("005930", 60)
        
        assert "individual_net" in net_buying_summary
        assert "institution_net" in net_buying_summary
        assert "foreign_net" in net_buying_summary
        assert "institution_foreign_net" in net_buying_summary
        
        # 기관+외국인 순매수가 양수인지 확인
        assert net_buying_summary["institution_foreign_net"] > 0
    
    @pytest.mark.asyncio
    async def test_stock_score_operations(self, async_session):
        """종목 점수 작업 테스트"""
        # 종목 생성
        stock_repo = StockInfoRepository(async_session)
        await stock_repo.create({
            "stock_code": "005930",
            "stock_name": "삼성전자",
            "market_type": "KOSPI"
        })
        
        score_repo = StockScoreRepository(async_session)
        
        # 점수 데이터 생성
        score_data = {
            "stock_code": "005930",
            "date": date.today(),
            "core1_institution_foreign": 1.0,
            "core2_obv_uptrend": 0.8,
            "core3_volatility_squeeze": 1.0,
            "core4_relative_strength": 0.6,
            "core5_accumulation_candles": 0.9,
            "dart1_new_holder": 1.0,
            "dart2_holder_increase": 0.8,
            "dart3_purpose_upgrade": 0.6,
            "dart4_reporter_weight": 0.5,
            "dart5_exec_trading": 0.6,
            "dart6_split_buying": 0.4,
            "total_core_score": 4.3,
            "total_dart_score": 3.9,
            "total_score": 8.2,
            "grade": "강함"
        }
        
        # 점수 생성
        created_score = await score_repo.create_or_update(score_data)
        assert created_score.total_score == 8.2
        assert created_score.grade == "강함"
        
        # 최신 점수 조회
        latest_score = await score_repo.get_latest_by_stock("005930")
        assert latest_score is not None
        assert latest_score.total_score == 8.2
        
        # 점수 히스토리 생성 (여러 날짜)
        for i in range(5):
            history_data = score_data.copy()
            history_data["date"] = date.today() - timedelta(days=i+1)
            history_data["total_score"] = 8.0 - i * 0.2
            await score_repo.create_or_update(history_data)
        
        # 점수 히스토리 조회
        score_history = await score_repo.get_score_history("005930", 7)
        assert len(score_history) == 6  # 오늘 포함 6일
        
        # 상위 점수 종목 조회
        top_scores = await score_repo.get_top_scores(date.today(), 8.0, 10)
        assert len(top_scores) == 1
        assert top_scores[0].total_score == 8.2
    
    @pytest.mark.asyncio
    async def test_data_validation(self, async_session):
        """데이터 검증 테스트"""
        stock_repo = StockInfoRepository(async_session)
        
        # 유효한 데이터
        valid_stock_data = {
            "stock_code": "005930",
            "stock_name": "삼성전자",
            "market_type": "KOSPI"
        }
        
        stock = await stock_repo.create(valid_stock_data)
        assert stock.stock_code == "005930"
        
        # 중복 종목코드 테스트 (예외 발생해야 함)
        with pytest.raises(Exception):
            await stock_repo.create(valid_stock_data)
    
    @pytest.mark.asyncio
    async def test_repository_error_handling(self, async_session):
        """리포지토리 오류 처리 테스트"""
        stock_repo = StockInfoRepository(async_session)
        
        # 존재하지 않는 종목 조회
        non_existent_stock = await stock_repo.get_by_code("999999")
        assert non_existent_stock is None
        
        # 빈 검색 결과
        empty_search = await stock_repo.search_by_name("존재하지않는종목")
        assert len(empty_search) == 0

class TestDatabasePerformance:
    """데이터베이스 성능 테스트"""
    
    @pytest.fixture
    async def performance_session(self):
        """성능 테스트용 세션 픽스처"""
        temp_file = tempfile.NamedTemporaryFile(delete=False, suffix=".db")
        temp_file.close()
        
        database_url = f"sqlite+aiosqlite:///{temp_file.name}"
        engine = create_async_engine(database_url, echo=False)
        
        async with engine.begin() as conn:
            await conn.run_sync(Base.metadata.create_all)
        
        SessionLocal = sessionmaker(
            engine, class_=AsyncSession, expire_on_commit=False
        )
        
        session = SessionLocal()
        try:
            yield session
        finally:
            await session.close()
            await engine.dispose()
            os.unlink(temp_file.name)
    
    @pytest.mark.asyncio
    async def test_bulk_operations_performance(self, performance_session):
        """대량 작업 성능 테스트"""
        import time
        
        # 종목 생성
        stock_repo = StockInfoRepository(performance_session)
        await stock_repo.create({
            "stock_code": "005930",
            "stock_name": "삼성전자",
            "market_type": "KOSPI"
        })
        
        price_repo = DailyPriceRepository(performance_session)
        
        # 대량 일봉 데이터 생성 (1000개)
        price_data_list = []
        base_date = date.today()
        
        start_time = time.time()
        
        for i in range(1000):
            price_data_list.append({
                "stock_code": "005930",
                "date": base_date - timedelta(days=i),
                "open_price": 75000,
                "high_price": 76000,
                "low_price": 74000,
                "close_price": 75500,
                "volume": 10000000,
                "trading_value": 755000000000
            })
        
        # 대량 생성 실행
        created_count = await price_repo.bulk_create(price_data_list)
        
        end_time = time.time()
        execution_time = end_time - start_time
        
        assert created_count == 1000
        assert execution_time < 5.0  # 5초 이내 완료되어야 함
        
        print(f"대량 삽입 성능: {created_count}건을 {execution_time:.2f}초에 처리")

if __name__ == "__main__":
    pytest.main([__file__, "-v"])
