# AI 머니 트래커 - 데이터 무결성 검증 시스템 테스트

import pytest
import asyncio
from datetime import datetime, date, timedelta
from unittest.mock import Mock, AsyncMock, patch
from typing import List, Dict, Any, Optional
import json

class TestDataIntegrityValidator:
    """데이터 무결성 검증기 테스트"""
    
    @pytest.fixture
    def sample_ohlcv_data(self):
        """샘플 OHLCV 데이터"""
        return [
            {
                "stock_code": "005930",
                "date": date(2024, 9, 27),
                "open": 76000,
                "high": 77000,
                "low": 75000,
                "close": 76500,
                "volume": 1000000,
                "trading_value": 76500000000
            },
            {
                "stock_code": "005930",
                "date": date(2024, 9, 26),
                "open": 75500,
                "high": 76200,
                "low": 74800,
                "close": 76000,
                "volume": 1200000,
                "trading_value": 91200000000
            }
        ]
    
    @pytest.fixture
    def sample_investor_trading_data(self):
        """샘플 투자자별 매매동향 데이터"""
        return [
            {
                "stock_code": "005930",
                "date": date(2024, 9, 27),
                "investor_type": "individual",
                "buy_volume": 500000,
                "sell_volume": 600000,
                "net_volume": -100000,
                "buy_amount": 38000000000,
                "sell_amount": 45600000000,
                "net_amount": -7600000000
            },
            {
                "stock_code": "005930",
                "date": date(2024, 9, 27),
                "investor_type": "institution",
                "buy_volume": 300000,
                "sell_volume": 200000,
                "net_volume": 100000,
                "buy_amount": 22950000000,
                "sell_amount": 15200000000,
                "net_amount": 7750000000
            }
        ]
    
    @pytest.fixture
    def sample_dart_data(self):
        """샘플 DART 공시 데이터"""
        return [
            {
                "rcept_no": "20240927000001",
                "corp_name": "삼성전자",
                "corp_code": "00126380",
                "stock_code": "005930",
                "report_nm": "대량보유상황보고서",
                "rcept_dt": date(2024, 9, 27),
                "flr_nm": "테스트투자운용",
                "rm": "대량보유상황보고서"
            }
        ]
    
    def test_validator_initialization(self):
        """데이터 무결성 검증기 초기화 테스트"""
        
        def initialize_validator():
            """검증기 초기화"""
            return {
                "validation_rules": {
                    "ohlcv": ["price_consistency", "volume_positive", "date_sequence"],
                    "investor_trading": ["volume_sum_consistency", "amount_calculation", "net_balance"],
                    "dart": ["rcept_no_format", "date_format", "corp_code_format"]
                },
                "tolerance": {
                    "price_variance": 0.1,  # 10% 가격 변동 허용
                    "volume_variance": 0.05,  # 5% 거래량 변동 허용
                    "amount_precision": 1000  # 1000원 단위 허용
                },
                "duplicate_detection": {
                    "ohlcv_key": ["stock_code", "date"],
                    "investor_trading_key": ["stock_code", "date", "investor_type"],
                    "dart_key": ["rcept_no"]
                }
            }
        
        config = initialize_validator()
        
        assert "validation_rules" in config
        assert "tolerance" in config
        assert "duplicate_detection" in config
        assert len(config["validation_rules"]) == 3
        assert "ohlcv" in config["validation_rules"]
        assert "investor_trading" in config["validation_rules"]
        assert "dart" in config["validation_rules"]
    
    def test_ohlcv_data_validation(self, sample_ohlcv_data):
        """OHLCV 데이터 검증 테스트"""
        
        def validate_ohlcv_data(data: List[Dict[str, Any]]) -> Dict[str, Any]:
            """OHLCV 데이터 검증"""
            validation_result = {
                "is_valid": True,
                "errors": [],
                "warnings": [],
                "statistics": {
                    "total_records": len(data),
                    "valid_records": 0,
                    "invalid_records": 0
                }
            }
            
            for i, record in enumerate(data):
                record_errors = []
                
                # 1. 필수 필드 검증
                required_fields = ["stock_code", "date", "open", "high", "low", "close", "volume"]
                for field in required_fields:
                    if field not in record or record[field] is None:
                        record_errors.append(f"레코드 {i}: 필수 필드 '{field}' 누락")
                
                # 2. 가격 일관성 검증 (high >= low, high >= open/close, low <= open/close)
                if all(field in record for field in ["open", "high", "low", "close"]):
                    high, low, open_price, close = record["high"], record["low"], record["open"], record["close"]
                    
                    if high < low:
                        record_errors.append(f"레코드 {i}: 고가({high})가 저가({low})보다 낮음")
                    if high < max(open_price, close):
                        record_errors.append(f"레코드 {i}: 고가({high})가 시가/종가보다 낮음")
                    if low > min(open_price, close):
                        record_errors.append(f"레코드 {i}: 저가({low})가 시가/종가보다 높음")
                
                # 3. 양수 검증 (volume, trading_value)
                for field in ["volume", "trading_value"]:
                    if field in record and record[field] is not None:
                        if record[field] < 0:
                            record_errors.append(f"레코드 {i}: {field}가 음수값({record[field]})")
                
                # 4. 날짜 형식 검증
                if "date" in record:
                    if not isinstance(record["date"], date):
                        record_errors.append(f"레코드 {i}: 날짜 형식이 올바르지 않음")
                
                # 5. 거래대금 계산 검증 (대략적)
                if all(field in record for field in ["close", "volume", "trading_value"]):
                    expected_value = record["close"] * record["volume"]
                    actual_value = record["trading_value"]
                    variance = abs(expected_value - actual_value) / expected_value if expected_value > 0 else 0
                    
                    if variance > 0.1:  # 10% 이상 차이
                        validation_result["warnings"].append(
                            f"레코드 {i}: 거래대금 계산 불일치 (예상: {expected_value}, 실제: {actual_value})"
                        )
                
                if record_errors:
                    validation_result["errors"].extend(record_errors)
                    validation_result["statistics"]["invalid_records"] += 1
                    validation_result["is_valid"] = False
                else:
                    validation_result["statistics"]["valid_records"] += 1
            
            return validation_result
        
        # 유효한 데이터 테스트
        result = validate_ohlcv_data(sample_ohlcv_data)
        assert result["is_valid"] == True
        assert result["statistics"]["valid_records"] == 2
        assert result["statistics"]["invalid_records"] == 0
        
        # 무효한 데이터 테스트
        invalid_data = [{
            "stock_code": "005930",
            "date": date(2024, 9, 27),
            "open": 76000,
            "high": 75000,  # 고가가 시가보다 낮음
            "low": 77000,   # 저가가 고가보다 높음
            "close": 76500,
            "volume": -1000,  # 음수 거래량
            "trading_value": 76500000000
        }]
        
        invalid_result = validate_ohlcv_data(invalid_data)
        assert invalid_result["is_valid"] == False
        assert len(invalid_result["errors"]) > 0
        assert invalid_result["statistics"]["invalid_records"] == 1
    
    def test_investor_trading_validation(self, sample_investor_trading_data):
        """투자자별 매매동향 데이터 검증 테스트"""
        
        def validate_investor_trading_data(data: List[Dict[str, Any]]) -> Dict[str, Any]:
            """투자자별 매매동향 데이터 검증"""
            validation_result = {
                "is_valid": True,
                "errors": [],
                "warnings": [],
                "statistics": {
                    "total_records": len(data),
                    "valid_records": 0,
                    "invalid_records": 0
                }
            }
            
            for i, record in enumerate(data):
                record_errors = []
                
                # 1. 필수 필드 검증
                required_fields = ["stock_code", "date", "investor_type", "buy_volume", "sell_volume", "net_volume"]
                for field in required_fields:
                    if field not in record or record[field] is None:
                        record_errors.append(f"레코드 {i}: 필수 필드 '{field}' 누락")
                
                # 2. 순매수량 계산 검증
                if all(field in record for field in ["buy_volume", "sell_volume", "net_volume"]):
                    expected_net = record["buy_volume"] - record["sell_volume"]
                    actual_net = record["net_volume"]
                    
                    if expected_net != actual_net:
                        record_errors.append(
                            f"레코드 {i}: 순매수량 계산 오류 (예상: {expected_net}, 실제: {actual_net})"
                        )
                
                # 3. 순매수금액 계산 검증
                if all(field in record for field in ["buy_amount", "sell_amount", "net_amount"]):
                    expected_net_amount = record["buy_amount"] - record["sell_amount"]
                    actual_net_amount = record["net_amount"]
                    
                    if abs(expected_net_amount - actual_net_amount) > 1000:  # 1000원 허용 오차
                        record_errors.append(
                            f"레코드 {i}: 순매수금액 계산 오류 (예상: {expected_net_amount}, 실제: {actual_net_amount})"
                        )
                
                # 4. 투자자 유형 검증
                if "investor_type" in record:
                    valid_types = ["individual", "institution", "foreign", "etc"]
                    if record["investor_type"] not in valid_types:
                        record_errors.append(f"레코드 {i}: 유효하지 않은 투자자 유형 '{record['investor_type']}'")
                
                # 5. 음수 거래량/금액 검증 (순매수는 음수 가능)
                for field in ["buy_volume", "sell_volume", "buy_amount", "sell_amount"]:
                    if field in record and record[field] is not None:
                        if record[field] < 0:
                            record_errors.append(f"레코드 {i}: {field}가 음수값({record[field]})")
                
                if record_errors:
                    validation_result["errors"].extend(record_errors)
                    validation_result["statistics"]["invalid_records"] += 1
                    validation_result["is_valid"] = False
                else:
                    validation_result["statistics"]["valid_records"] += 1
            
            return validation_result
        
        # 유효한 데이터 테스트
        result = validate_investor_trading_data(sample_investor_trading_data)
        assert result["is_valid"] == True
        assert result["statistics"]["valid_records"] == 2
        assert result["statistics"]["invalid_records"] == 0
        
        # 무효한 데이터 테스트
        invalid_data = [{
            "stock_code": "005930",
            "date": date(2024, 9, 27),
            "investor_type": "invalid_type",
            "buy_volume": 500000,
            "sell_volume": 600000,
            "net_volume": 200000,  # 계산 오류 (실제로는 -100000이어야 함)
            "buy_amount": -1000,   # 음수 매수금액
            "sell_amount": 45600000000,
            "net_amount": -7600000000
        }]
        
        invalid_result = validate_investor_trading_data(invalid_data)
        assert invalid_result["is_valid"] == False
        assert len(invalid_result["errors"]) > 0
    
    def test_dart_data_validation(self, sample_dart_data):
        """DART 공시 데이터 검증 테스트"""
        
        def validate_dart_data(data: List[Dict[str, Any]]) -> Dict[str, Any]:
            """DART 공시 데이터 검증"""
            validation_result = {
                "is_valid": True,
                "errors": [],
                "warnings": [],
                "statistics": {
                    "total_records": len(data),
                    "valid_records": 0,
                    "invalid_records": 0
                }
            }
            
            for i, record in enumerate(data):
                record_errors = []
                
                # 1. 필수 필드 검증
                required_fields = ["rcept_no", "corp_name", "corp_code", "stock_code", "report_nm", "rcept_dt"]
                for field in required_fields:
                    if field not in record or record[field] is None:
                        record_errors.append(f"레코드 {i}: 필수 필드 '{field}' 누락")
                
                # 2. 접수번호 형식 검증 (14자리 숫자)
                if "rcept_no" in record:
                    rcept_no = str(record["rcept_no"])
                    if not (rcept_no.isdigit() and len(rcept_no) >= 14):
                        record_errors.append(f"레코드 {i}: 접수번호 형식 오류 '{rcept_no}'")
                
                # 3. 법인코드 형식 검증 (8자리)
                if "corp_code" in record:
                    corp_code = str(record["corp_code"])
                    if not (corp_code.isdigit() and len(corp_code) == 8):
                        record_errors.append(f"레코드 {i}: 법인코드 형식 오류 '{corp_code}'")
                
                # 4. 종목코드 형식 검증 (6자리)
                if "stock_code" in record:
                    stock_code = str(record["stock_code"])
                    if not (stock_code.isdigit() and len(stock_code) == 6):
                        record_errors.append(f"레코드 {i}: 종목코드 형식 오류 '{stock_code}'")
                
                # 5. 날짜 형식 검증
                if "rcept_dt" in record:
                    if not isinstance(record["rcept_dt"], date):
                        record_errors.append(f"레코드 {i}: 접수일자 형식이 올바르지 않음")
                
                # 6. 보고서명 검증
                if "report_nm" in record:
                    valid_reports = ["대량보유상황보고서", "주요사항보고서", "임원·주요주주특정증권등소유상황보고서"]
                    report_nm = record["report_nm"]
                    
                    is_valid_report = any(valid_report in report_nm for valid_report in valid_reports)
                    if not is_valid_report:
                        validation_result["warnings"].append(
                            f"레코드 {i}: 알 수 없는 보고서 유형 '{report_nm}'"
                        )
                
                if record_errors:
                    validation_result["errors"].extend(record_errors)
                    validation_result["statistics"]["invalid_records"] += 1
                    validation_result["is_valid"] = False
                else:
                    validation_result["statistics"]["valid_records"] += 1
            
            return validation_result
        
        # 유효한 데이터 테스트
        result = validate_dart_data(sample_dart_data)
        assert result["is_valid"] == True
        assert result["statistics"]["valid_records"] == 1
        assert result["statistics"]["invalid_records"] == 0
        
        # 무효한 데이터 테스트
        invalid_data = [{
            "rcept_no": "123",  # 너무 짧음
            "corp_name": "삼성전자",
            "corp_code": "123456789",  # 9자리 (8자리여야 함)
            "stock_code": "05930",  # 5자리 (6자리여야 함)
            "report_nm": "대량보유상황보고서",
            "rcept_dt": "2024-09-27",  # 문자열 (date 객체여야 함)
            "flr_nm": "테스트투자운용"
        }]
        
        invalid_result = validate_dart_data(invalid_data)
        assert invalid_result["is_valid"] == False
        assert len(invalid_result["errors"]) > 0
    
    def test_duplicate_detection(self, sample_ohlcv_data, sample_investor_trading_data):
        """중복 데이터 감지 테스트"""
        
        def detect_duplicates(data: List[Dict[str, Any]], key_fields: List[str]) -> Dict[str, Any]:
            """중복 데이터 감지"""
            seen_keys = set()
            duplicates = []
            unique_data = []
            
            for i, record in enumerate(data):
                # 키 필드로 고유 키 생성
                key_values = tuple(record.get(field) for field in key_fields)
                
                if key_values in seen_keys:
                    duplicates.append({
                        "index": i,
                        "key": dict(zip(key_fields, key_values)),
                        "record": record
                    })
                else:
                    seen_keys.add(key_values)
                    unique_data.append(record)
            
            return {
                "has_duplicates": len(duplicates) > 0,
                "duplicate_count": len(duplicates),
                "duplicates": duplicates,
                "unique_data": unique_data,
                "unique_count": len(unique_data)
            }
        
        # OHLCV 중복 테스트 (중복 없음)
        ohlcv_result = detect_duplicates(sample_ohlcv_data, ["stock_code", "date"])
        assert ohlcv_result["has_duplicates"] == False
        assert ohlcv_result["duplicate_count"] == 0
        assert ohlcv_result["unique_count"] == 2
        
        # OHLCV 중복 데이터로 테스트
        duplicate_ohlcv = sample_ohlcv_data + [sample_ohlcv_data[0]]  # 첫 번째 레코드 중복
        ohlcv_dup_result = detect_duplicates(duplicate_ohlcv, ["stock_code", "date"])
        assert ohlcv_dup_result["has_duplicates"] == True
        assert ohlcv_dup_result["duplicate_count"] == 1
        assert ohlcv_dup_result["unique_count"] == 2
        
        # 투자자별 매매동향 중복 테스트
        investor_result = detect_duplicates(sample_investor_trading_data, ["stock_code", "date", "investor_type"])
        assert investor_result["has_duplicates"] == False
        assert investor_result["duplicate_count"] == 0
        assert investor_result["unique_count"] == 2
    
    def test_data_completeness_check(self):
        """데이터 완전성 검사 테스트"""
        
        def check_data_completeness(
            stock_codes: List[str], 
            date_range: int,
            ohlcv_data: List[Dict[str, Any]],
            investor_data: List[Dict[str, Any]]
        ) -> Dict[str, Any]:
            """데이터 완전성 검사"""
            
            from datetime import date, timedelta
            
            # 기대되는 날짜 범위 계산
            end_date = date.today()
            start_date = end_date - timedelta(days=date_range)
            expected_dates = []
            current_date = start_date
            while current_date <= end_date:
                # 주말 제외 (간단한 버전)
                if current_date.weekday() < 5:  # 월-금
                    expected_dates.append(current_date)
                current_date += timedelta(days=1)
            
            completeness_result = {
                "is_complete": True,
                "missing_data": [],
                "coverage_rate": 0.0,
                "statistics": {
                    "expected_records": len(stock_codes) * len(expected_dates),
                    "actual_ohlcv_records": len(ohlcv_data),
                    "actual_investor_records": len(investor_data)
                }
            }
            
            # OHLCV 데이터 완전성 검사
            ohlcv_keys = set((record["stock_code"], record["date"]) for record in ohlcv_data)
            
            for stock_code in stock_codes:
                for expected_date in expected_dates:
                    if (stock_code, expected_date) not in ohlcv_keys:
                        completeness_result["missing_data"].append({
                            "data_type": "ohlcv",
                            "stock_code": stock_code,
                            "date": expected_date
                        })
                        completeness_result["is_complete"] = False
            
            # 커버리지 비율 계산
            if completeness_result["statistics"]["expected_records"] > 0:
                coverage = 1 - (len(completeness_result["missing_data"]) / 
                              completeness_result["statistics"]["expected_records"])
                completeness_result["coverage_rate"] = max(0.0, coverage)
            
            return completeness_result
        
        # 완전한 데이터 테스트
        complete_ohlcv = [
            {"stock_code": "005930", "date": date.today()},
            {"stock_code": "000660", "date": date.today()}
        ]
        
        result = check_data_completeness(
            stock_codes=["005930", "000660"],
            date_range=1,  # 1일
            ohlcv_data=complete_ohlcv,
            investor_data=[]
        )
        
        assert result["coverage_rate"] >= 0.0
        
        # 불완전한 데이터 테스트
        incomplete_result = check_data_completeness(
            stock_codes=["005930", "000660"],
            date_range=1,
            ohlcv_data=[{"stock_code": "005930", "date": date.today()}],  # 000660 누락
            investor_data=[]
        )
        
        assert incomplete_result["is_complete"] == False
        assert len(incomplete_result["missing_data"]) > 0
        assert incomplete_result["coverage_rate"] < 1.0

class TestDataIntegrityService:
    """데이터 무결성 서비스 테스트"""
    
    @pytest.mark.asyncio
    async def test_integrity_service_initialization(self):
        """무결성 서비스 초기화 테스트"""
        
        def initialize_integrity_service():
            """무결성 서비스 초기화"""
            return {
                "validator": "DataIntegrityValidator instance",
                "scheduler": "IntegrityCheckScheduler instance",
                "config": {
                    "check_frequency": "daily",
                    "alert_threshold": 0.95,  # 95% 이하시 알림
                    "auto_fix": False,
                    "report_format": "json"
                }
            }
        
        service = initialize_integrity_service()
        
        assert "validator" in service
        assert "scheduler" in service
        assert "config" in service
        assert service["config"]["check_frequency"] == "daily"
        assert service["config"]["alert_threshold"] == 0.95
    
    @pytest.mark.asyncio
    async def test_automated_integrity_check(self):
        """자동 무결성 검사 테스트"""
        
        async def run_automated_integrity_check() -> Dict[str, Any]:
            """자동 무결성 검사 실행"""
            
            # 모의 데이터베이스에서 데이터 조회
            mock_data = {
                "ohlcv": [
                    {"stock_code": "005930", "date": date.today(), "close": 76000},
                    {"stock_code": "000660", "date": date.today(), "close": 88000}
                ],
                "investor_trading": [
                    {"stock_code": "005930", "date": date.today(), "investor_type": "individual", "net_volume": -1000},
                    {"stock_code": "005930", "date": date.today(), "investor_type": "institution", "net_volume": 1000}
                ],
                "dart": [
                    {"rcept_no": "20240927000001", "stock_code": "005930", "rcept_dt": date.today()}
                ]
            }
            
            # 무결성 검사 실행
            check_result = {
                "timestamp": datetime.now().isoformat(),
                "overall_status": "healthy",
                "data_types": {
                    "ohlcv": {
                        "status": "healthy",
                        "record_count": len(mock_data["ohlcv"]),
                        "validity_rate": 1.0,
                        "completeness_rate": 0.98
                    },
                    "investor_trading": {
                        "status": "healthy", 
                        "record_count": len(mock_data["investor_trading"]),
                        "validity_rate": 1.0,
                        "completeness_rate": 0.95
                    },
                    "dart": {
                        "status": "healthy",
                        "record_count": len(mock_data["dart"]),
                        "validity_rate": 1.0,
                        "completeness_rate": 0.90
                    }
                },
                "alerts": [],
                "recommendations": []
            }
            
            # 알림 조건 검사
            alert_threshold = 0.95
            for data_type, metrics in check_result["data_types"].items():
                if metrics["completeness_rate"] < alert_threshold:
                    check_result["alerts"].append({
                        "type": "low_completeness",
                        "data_type": data_type,
                        "current_rate": metrics["completeness_rate"],
                        "threshold": alert_threshold,
                        "severity": "warning"
                    })
            
            if check_result["alerts"]:
                check_result["overall_status"] = "warning"
            
            return check_result
        
        result = await run_automated_integrity_check()
        
        assert "timestamp" in result
        assert "overall_status" in result
        assert "data_types" in result
        assert len(result["data_types"]) == 3
        assert "ohlcv" in result["data_types"]
        assert "investor_trading" in result["data_types"]
        assert "dart" in result["data_types"]
        
        # 각 데이터 타입별 메트릭 확인
        for data_type, metrics in result["data_types"].items():
            assert "status" in metrics
            assert "record_count" in metrics
            assert "validity_rate" in metrics
            assert "completeness_rate" in metrics
            assert 0.0 <= metrics["validity_rate"] <= 1.0
            assert 0.0 <= metrics["completeness_rate"] <= 1.0

if __name__ == "__main__":
    pytest.main([__file__, "-v"])
