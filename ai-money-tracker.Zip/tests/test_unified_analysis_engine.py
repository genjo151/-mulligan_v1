# AI 머니 트래커 - 통합 분석 엔진 테스트

import pytest
import asyncio
from datetime import datetime, date, timedelta
from unittest.mock import Mock, AsyncMock, patch
from typing import List, Dict, Any, Optional
import json

class TestUnifiedAnalysisEngine:
    """통합 분석 엔진 테스트"""
    
    @pytest.fixture
    def sample_core_scores(self):
        """샘플 코어 5요소 점수"""
        return {
            "core1_institution_foreign_60d": 1.5,  # 기관·외국인 60일 누적 순매수
            "core2_obv_uptrend_60d": 1.0,          # OBV 정량 우상향
            "core3_volatility_squeeze": 0.5,        # 변동성 수축 BBW
            "core4_relative_strength": 1.0,         # 상대강도 RS 개선
            "core5_accumulation_candles": 0.8       # 매집봉 패턴 감지
        }
    
    @pytest.fixture
    def sample_dart_scores(self):
        """샘플 DART 6요소 점수"""
        return {
            "dart1_major_shareholding": 1.5,        # 대량보유
            "dart2_executive_shareholding": 1.0,    # 임원 지분 변동
            "dart3_material_events": 0.8,           # 주요사항
            "dart4_disclosure_frequency": 0.6,      # 공시 빈도
            "dart5_ownership_change_rate": 1.2,     # 지분 변동률
            "dart6_disclosure_timing": 0.8          # 공시 시점
        }
    
    @pytest.fixture
    def sample_stock_data(self):
        """샘플 종목 데이터"""
        return {
            "stock_code": "005930",
            "stock_name": "삼성전자",
            "market_type": "KOSPI",
            "sector": "전기전자",
            "current_price": 76500,
            "market_cap": 456000000000000,  # 456조원
            "trading_volume": 1000000,
            "analysis_date": date.today()
        }
    
    def test_analysis_engine_initialization(self):
        """통합 분석 엔진 초기화 테스트"""
        
        def initialize_analysis_engine():
            """분석 엔진 초기화"""
            return {
                "core_analyzer": "CoreAnalyzer instance",
                "dart_analyzer": "DartAnalyzer instance", 
                "unified_scorer": "UnifiedScorer instance",
                "pattern_validator": "PatternValidator instance",
                "event_filter": "EventFilter instance",
                "recommendation_engine": "RecommendationEngine instance",
                "config": {
                    "max_total_score": 8.9,
                    "core_weight": 0.6,      # 60%
                    "dart_weight": 0.4,      # 40%
                    "pattern_threshold": 2,   # 최소 2회 출현
                    "minimum_core_count": 3   # 최소 3개 코어 요소 충족
                }
            }
        
        engine = initialize_analysis_engine()
        
        assert "core_analyzer" in engine
        assert "dart_analyzer" in engine
        assert "unified_scorer" in engine
        assert "pattern_validator" in engine
        assert "event_filter" in engine
        assert "recommendation_engine" in engine
        assert engine["config"]["max_total_score"] == 8.9
        assert engine["config"]["core_weight"] + engine["config"]["dart_weight"] == 1.0
    
    def test_unified_score_calculation(self, sample_core_scores, sample_dart_scores):
        """통합 점수 계산 테스트"""
        
        def calculate_unified_score(
            core_scores: Dict[str, float],
            dart_scores: Dict[str, float],
            config: Dict[str, Any]
        ) -> Dict[str, Any]:
            """통합 점수 계산"""
            
            # 1. 코어 5요소 총점 계산 (5점 만점)
            core_total = sum(core_scores.values())
            core_max = 5.0
            core_normalized = min(core_total / core_max, 1.0) * 5.0
            
            # 2. DART 6요소 총점 계산 (3.9점 만점)
            dart_total = sum(dart_scores.values())
            dart_max = 3.9
            dart_normalized = min(dart_total / dart_max, 1.0) * 3.9
            
            # 3. 가중 평균으로 최종 점수 계산
            core_weight = config.get("core_weight", 0.6)
            dart_weight = config.get("dart_weight", 0.4)
            max_total_score = config.get("max_total_score", 8.9)
            
            weighted_score = (core_normalized * core_weight + dart_normalized * dart_weight) * max_total_score / 5.0
            
            # 4. 코어 요소 충족 개수 확인
            core_elements_met = sum(1 for score in core_scores.values() if score > 0)
            dart_elements_met = sum(1 for score in dart_scores.values() if score > 0)
            
            # 5. 최소 조건 검증
            minimum_core_count = config.get("minimum_core_count", 3)
            meets_minimum_requirements = core_elements_met >= minimum_core_count
            
            return {
                "total_score": round(weighted_score, 2),
                "core_score": round(core_normalized, 2),
                "dart_score": round(dart_normalized, 2),
                "core_elements_met": core_elements_met,
                "dart_elements_met": dart_elements_met,
                "meets_minimum_requirements": meets_minimum_requirements,
                "grade": _calculate_grade(weighted_score, max_total_score),
                "breakdown": {
                    "core_scores": core_scores,
                    "dart_scores": dart_scores,
                    "weights": {"core": core_weight, "dart": dart_weight}
                }
            }
        
        def _calculate_grade(score: float, max_score: float) -> str:
            """등급 계산"""
            percentage = (score / max_score) * 100
            if percentage >= 90:
                return "A+"
            elif percentage >= 85:
                return "A"
            elif percentage >= 80:
                return "B+"
            elif percentage >= 75:
                return "B"
            elif percentage >= 70:
                return "C+"
            elif percentage >= 65:
                return "C"
            elif percentage >= 60:
                return "D"
            else:
                return "F"
        
        config = {
            "max_total_score": 8.9,
            "core_weight": 0.6,
            "dart_weight": 0.4,
            "minimum_core_count": 3
        }
        
        result = calculate_unified_score(sample_core_scores, sample_dart_scores, config)
        
        assert "total_score" in result
        assert "core_score" in result
        assert "dart_score" in result
        assert result["total_score"] <= 8.9
        assert result["core_score"] <= 5.0
        assert result["dart_score"] <= 3.9
        assert result["core_elements_met"] == 5  # 모든 코어 요소가 0보다 큼
        assert result["dart_elements_met"] == 6  # 모든 DART 요소가 0보다 큼
        assert result["meets_minimum_requirements"] == True
        assert result["grade"] in ["A+", "A", "B+", "B", "C+", "C", "D", "F"]
    
    def test_pattern_validation_logic(self):
        """60일 내 2-3회 출현 패턴 검증 테스트"""
        
        def validate_pattern_occurrence(
            stock_code: str,
            analysis_history: List[Dict[str, Any]],
            pattern_threshold: int = 2
        ) -> Dict[str, Any]:
            """패턴 출현 빈도 검증"""
            
            # 60일 내 분석 이력 필터링
            cutoff_date = date.today() - timedelta(days=60)
            recent_analyses = [
                analysis for analysis in analysis_history
                if analysis.get("analysis_date", date.min) >= cutoff_date
            ]
            
            # 조건 충족 분석 횟수 계산
            qualified_analyses = []
            for analysis in recent_analyses:
                core_elements_met = analysis.get("core_elements_met", 0)
                total_score = analysis.get("total_score", 0)
                meets_requirements = analysis.get("meets_minimum_requirements", False)
                
                # 조건: 최소 3개 코어 요소 + 총점 3점 이상
                if meets_requirements and core_elements_met >= 3 and total_score >= 3.0:
                    qualified_analyses.append(analysis)
            
            # 패턴 검증 결과
            occurrence_count = len(qualified_analyses)
            pattern_validated = occurrence_count >= pattern_threshold
            
            # 최근 트렌드 분석
            if len(qualified_analyses) >= 2:
                recent_scores = [a["total_score"] for a in qualified_analyses[-3:]]
                trend = "improving" if recent_scores[-1] > recent_scores[0] else "declining"
            else:
                trend = "insufficient_data"
            
            return {
                "stock_code": stock_code,
                "pattern_validated": pattern_validated,
                "occurrence_count": occurrence_count,
                "required_count": pattern_threshold,
                "recent_analyses_count": len(recent_analyses),
                "qualified_analyses": qualified_analyses,
                "trend": trend,
                "validation_date": date.today(),
                "next_validation_date": date.today() + timedelta(days=1)
            }
        
        # 테스트 데이터: 60일 내 4회 분석, 그 중 3회 조건 충족
        analysis_history = [
            {
                "analysis_date": date.today() - timedelta(days=10),
                "total_score": 6.5,
                "core_elements_met": 4,
                "meets_minimum_requirements": True
            },
            {
                "analysis_date": date.today() - timedelta(days=25),
                "total_score": 5.8,
                "core_elements_met": 3,
                "meets_minimum_requirements": True
            },
            {
                "analysis_date": date.today() - timedelta(days=40),
                "total_score": 2.5,  # 점수 부족
                "core_elements_met": 2,  # 요소 부족
                "meets_minimum_requirements": False
            },
            {
                "analysis_date": date.today() - timedelta(days=55),
                "total_score": 7.2,
                "core_elements_met": 5,
                "meets_minimum_requirements": True
            },
            {
                "analysis_date": date.today() - timedelta(days=70),  # 60일 초과
                "total_score": 8.0,
                "core_elements_met": 5,
                "meets_minimum_requirements": True
            }
        ]
        
        result = validate_pattern_occurrence("005930", analysis_history, pattern_threshold=2)
        
        assert result["pattern_validated"] == True  # 3회 >= 2회
        assert result["occurrence_count"] == 3
        assert result["recent_analyses_count"] == 4  # 60일 내 4개
        assert len(result["qualified_analyses"]) == 3
        assert result["trend"] in ["improving", "declining", "insufficient_data"]
        
        # 조건 미충족 테스트
        insufficient_history = analysis_history[:2]  # 2개만 사용
        insufficient_result = validate_pattern_occurrence("000660", insufficient_history, pattern_threshold=3)
        
        assert insufficient_result["pattern_validated"] == False
        assert insufficient_result["occurrence_count"] < 3
    
    def test_event_exclusion_logic(self):
        """이벤트 제외 로직 테스트"""
        
        def should_exclude_analysis(
            analysis_date: date,
            stock_code: str,
            events: List[Dict[str, Any]]
        ) -> Dict[str, Any]:
            """분석 제외 여부 결정"""
            
            exclusion_reasons = []
            
            for event in events:
                event_date = event.get("event_date")
                event_type = event.get("event_type")
                event_stock = event.get("stock_code")
                
                # 해당 종목의 이벤트만 확인
                if event_stock != stock_code:
                    continue
                
                # 이벤트 전후 2일 범위 계산
                exclusion_start = event_date - timedelta(days=2)
                exclusion_end = event_date + timedelta(days=2)
                
                # 분석일이 제외 기간에 포함되는지 확인
                if exclusion_start <= analysis_date <= exclusion_end:
                    exclusion_reasons.append({
                        "event_type": event_type,
                        "event_date": event_date,
                        "days_from_event": (analysis_date - event_date).days,
                        "description": event.get("description", "")
                    })
            
            should_exclude = len(exclusion_reasons) > 0
            
            return {
                "should_exclude": should_exclude,
                "exclusion_reasons": exclusion_reasons,
                "analysis_date": analysis_date,
                "stock_code": stock_code
            }
        
        # 테스트 이벤트 데이터
        events = [
            {
                "stock_code": "005930",
                "event_type": "earnings_announcement",
                "event_date": date(2024, 9, 25),
                "description": "3분기 실적발표"
            },
            {
                "stock_code": "005930", 
                "event_type": "rebalancing",
                "event_date": date(2024, 9, 15),
                "description": "ETF 리밸런싱"
            },
            {
                "stock_code": "005930",
                "event_type": "news_surge",
                "event_date": date(2024, 9, 20),
                "description": "반도체 호재 뉴스"
            },
            {
                "stock_code": "000660",  # 다른 종목
                "event_type": "earnings_announcement", 
                "event_date": date(2024, 9, 26),
                "description": "SK하이닉스 실적발표"
            }
        ]
        
        # 실적발표 2일 후 분석 (제외되어야 함)
        result1 = should_exclude_analysis(date(2024, 9, 27), "005930", events)
        assert result1["should_exclude"] == True
        assert len(result1["exclusion_reasons"]) == 1
        assert result1["exclusion_reasons"][0]["event_type"] == "earnings_announcement"
        
        # 이벤트와 무관한 날짜 분석 (제외되지 않음)
        result2 = should_exclude_analysis(date(2024, 9, 10), "005930", events)
        assert result2["should_exclude"] == False
        assert len(result2["exclusion_reasons"]) == 0
        
        # 다른 종목의 이벤트는 영향 없음 (하지만 뉴스 급등일과 겹침)
        result3 = should_exclude_analysis(date(2024, 9, 28), "005930", events)  # 모든 이벤트와 무관한 날짜
        assert result3["should_exclude"] == False  # 어떤 이벤트와도 무관
    
    @pytest.mark.asyncio
    async def test_unified_analysis_workflow(self, sample_stock_data, sample_core_scores, sample_dart_scores):
        """통합 분석 워크플로우 테스트"""
        
        async def run_unified_analysis(
            stock_code: str,
            analysis_date: date = None
        ) -> Dict[str, Any]:
            """통합 분석 실행"""
            
            if analysis_date is None:
                analysis_date = date.today()
            
            analysis_result = {
                "stock_code": stock_code,
                "analysis_date": analysis_date,
                "timestamp": datetime.now(),
                "status": "completed"
            }
            
            try:
                # 1. 이벤트 제외 검사
                mock_events = []  # 실제로는 데이터베이스에서 조회
                exclusion_check = {
                    "should_exclude": False,
                    "exclusion_reasons": []
                }
                
                if exclusion_check["should_exclude"]:
                    analysis_result.update({
                        "status": "excluded",
                        "exclusion_reasons": exclusion_check["exclusion_reasons"]
                    })
                    return analysis_result
                
                # 2. 코어 5요소 분석
                core_analysis = {
                    "scores": sample_core_scores,
                    "total": sum(sample_core_scores.values()),
                    "elements_met": sum(1 for score in sample_core_scores.values() if score > 0)
                }
                
                # 3. DART 6요소 분석
                dart_analysis = {
                    "scores": sample_dart_scores,
                    "total": sum(sample_dart_scores.values()),
                    "elements_met": sum(1 for score in sample_dart_scores.values() if score > 0)
                }
                
                # 4. 통합 점수 계산
                config = {
                    "max_total_score": 8.9,
                    "core_weight": 0.6,
                    "dart_weight": 0.4,
                    "minimum_core_count": 3
                }
                
                # 통합 점수 계산 로직 (간단화)
                core_normalized = min(core_analysis["total"] / 5.0, 1.0) * 5.0
                dart_normalized = min(dart_analysis["total"] / 3.9, 1.0) * 3.9
                
                weighted_score = (
                    core_normalized * config["core_weight"] + 
                    dart_normalized * config["dart_weight"]
                ) * config["max_total_score"] / 5.0
                
                unified_score = {
                    "total_score": round(weighted_score, 2),
                    "core_score": round(core_normalized, 2),
                    "dart_score": round(dart_normalized, 2),
                    "core_elements_met": core_analysis["elements_met"],
                    "dart_elements_met": dart_analysis["elements_met"],
                    "meets_minimum_requirements": core_analysis["elements_met"] >= config["minimum_core_count"]
                }
                
                # 5. 패턴 검증 (간단화)
                pattern_validation = {
                    "pattern_validated": True,  # 실제로는 이력 조회
                    "occurrence_count": 3,
                    "trend": "improving"
                }
                
                # 6. 추천 등급 결정
                if unified_score["meets_minimum_requirements"] and pattern_validation["pattern_validated"]:
                    if unified_score["total_score"] >= 7.0:
                        recommendation = "강력추천"
                    elif unified_score["total_score"] >= 5.0:
                        recommendation = "추천"
                    elif unified_score["total_score"] >= 3.0:
                        recommendation = "관심"
                    else:
                        recommendation = "보류"
                else:
                    recommendation = "부적격"
                
                # 7. 최종 결과 구성
                analysis_result.update({
                    "core_analysis": core_analysis,
                    "dart_analysis": dart_analysis,
                    "unified_score": unified_score,
                    "pattern_validation": pattern_validation,
                    "recommendation": recommendation,
                    "analysis_summary": {
                        "total_elements": unified_score["core_elements_met"] + unified_score["dart_elements_met"],
                        "confidence_level": "high" if pattern_validation["pattern_validated"] else "medium",
                        "risk_level": "low" if unified_score["total_score"] >= 6.0 else "medium"
                    }
                })
                
                return analysis_result
                
            except Exception as e:
                analysis_result.update({
                    "status": "error",
                    "error": str(e)
                })
                return analysis_result
        
        # 통합 분석 실행
        result = await run_unified_analysis("005930")
        
        assert result["status"] == "completed"
        assert "core_analysis" in result
        assert "dart_analysis" in result
        assert "unified_score" in result
        assert "pattern_validation" in result
        assert "recommendation" in result
        
        # 점수 검증
        assert result["unified_score"]["total_score"] <= 8.9
        assert result["unified_score"]["core_score"] <= 5.0
        assert result["unified_score"]["dart_score"] <= 3.9
        
        # 추천 등급 검증
        assert result["recommendation"] in ["강력추천", "추천", "관심", "보류", "부적격"]
        
        # 분석 요약 검증
        assert "analysis_summary" in result
        assert result["analysis_summary"]["confidence_level"] in ["high", "medium", "low"]
        assert result["analysis_summary"]["risk_level"] in ["low", "medium", "high"]

class TestRecommendationEngine:
    """추천 엔진 테스트"""
    
    def test_stock_ranking_system(self):
        """종목 랭킹 시스템 테스트"""
        
        def rank_stocks(analysis_results: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
            """종목 랭킹 생성"""
            
            # 유효한 분석 결과만 필터링
            valid_results = [
                result for result in analysis_results
                if result.get("status") == "completed" and
                result.get("unified_score", {}).get("meets_minimum_requirements", False) and
                result.get("pattern_validation", {}).get("pattern_validated", False)
            ]
            
            # 점수 기준으로 정렬
            ranked_stocks = sorted(
                valid_results,
                key=lambda x: (
                    x.get("unified_score", {}).get("total_score", 0),
                    x.get("unified_score", {}).get("core_elements_met", 0),
                    x.get("pattern_validation", {}).get("occurrence_count", 0)
                ),
                reverse=True
            )
            
            # 랭킹 정보 추가
            for i, stock in enumerate(ranked_stocks):
                stock["rank"] = i + 1
                stock["percentile"] = round((len(ranked_stocks) - i) / len(ranked_stocks) * 100, 1)
            
            return ranked_stocks
        
        # 테스트 데이터
        analysis_results = [
            {
                "stock_code": "005930",
                "status": "completed",
                "unified_score": {"total_score": 7.5, "core_elements_met": 5, "meets_minimum_requirements": True},
                "pattern_validation": {"pattern_validated": True, "occurrence_count": 4}
            },
            {
                "stock_code": "000660",
                "status": "completed", 
                "unified_score": {"total_score": 6.2, "core_elements_met": 4, "meets_minimum_requirements": True},
                "pattern_validation": {"pattern_validated": True, "occurrence_count": 3}
            },
            {
                "stock_code": "035420",
                "status": "completed",
                "unified_score": {"total_score": 8.1, "core_elements_met": 5, "meets_minimum_requirements": True},
                "pattern_validation": {"pattern_validated": True, "occurrence_count": 3}
            },
            {
                "stock_code": "051910",
                "status": "excluded",  # 제외된 종목
                "unified_score": {"total_score": 8.5, "core_elements_met": 5, "meets_minimum_requirements": True},
                "pattern_validation": {"pattern_validated": True, "occurrence_count": 4}
            }
        ]
        
        ranked_stocks = rank_stocks(analysis_results)
        
        assert len(ranked_stocks) == 3  # 제외된 종목 1개 빼고
        assert ranked_stocks[0]["stock_code"] == "035420"  # 가장 높은 점수
        assert ranked_stocks[0]["rank"] == 1
        assert ranked_stocks[0]["percentile"] == 100.0
        assert ranked_stocks[1]["stock_code"] == "005930"  # 두 번째
        assert ranked_stocks[2]["stock_code"] == "000660"  # 세 번째
        assert ranked_stocks[2]["rank"] == 3
    
    def test_portfolio_recommendation(self):
        """포트폴리오 추천 테스트"""
        
        def recommend_portfolio(
            ranked_stocks: List[Dict[str, Any]],
            max_stocks: int = 10,
            min_score: float = 5.0,
            sector_diversification: bool = True
        ) -> Dict[str, Any]:
            """포트폴리오 추천"""
            
            # 최소 점수 이상인 종목만 필터링
            qualified_stocks = [
                stock for stock in ranked_stocks
                if stock.get("unified_score", {}).get("total_score", 0) >= min_score
            ]
            
            # 섹터 다양화가 활성화된 경우
            if sector_diversification:
                # 간단한 섹터 다양화 로직 (실제로는 더 복잡함)
                portfolio_stocks = []
                used_sectors = set()
                
                for stock in qualified_stocks:
                    stock_sector = stock.get("sector", "기타")
                    
                    # 같은 섹터가 2개 이상 없도록 제한 (간단화)
                    sector_count = sum(1 for s in portfolio_stocks if s.get("sector") == stock_sector)
                    
                    if sector_count < 2 and len(portfolio_stocks) < max_stocks:
                        portfolio_stocks.append(stock)
                
                # 나머지 자리는 점수 순으로 채움
                remaining_slots = max_stocks - len(portfolio_stocks)
                for stock in qualified_stocks:
                    if stock not in portfolio_stocks and remaining_slots > 0:
                        portfolio_stocks.append(stock)
                        remaining_slots -= 1
            else:
                # 단순히 점수 순으로 선택
                portfolio_stocks = qualified_stocks[:max_stocks]
            
            # 포트폴리오 통계 계산
            if portfolio_stocks:
                avg_score = sum(s.get("unified_score", {}).get("total_score", 0) for s in portfolio_stocks) / len(portfolio_stocks)
                score_range = {
                    "min": min(s.get("unified_score", {}).get("total_score", 0) for s in portfolio_stocks),
                    "max": max(s.get("unified_score", {}).get("total_score", 0) for s in portfolio_stocks)
                }
            else:
                avg_score = 0
                score_range = {"min": 0, "max": 0}
            
            return {
                "portfolio_stocks": portfolio_stocks,
                "portfolio_size": len(portfolio_stocks),
                "statistics": {
                    "average_score": round(avg_score, 2),
                    "score_range": score_range,
                    "qualified_candidates": len(qualified_stocks),
                    "diversification_applied": sector_diversification
                },
                "recommendation_date": date.today(),
                "rebalancing_frequency": "weekly"
            }
        
        # 테스트 데이터 (섹터 정보 포함)
        ranked_stocks = [
            {
                "stock_code": "035420", "rank": 1, "sector": "제약바이오",
                "unified_score": {"total_score": 8.1}
            },
            {
                "stock_code": "005930", "rank": 2, "sector": "전기전자",
                "unified_score": {"total_score": 7.5}
            },
            {
                "stock_code": "000660", "rank": 3, "sector": "전기전자", 
                "unified_score": {"total_score": 6.2}
            },
            {
                "stock_code": "028260", "rank": 4, "sector": "제약바이오",
                "unified_score": {"total_score": 5.8}
            },
            {
                "stock_code": "051910", "rank": 5, "sector": "화학",
                "unified_score": {"total_score": 5.1}
            }
        ]
        
        # 다양화 적용 테스트
        portfolio_diversified = recommend_portfolio(
            ranked_stocks, 
            max_stocks=5, 
            min_score=5.0, 
            sector_diversification=True
        )
        
        assert portfolio_diversified["portfolio_size"] <= 5
        assert portfolio_diversified["statistics"]["average_score"] >= 5.0
        assert portfolio_diversified["statistics"]["diversification_applied"] == True
        
        # 섹터별 종목 수 확인 (간단한 다양화 로직)
        sectors = [stock.get("sector") for stock in portfolio_diversified["portfolio_stocks"]]
        sector_counts = {sector: sectors.count(sector) for sector in set(sectors)}
        assert all(count <= 2 for count in sector_counts.values())  # 섹터당 최대 2개
        
        # 다양화 미적용 테스트  
        portfolio_simple = recommend_portfolio(
            ranked_stocks,
            max_stocks=3,
            min_score=6.0,
            sector_diversification=False
        )
        
        assert portfolio_simple["portfolio_size"] == 3
        assert all(s.get("unified_score", {}).get("total_score", 0) >= 6.0 for s in portfolio_simple["portfolio_stocks"])
        assert portfolio_simple["statistics"]["diversification_applied"] == False

if __name__ == "__main__":
    pytest.main([__file__, "-v"])
