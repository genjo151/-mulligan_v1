# AI 머니 트래커 - API 라우팅 테스트

import pytest
import json
from fastapi.testclient import TestClient
from backend.main import app

client = TestClient(app)

class TestStockRoutes:
    """종목 관련 API 테스트"""
    
    def test_get_recommended_stocks_empty(self):
        """추천 종목 조회 - 빈 결과"""
        response = client.get("/api/v1/stocks/recommended")
        assert response.status_code == 200
        
        data = response.json()
        assert isinstance(data, list)
        # 초기에는 빈 리스트 반환
    
    def test_get_recommended_stocks_with_filters(self):
        """추천 종목 조회 - 필터 적용"""
        params = {
            "min_score": 5.5,
            "sectors": "technology,finance"
        }
        response = client.get("/api/v1/stocks/recommended", params=params)
        assert response.status_code == 200
        
        data = response.json()
        assert isinstance(data, list)
    
    def test_get_stock_detail_not_found(self):
        """종목 상세 정보 - 존재하지 않는 종목"""
        response = client.get("/api/v1/stocks/000000/detail")
        assert response.status_code == 404
        
        data = response.json()
        assert "detail" in data
    
    def test_get_stock_score_history_not_found(self):
        """종목 스코어 히스토리 - 존재하지 않는 종목"""
        response = client.get("/api/v1/stocks/000000/score-history")
        assert response.status_code == 404

class TestScanRoutes:
    """스캔 관련 API 테스트"""
    
    def test_get_scan_status(self):
        """스캔 상태 조회"""
        response = client.get("/api/v1/scan/status")
        assert response.status_code == 200
        
        data = response.json()
        assert "isRunning" in data
        assert "progress" in data
        assert "lastScanTime" in data
        assert isinstance(data["isRunning"], bool)
        assert isinstance(data["progress"], (int, float))
    
    def test_start_scan(self):
        """스캔 시작"""
        response = client.post("/api/v1/scan/start")
        assert response.status_code == 200
        
        data = response.json()
        assert "message" in data
        assert "status" in data
    
    def test_stop_scan(self):
        """스캔 중지"""
        response = client.post("/api/v1/scan/stop")
        assert response.status_code == 200
        
        data = response.json()
        assert "message" in data

class TestSettingsRoutes:
    """설정 관련 API 테스트"""
    
    def test_save_settings(self):
        """설정 저장"""
        settings_data = {
            "minScore": 6.0,
            "pushNotifications": True,
            "excludedSectors": ["banks", "insurance"]
        }
        
        response = client.post("/api/v1/settings", json=settings_data)
        assert response.status_code == 200
        
        data = response.json()
        assert "message" in data
        assert data["message"] == "설정이 저장되었습니다."
    
    def test_save_settings_invalid_data(self):
        """설정 저장 - 잘못된 데이터"""
        invalid_data = {
            "minScore": "invalid",  # 숫자가 아님
            "pushNotifications": "not_boolean"  # 불린이 아님
        }
        
        response = client.post("/api/v1/settings", json=invalid_data)
        assert response.status_code == 422  # Validation Error
    
    def test_get_settings(self):
        """설정 조회"""
        response = client.get("/api/v1/settings")
        assert response.status_code == 200
        
        data = response.json()
        assert "minScore" in data
        assert "pushNotifications" in data
        assert "excludedSectors" in data

class TestApiKeyRoutes:
    """API 키 테스트 관련"""
    
    def test_test_api_keys_missing_keys(self):
        """API 키 테스트 - 키 누락"""
        test_data = {
            "dartApiKey": "",
            "stockApiKey": ""
        }
        
        response = client.post("/api/v1/settings/test-api-keys", json=test_data)
        assert response.status_code == 200
        
        data = response.json()
        assert "dartApi" in data
        assert "stockApi" in data
        assert data["dartApi"]["success"] is False
        assert data["stockApi"]["success"] is False
    
    def test_test_api_keys_invalid_format(self):
        """API 키 테스트 - 잘못된 형식"""
        test_data = {
            "dartApiKey": "short",  # 너무 짧음
            "stockApiKey": "also_short"  # 너무 짧음
        }
        
        response = client.post("/api/v1/settings/test-api-keys", json=test_data)
        assert response.status_code == 200
        
        data = response.json()
        assert data["dartApi"]["success"] is False
        assert data["stockApi"]["success"] is False

class TestNotificationRoutes:
    """알림 관련 API 테스트"""
    
    def test_get_notification_history(self):
        """알림 히스토리 조회"""
        response = client.get("/api/v1/notifications/history")
        assert response.status_code == 200
        
        data = response.json()
        assert isinstance(data, list)
    
    def test_get_notification_history_with_limit(self):
        """알림 히스토리 조회 - 제한"""
        response = client.get("/api/v1/notifications/history?limit=10")
        assert response.status_code == 200
        
        data = response.json()
        assert isinstance(data, list)
        assert len(data) <= 10

if __name__ == "__main__":
    pytest.main([__file__, "-v"])
