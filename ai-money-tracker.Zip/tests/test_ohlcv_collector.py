# AI 머니 트래커 - OHLCV 데이터 수집기 테스트

import pytest
import asyncio
from datetime import datetime, date, timedelta
from unittest.mock import Mock, AsyncMock, patch
from typing import List, Dict, Any

from backend.services.data_collection.ohlcv_collector import (
    OHLCVDataCollector, OHLCVCollectionScheduler
)

class TestOHLCVDataCollector:
    """OHLCV 데이터 수집기 테스트"""
    
    @pytest.fixture
    def collector(self):
        """테스트용 OHLCV 수집기"""
        return OHLCVDataCollector(
            api_key="TEST_STOCK_API_KEY_1234567890",
            batch_size=5
        )
    
    @pytest.fixture
    def sample_ohlcv_data(self):
        """샘플 OHLCV 데이터"""
        return [
            {
                "stock_code": "005930",
                "date": "20241201",
                "open_price": "75000",
                "high_price": "76500",
                "low_price": "74500", 
                "close_price": "76000",
                "volume": "15000000",
                "trading_value": "1140000000000"
            },
            {
                "stock_code": "005930",
                "date": "20241130",
                "open_price": "74500",
                "high_price": "75200",
                "low_price": "74000",
                "close_price": "75000", 
                "volume": "12000000",
                "trading_value": "900000000000"
            }
        ]
    
    def test_collector_initialization(self, collector):
        """수집기 초기화 테스트"""
        assert collector.api_key == "TEST_STOCK_API_KEY_1234567890"
        assert collector.batch_size == 5
        assert collector.rate_limit == 20
        assert collector.timeout == 30
    
    def test_get_api_headers(self, collector):
        """API 헤더 생성 테스트"""
        headers = collector._get_api_headers()
        
        assert "Content-Type" in headers
        assert "authorization" in headers
        assert "tr_id" in headers
        assert headers["tr_id"] == "FHKST03010100"
    
    @pytest.mark.asyncio
    async def test_generate_mock_ohlcv_data(self, collector):
        """모의 OHLCV 데이터 생성 테스트"""
        data = await collector._generate_mock_ohlcv_data("005930", 5)
        
        assert len(data) == 5
        assert all(item["stock_code"] == "005930" for item in data)
        assert all("date" in item for item in data)
        assert all("open_price" in item for item in data)
        assert all("high_price" in item for item in data)
        assert all("low_price" in item for item in data)
        assert all("close_price" in item for item in data)
        assert all("volume" in item for item in data)
    
    @pytest.mark.asyncio
    async def test_collect_single_item(self, collector):
        """단일 종목 수집 테스트"""
        data = await collector.collect_single_item(
            "005930",
            start_date="20241101",
            end_date="20241201", 
            days=30
        )
        
        assert len(data) == 30
        assert all(item["stock_code"] == "005930" for item in data)
    
    def test_validate_data_valid(self, collector, sample_ohlcv_data):
        """유효한 데이터 검증 테스트"""
        for item in sample_ohlcv_data:
            errors = collector.validate_data(item)
            assert len(errors) == 0
    
    def test_validate_data_invalid(self, collector):
        """무효한 데이터 검증 테스트"""
        # 필수 필드 누락
        invalid_data1 = {
            "stock_code": "005930",
            "date": "20241201"
            # 가격 필드들 누락
        }
        errors1 = collector.validate_data(invalid_data1)
        assert len(errors1) > 0
        assert any("누락" in error for error in errors1)
        
        # 가격 일관성 오류
        invalid_data2 = {
            "stock_code": "005930",
            "date": "20241201",
            "open_price": "77000",  # 고가보다 높음
            "high_price": "76000",
            "low_price": "74000",
            "close_price": "75000",
            "volume": "10000000"
        }
        errors2 = collector.validate_data(invalid_data2)
        assert len(errors2) > 0
        assert any("범위" in error for error in errors2)
        
        # 잘못된 종목코드
        invalid_data3 = {
            "stock_code": "INVALID",
            "date": "20241201",
            "open_price": "75000",
            "high_price": "76000",
            "low_price": "74000",
            "close_price": "75000",
            "volume": "10000000"
        }
        errors3 = collector.validate_data(invalid_data3)
        assert len(errors3) > 0
        assert any("종목코드" in error for error in errors3)
    
    def test_detect_duplicates(self, collector):
        """중복 데이터 탐지 테스트"""
        data_with_duplicates = [
            {"stock_code": "005930", "date": "20241201", "close_price": "76000"},
            {"stock_code": "005930", "date": "20241201", "close_price": "76100"},  # 중복
            {"stock_code": "005930", "date": "20241130", "close_price": "75000"},
            {"stock_code": "000660", "date": "20241201", "close_price": "128000"}
        ]
        
        duplicates = collector.detect_duplicates(
            data_with_duplicates, 
            ["stock_code", "date"]
        )
        
        assert len(duplicates) == 1
        assert duplicates[0]["close_price"] == "76100"
    
    @pytest.mark.asyncio
    async def test_collect_data_with_stock_codes(self, collector):
        """특정 종목코드로 데이터 수집 테스트"""
        stock_codes = ["005930", "000660"]
        
        data = await collector.collect_data(
            stock_codes=stock_codes,
            days=10
        )
        
        # 모의 데이터이므로 각 종목당 10개씩 총 20개 예상
        assert len(data) == 20
        
        collected_codes = set(item["stock_code"] for item in data)
        assert collected_codes == set(stock_codes)

class TestOHLCVCollectionScheduler:
    """OHLCV 수집 스케줄러 테스트"""
    
    @pytest.fixture
    def collector(self):
        """테스트용 수집기"""
        return OHLCVDataCollector(
            api_key="TEST_STOCK_API_KEY_1234567890"
        )
    
    @pytest.fixture
    def scheduler(self, collector):
        """테스트용 스케줄러"""
        return OHLCVCollectionScheduler(collector)
    
    def test_scheduler_initialization(self, scheduler):
        """스케줄러 초기화 테스트"""
        assert scheduler.collector is not None
        assert scheduler.is_running == False
        assert scheduler.last_collection_time is None
    
    @pytest.mark.asyncio
    async def test_run_daily_collection(self, scheduler):
        """일일 수집 실행 테스트"""
        # 모의 저장 결과
        with patch.object(scheduler.collector, 'save_to_database') as mock_save:
            mock_save.return_value = {
                "total_received": 100,
                "validation_passed": 95,
                "duplicates_removed": 5,
                "saved_count": 90
            }
            
            result = await scheduler.run_daily_collection(
                stock_codes=["005930", "000660"],
                days=30
            )
            
            assert result["success"] == True
            assert "collection_result" in result
            assert "duration_seconds" in result
            assert result["target_stocks"] == 2
    
    def test_get_collection_status(self, scheduler):
        """수집 상태 조회 테스트"""
        status = scheduler.get_collection_status()
        
        assert "scheduler_type" in status
        assert "is_running" in status
        assert "last_collection_time" in status
        assert status["scheduler_type"] == "ohlcv_daily"

class TestOHLCVIntegration:
    """OHLCV 통합 테스트"""
    
    @pytest.mark.asyncio
    async def test_end_to_end_collection_flow(self):
        """전체 수집 플로우 테스트"""
        # 1. 수집기 초기화
        collector = OHLCVDataCollector(
            api_key="TEST_STOCK_API_KEY_1234567890",
            batch_size=2
        )
        
        # 2. 데이터 수집
        async with collector:
            data = await collector.collect_data(
                stock_codes=["005930", "000660"],
                days=5
            )
        
        # 3. 데이터 검증
        assert len(data) == 10  # 2개 종목 * 5일
        
        for item in data:
            errors = collector.validate_data(item)
            assert len(errors) == 0, f"검증 실패: {item}, 오류: {errors}"
        
        # 4. 중복 검사
        duplicates = collector.detect_duplicates(data, ["stock_code", "date"])
        assert len(duplicates) == 0, f"중복 데이터 발견: {duplicates}"
    
    @pytest.mark.asyncio
    async def test_error_handling(self):
        """오류 처리 테스트"""
        collector = OHLCVDataCollector(
            api_key="INVALID_KEY",
            max_retries=1
        )
        
        # 잘못된 API 키로 수집 시도
        async with collector:
            data = await collector.collect_data(
                stock_codes=["INVALID"],
                days=1
            )
        
        # 오류 상황에서도 빈 리스트 반환되어야 함
        assert isinstance(data, list)
    
    @pytest.mark.asyncio
    async def test_rate_limiting(self):
        """속도 제한 테스트"""
        collector = OHLCVDataCollector(
            api_key="TEST_STOCK_API_KEY_1234567890",
            rate_limit=2  # 초당 2개 요청
        )
        
        start_time = datetime.now()
        
        async with collector:
            # 속도 제한 확인
            await collector._check_rate_limit()
            await collector._check_rate_limit()
            await collector._check_rate_limit()  # 이 시점에서 대기 발생
        
        end_time = datetime.now()
        duration = (end_time - start_time).total_seconds()
        
        # 속도 제한으로 인해 최소 0.5초는 걸려야 함
        assert duration >= 0.5

if __name__ == "__main__":
    pytest.main([__file__, "-v"])
