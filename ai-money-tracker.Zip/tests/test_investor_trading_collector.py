# AI 머니 트래커 - 투자자별 매매동향 수집기 테스트

import pytest
import asyncio
from datetime import datetime, date, timedelta
from unittest.mock import Mock, AsyncMock, patch
from typing import List, Dict, Any

class TestInvestorTradingCollector:
    """투자자별 매매동향 수집기 테스트"""
    
    @pytest.fixture
    def sample_trading_data(self):
        """샘플 매매동향 데이터"""
        return [
            {
                "stock_code": "005930",
                "date": "20241201",
                "individual_buy": "500000000",
                "individual_sell": "450000000",
                "individual_net": "50000000",
                "institution_buy": "300000000",
                "institution_sell": "280000000", 
                "institution_net": "20000000",
                "foreign_buy": "200000000",
                "foreign_sell": "180000000",
                "foreign_net": "20000000",
                "trust_buy": "100000000",
                "trust_sell": "90000000",
                "trust_net": "10000000",
                "pension_buy": "50000000",
                "pension_sell": "45000000",
                "pension_net": "5000000"
            },
            {
                "stock_code": "005930",
                "date": "20241130",
                "individual_buy": "480000000",
                "individual_sell": "520000000",
                "individual_net": "-40000000",
                "institution_buy": "320000000",
                "institution_sell": "300000000",
                "institution_net": "20000000",
                "foreign_buy": "180000000",
                "foreign_sell": "200000000",
                "foreign_net": "-20000000",
                "trust_buy": "80000000",
                "trust_sell": "85000000",
                "trust_net": "-5000000",
                "pension_buy": "40000000",
                "pension_sell": "42000000",
                "pension_net": "-2000000"
            }
        ]
    
    def test_collector_initialization_requirements(self):
        """수집기 초기화 요구사항 테스트"""
        collector_config = {
            "api_key": "test_api_key",
            "base_url": "https://openapi.koreainvestment.com",
            "timeout": 30,
            "max_retries": 3,
            "batch_size": 50,
            "rate_limit": 10  # 초당 10개 요청
        }
        
        for key, value in collector_config.items():
            assert key is not None
            assert value is not None
    
    @pytest.mark.asyncio
    async def test_collect_single_stock_trading_data(self):
        """단일 종목 매매동향 수집 테스트"""
        
        async def mock_collect_trading(stock_code: str, date_str: str):
            """모의 매매동향 데이터 수집"""
            if stock_code == "005930":
                return {
                    "stock_code": stock_code,
                    "date": date_str,
                    "individual_buy": "500000000",
                    "individual_sell": "450000000",
                    "institution_buy": "300000000",
                    "institution_sell": "280000000",
                    "foreign_buy": "200000000",
                    "foreign_sell": "180000000"
                }
            return None
        
        result = await mock_collect_trading("005930", "20241201")
        
        assert result is not None
        assert result["stock_code"] == "005930"
        assert "individual_buy" in result
        assert "institution_buy" in result
        assert "foreign_buy" in result
    
    def test_calculate_net_trading_amounts(self, sample_trading_data):
        """순매수 금액 계산 테스트"""
        
        def calculate_net_amounts(trading_data: Dict[str, Any]) -> Dict[str, int]:
            """순매수 금액 계산"""
            individual_net = int(trading_data["individual_buy"]) - int(trading_data["individual_sell"])
            institution_net = int(trading_data["institution_buy"]) - int(trading_data["institution_sell"])
            foreign_net = int(trading_data["foreign_buy"]) - int(trading_data["foreign_sell"])
            trust_net = int(trading_data.get("trust_buy", 0)) - int(trading_data.get("trust_sell", 0))
            pension_net = int(trading_data.get("pension_buy", 0)) - int(trading_data.get("pension_sell", 0))
            
            return {
                "individual_net": individual_net,
                "institution_net": institution_net,
                "foreign_net": foreign_net,
                "trust_net": trust_net,
                "pension_net": pension_net,
                "institution_foreign_net": institution_net + foreign_net
            }
        
        # 첫 번째 데이터 (모두 순매수)
        trading_data1 = sample_trading_data[0]
        net_amounts1 = calculate_net_amounts(trading_data1)
        
        assert net_amounts1["individual_net"] == 50000000  # 개인 5천만원 순매수
        assert net_amounts1["institution_net"] == 20000000  # 기관 2천만원 순매수
        assert net_amounts1["foreign_net"] == 20000000  # 외국인 2천만원 순매수
        assert net_amounts1["institution_foreign_net"] == 40000000  # 기관+외국인 4천만원 순매수
        
        # 두 번째 데이터 (일부 순매도)
        trading_data2 = sample_trading_data[1]
        net_amounts2 = calculate_net_amounts(trading_data2)
        
        assert net_amounts2["individual_net"] == -40000000  # 개인 4천만원 순매도
        assert net_amounts2["foreign_net"] == -20000000  # 외국인 2천만원 순매도
    
    def test_validate_trading_data(self, sample_trading_data):
        """매매동향 데이터 검증 테스트"""
        
        def validate_trading_data(data: Dict[str, Any]) -> List[str]:
            """매매동향 데이터 검증"""
            errors = []
            
            # 필수 필드 검증
            required_fields = [
                "stock_code", "date", 
                "individual_buy", "individual_sell",
                "institution_buy", "institution_sell",
                "foreign_buy", "foreign_sell"
            ]
            
            for field in required_fields:
                if field not in data or data[field] is None:
                    errors.append(f"필수 필드 '{field}' 누락")
            
            # 종목코드 검증
            if "stock_code" in data:
                stock_code = data["stock_code"]
                if not (isinstance(stock_code, str) and len(stock_code) == 6 and stock_code.isdigit()):
                    errors.append(f"유효하지 않은 종목코드: {stock_code}")
            
            # 날짜 형식 검증
            if "date" in data:
                try:
                    datetime.strptime(data["date"], "%Y%m%d")
                except ValueError:
                    errors.append(f"유효하지 않은 날짜 형식: {data['date']}")
            
            # 매매금액 검증 (음수 불가)
            trading_fields = [
                "individual_buy", "individual_sell",
                "institution_buy", "institution_sell", 
                "foreign_buy", "foreign_sell"
            ]
            
            for field in trading_fields:
                if field in data:
                    try:
                        amount = int(data[field])
                        if amount < 0:
                            errors.append(f"{field}가 음수: {amount}")
                    except (ValueError, TypeError):
                        errors.append(f"{field}가 숫자가 아님: {data[field]}")
            
            return errors
        
        # 유효한 데이터 테스트
        for item in sample_trading_data:
            errors = validate_trading_data(item)
            assert len(errors) == 0, f"검증 실패: {errors}"
        
        # 무효한 데이터 테스트
        invalid_data = {
            "stock_code": "INVALID",  # 잘못된 종목코드
            "date": "2024-12-01",     # 잘못된 날짜 형식
            "individual_buy": "-1000000",  # 음수 금액
            "individual_sell": "abc",      # 숫자가 아님
            # 필수 필드 누락
        }
        
        errors = validate_trading_data(invalid_data)
        assert len(errors) > 0
    
    @pytest.mark.asyncio
    async def test_batch_collection_trading_data(self):
        """배치 수집 테스트"""
        
        async def mock_batch_collect(stock_codes: List[str], target_date: str):
            """모의 배치 수집"""
            results = {}
            
            for code in stock_codes:
                if code in ["005930", "000660"]:
                    results[code] = {
                        "stock_code": code,
                        "date": target_date,
                        "individual_buy": "500000000",
                        "individual_sell": "450000000",
                        "institution_buy": "300000000",
                        "institution_sell": "280000000",
                        "foreign_buy": "200000000",
                        "foreign_sell": "180000000"
                    }
                else:
                    results[code] = None  # 데이터 없음
            
            return results
        
        stock_codes = ["005930", "000660", "035420"]
        target_date = "20241201"
        
        results = await mock_batch_collect(stock_codes, target_date)
        
        assert len(results) == 3
        assert results["005930"] is not None
        assert results["000660"] is not None  
        assert results["035420"] is None  # 데이터 없음
    
    def test_aggregate_trading_summary(self, sample_trading_data):
        """매매동향 집계 테스트"""
        
        def aggregate_trading_summary(data_list: List[Dict]) -> Dict[str, Any]:
            """매매동향 집계"""
            summary = {
                "period_start": None,
                "period_end": None,
                "total_days": len(data_list),
                "cumulative_net": {
                    "individual": 0,
                    "institution": 0,
                    "foreign": 0,
                    "trust": 0,
                    "pension": 0
                },
                "daily_average": {}
            }
            
            if not data_list:
                return summary
            
            # 기간 계산
            dates = [item["date"] for item in data_list]
            summary["period_start"] = min(dates)
            summary["period_end"] = max(dates)
            
            # 누적 순매수 계산
            for item in data_list:
                summary["cumulative_net"]["individual"] += int(item.get("individual_net", 0))
                summary["cumulative_net"]["institution"] += int(item.get("institution_net", 0))
                summary["cumulative_net"]["foreign"] += int(item.get("foreign_net", 0))
                summary["cumulative_net"]["trust"] += int(item.get("trust_net", 0))
                summary["cumulative_net"]["pension"] += int(item.get("pension_net", 0))
            
            # 일평균 계산
            if summary["total_days"] > 0:
                for investor_type, cumulative in summary["cumulative_net"].items():
                    summary["daily_average"][investor_type] = cumulative / summary["total_days"]
            
            return summary
        
        summary = aggregate_trading_summary(sample_trading_data)
        
        assert summary["total_days"] == 2
        assert summary["period_start"] == "20241130"
        assert summary["period_end"] == "20241201"
        
        # 누적 순매수 (50M + (-40M) = 10M)
        assert summary["cumulative_net"]["individual"] == 10000000
        # 기관 (20M + 20M = 40M)
        assert summary["cumulative_net"]["institution"] == 40000000
        # 외국인 (20M + (-20M) = 0)
        assert summary["cumulative_net"]["foreign"] == 0
    
    def test_detect_trading_patterns(self, sample_trading_data):
        """매매 패턴 탐지 테스트"""
        
        def detect_trading_patterns(data_list: List[Dict]) -> Dict[str, Any]:
            """매매 패턴 탐지"""
            patterns = {
                "institution_foreign_buying": False,  # 기관+외국인 연속 순매수
                "individual_selling": False,          # 개인 연속 순매도
                "foreign_accumulation": False,        # 외국인 누적 매수
                "institutional_strength": 0.0         # 기관 매수력
            }
            
            if len(data_list) < 2:
                return patterns
            
            # 정렬 (날짜순)
            sorted_data = sorted(data_list, key=lambda x: x["date"])
            
            # 기관+외국인 연속 순매수 체크
            institution_foreign_net = []
            individual_net = []
            
            for item in sorted_data:
                inst_net = int(item.get("institution_net", 0))
                foreign_net = int(item.get("foreign_net", 0))
                indiv_net = int(item.get("individual_net", 0))
                
                institution_foreign_net.append(inst_net + foreign_net)
                individual_net.append(indiv_net)
            
            # 패턴 분석
            if len(institution_foreign_net) >= 2:
                patterns["institution_foreign_buying"] = all(net > 0 for net in institution_foreign_net)
                patterns["individual_selling"] = all(net < 0 for net in individual_net)
                
                # 외국인 누적 매수 (총합이 양수)
                total_foreign = sum(int(item.get("foreign_net", 0)) for item in sorted_data)
                patterns["foreign_accumulation"] = total_foreign > 0
                
                # 기관 매수력 (평균 순매수 비율)
                total_institution = sum(int(item.get("institution_net", 0)) for item in sorted_data)
                total_trading = sum(int(item.get("institution_buy", 0)) + int(item.get("institution_sell", 0)) for item in sorted_data)
                
                if total_trading > 0:
                    patterns["institutional_strength"] = total_institution / total_trading
            
            return patterns
        
        patterns = detect_trading_patterns(sample_trading_data)
        
        # 기관+외국인이 모든 날에 순매수했는지 확인
        # 첫날: 20M + 20M = 40M (양수), 둘째날: 20M + (-20M) = 0 (0 이상)
        assert patterns["institution_foreign_buying"] == False  # 둘째날이 0이므로
        
        # 개인이 모든 날에 순매도했는지 확인  
        # 첫날: 50M (양수), 둘째날: -40M (음수)
        assert patterns["individual_selling"] == False  # 첫날이 양수이므로
    
    @pytest.mark.asyncio
    async def test_error_handling_and_retry(self):
        """오류 처리 및 재시도 테스트"""
        
        async def mock_failing_collector(stock_code: str, retry_count: int = 0):
            """실패하는 수집기 모의"""
            if retry_count < 2:
                raise Exception("네트워크 오류")
            else:
                return {
                    "stock_code": stock_code,
                    "date": "20241201",
                    "individual_buy": "100000000",
                    "individual_sell": "90000000"
                }
        
        # 재시도 로직 테스트
        max_retries = 3
        for attempt in range(max_retries):
            try:
                result = await mock_failing_collector("005930", attempt)
                assert result is not None
                break
            except Exception as e:
                if attempt == max_retries - 1:
                    pytest.fail("최대 재시도 횟수 초과")
                continue
    
    def test_data_storage_format(self, sample_trading_data):
        """데이터 저장 형식 테스트"""
        
        def convert_to_database_format(trading_data: Dict[str, Any]) -> Dict[str, Any]:
            """데이터베이스 저장 형식으로 변환"""
            db_format = {
                "stock_code": trading_data["stock_code"],
                "date": datetime.strptime(trading_data["date"], "%Y%m%d").date(),
                "individual_buy": int(trading_data["individual_buy"]),
                "individual_sell": int(trading_data["individual_sell"]),
                "individual_net": int(trading_data.get("individual_net", 0)),
                "institution_buy": int(trading_data["institution_buy"]),
                "institution_sell": int(trading_data["institution_sell"]),
                "institution_net": int(trading_data.get("institution_net", 0)),
                "foreign_buy": int(trading_data["foreign_buy"]),
                "foreign_sell": int(trading_data["foreign_sell"]),
                "foreign_net": int(trading_data.get("foreign_net", 0)),
                "trust_buy": int(trading_data.get("trust_buy", 0)),
                "trust_sell": int(trading_data.get("trust_sell", 0)),
                "trust_net": int(trading_data.get("trust_net", 0)),
                "pension_buy": int(trading_data.get("pension_buy", 0)),
                "pension_sell": int(trading_data.get("pension_sell", 0)),
                "pension_net": int(trading_data.get("pension_net", 0))
            }
            
            return db_format
        
        for item in sample_trading_data:
            db_item = convert_to_database_format(item)
            
            assert isinstance(db_item["date"], date)
            assert isinstance(db_item["individual_buy"], int)
            assert isinstance(db_item["institution_net"], int)
            assert db_item["stock_code"] == item["stock_code"]

if __name__ == "__main__":
    pytest.main([__file__, "-v"])
