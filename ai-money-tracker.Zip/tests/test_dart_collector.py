# AI 머니 트래커 - DART 공시 데이터 수집기 테스트

import pytest
import asyncio
from datetime import datetime, date, timedelta
from unittest.mock import Mock, AsyncMock, patch
from typing import List, Dict, Any
import json

class TestDartDataCollector:
    """DART 공시 데이터 수집기 테스트"""
    
    @pytest.fixture
    def sample_dart_list_response(self):
        """샘플 DART 공시 목록 응답"""
        return {
            "status": "000",
            "message": "정상",
            "page_no": 1,
            "page_count": 10,
            "total_count": 10,
            "total_page": 1,
            "list": [
                {
                    "corp_cls": "Y",
                    "corp_name": "삼성전자",
                    "corp_code": "00126380",
                    "stock_code": "005930",
                    "report_nm": "대량보유상황보고서",
                    "rcept_no": "20240915000001",
                    "flr_nm": "테스트투자운용",
                    "rcept_dt": "20240915",
                    "rm": "대량보유상황보고서"
                },
                {
                    "corp_cls": "Y", 
                    "corp_name": "SK하이닉스",
                    "corp_code": "00164779",
                    "stock_code": "000660",
                    "report_nm": "주요사항보고서",
                    "rcept_no": "20240915000002",
                    "flr_nm": "SK하이닉스",
                    "rcept_dt": "20240915",
                    "rm": "임원ㆍ주요주주특정증권등소유상황보고서"
                }
            ]
        }
    
    @pytest.fixture
    def sample_majorstock_response(self):
        """샘플 대량보유 상세 정보 응답"""
        return {
            "status": "000",
            "message": "정상",
            "list": [
                {
                    "rcept_no": "20240915000001",
                    "rcept_dt": "20240915",
                    "corp_cls": "Y",
                    "corp_code": "00126380",
                    "corp_name": "삼성전자",
                    "report_nm": "대량보유상황보고서",
                    "flr_nm": "테스트투자운용",
                    "isu_nm": "삼성전자",
                    "isu_cd": "KR7005930003",
                    "isu_stkprc": "71000",
                    "ctr_stkprc": "71000",
                    "reporter_nm": "테스트투자운용",
                    "rpt_duty_occrrn_dt": "20240910",
                    "hold_stock_co": "15000000",
                    "hold_stock_rt": "5.25",
                    "change_stock_co": "1000000",
                    "change_stock_rt": "0.35"
                }
            ]
        }
    
    @pytest.fixture
    def sample_elestock_response(self):
        """샘플 임원·주요주주 소유보고서 응답"""
        return {
            "status": "000",
            "message": "정상",
            "list": [
                {
                    "rcept_no": "20240915000002",
                    "rcept_dt": "20240915",
                    "corp_cls": "Y",
                    "corp_code": "00164779",
                    "corp_name": "SK하이닉스",
                    "isu_nm": "SK하이닉스",
                    "isu_cd": "KR7000660001",
                    "rep_nm": "이석희",
                    "ownstock_co": "100000",
                    "ownstock_rt": "0.01",
                    "change_co": "0",
                    "change_rt": "0.00"
                }
            ]
        }
    
    def test_dart_collector_initialization(self):
        """DART 수집기 초기화 테스트"""
        collector_config = {
            "api_key": "test_dart_api_key",
            "base_url": "https://opendart.fss.or.kr",
            "timeout": 45,
            "max_retries": 5,
            "rate_limit": 100,  # 일일 10000개 요청이지만 분산처리
            "collection_frequency": "hourly"
        }
        
        for key, value in collector_config.items():
            assert key is not None
            assert value is not None
    
    @pytest.mark.asyncio
    async def test_collect_recent_disclosures(self, sample_dart_list_response):
        """최근 공시 목록 수집 테스트"""
        
        async def mock_collect_list(begin_de: str, end_de: str, corp_cls: str = "Y"):
            """모의 공시 목록 수집"""
            return sample_dart_list_response["list"]
        
        begin_date = "20240915"
        end_date = "20240915"
        
        result = await mock_collect_list(begin_date, end_date)
        
        assert len(result) == 2
        assert result[0]["corp_name"] == "삼성전자"
        assert result[0]["stock_code"] == "005930"
        assert result[0]["report_nm"] == "대량보유상황보고서"
        assert result[1]["corp_name"] == "SK하이닉스"
        assert result[1]["stock_code"] == "000660"
    
    @pytest.mark.asyncio
    async def test_collect_majorstock_details(self, sample_majorstock_response):
        """대량보유 상세 정보 수집 테스트"""
        
        async def mock_collect_majorstock(rcept_no: str):
            """모의 대량보유 상세 정보 수집"""
            if rcept_no == "20240915000001":
                return sample_majorstock_response["list"]
            return []
        
        result = await mock_collect_majorstock("20240915000001")
        
        assert len(result) == 1
        assert result[0]["corp_name"] == "삼성전자"
        assert result[0]["reporter_nm"] == "테스트투자운용"
        assert float(result[0]["hold_stock_rt"]) == 5.25
        assert int(result[0]["hold_stock_co"]) == 15000000
    
    @pytest.mark.asyncio
    async def test_collect_elestock_details(self, sample_elestock_response):
        """임원·주요주주 소유보고서 수집 테스트"""
        
        async def mock_collect_elestock(rcept_no: str):
            """모의 임원·주요주주 소유보고서 수집"""
            if rcept_no == "20240915000002":
                return sample_elestock_response["list"]
            return []
        
        result = await mock_collect_elestock("20240915000002")
        
        assert len(result) == 1
        assert result[0]["corp_name"] == "SK하이닉스"
        assert result[0]["rep_nm"] == "이석희"
        assert int(result[0]["ownstock_co"]) == 100000
        assert float(result[0]["ownstock_rt"]) == 0.01
    
    def test_filter_relevant_disclosures(self):
        """관련 공시 필터링 테스트"""
        
        def filter_relevant_reports(disclosures: List[Dict], keywords: List[str]) -> List[Dict]:
            """관련 공시 필터링"""
            relevant_reports = []
            
            for disclosure in disclosures:
                report_name = disclosure.get("report_nm", "").lower()
                rm = disclosure.get("rm", "").lower()
                
                # 키워드 매칭
                for keyword in keywords:
                    if keyword.lower() in report_name or keyword.lower() in rm:
                        relevant_reports.append(disclosure)
                        break
            
            return relevant_reports
        
        test_disclosures = [
            {"report_nm": "대량보유상황보고서", "rm": "대량보유상황보고서", "rcept_no": "1"},
            {"report_nm": "주요사항보고서", "rm": "임원ㆍ주요주주특정증권등소유상황보고서", "rcept_no": "2"},
            {"report_nm": "분기보고서", "rm": "분기보고서", "rcept_no": "3"},
            {"report_nm": "반기보고서", "rm": "반기보고서", "rcept_no": "4"},
            {"report_nm": "사업보고서", "rm": "사업보고서", "rcept_no": "5"}
        ]
        
        # DART 6요소 관련 키워드
        dart_keywords = ["대량보유", "주요사항", "임원", "주요주주", "특정증권"]
        
        filtered = filter_relevant_reports(test_disclosures, dart_keywords)
        
        assert len(filtered) == 2  # 대량보유, 주요사항보고서만
        rcept_nos = [r["rcept_no"] for r in filtered]
        assert "1" in rcept_nos  # 대량보유상황보고서
        assert "2" in rcept_nos  # 주요사항보고서
        assert "3" not in rcept_nos  # 분기보고서 제외
    
    def test_validate_dart_disclosure_data(self, sample_dart_list_response):
        """DART 공시 데이터 검증 테스트"""
        
        def validate_disclosure_data(data: Dict[str, Any]) -> List[str]:
            """DART 공시 데이터 검증"""
            errors = []
            
            # 필수 필드 검증
            required_fields = [
                "rcept_no", "corp_name", "corp_code", "rcept_dt", 
                "report_nm", "flr_nm"
            ]
            
            for field in required_fields:
                if field not in data or not data[field]:
                    errors.append(f"필수 필드 '{field}' 누락")
            
            # 접수번호 형식 검증
            if "rcept_no" in data:
                rcept_no = data["rcept_no"]
                if not (isinstance(rcept_no, str) and len(rcept_no) >= 14):
                    errors.append(f"유효하지 않은 접수번호 형식: {rcept_no}")
            
            # 날짜 형식 검증
            if "rcept_dt" in data:
                try:
                    datetime.strptime(data["rcept_dt"], "%Y%m%d")
                except ValueError:
                    errors.append(f"유효하지 않은 날짜 형식: {data['rcept_dt']}")
            
            # 법인코드 형식 검증
            if "corp_code" in data:
                corp_code = data["corp_code"]
                if not (isinstance(corp_code, str) and len(corp_code) == 8):
                    errors.append(f"유효하지 않은 법인코드 형식: {corp_code}")
            
            return errors
        
        # 유효한 데이터 테스트
        for item in sample_dart_list_response["list"]:
            errors = validate_disclosure_data(item)
            assert len(errors) == 0, f"검증 실패: {errors}"
        
        # 무효한 데이터 테스트
        invalid_data = {
            "rcept_no": "123",  # 너무 짧음
            "corp_name": "",    # 빈 값
            "rcept_dt": "2024-09-15",  # 잘못된 형식
            "corp_code": "123456789",  # 길이 초과
        }
        
        errors = validate_disclosure_data(invalid_data)
        assert len(errors) > 0
    
    def test_calculate_dart_scores(self):
        """DART 점수 계산 테스트"""
        
        def calculate_dart_scores(disclosures: List[Dict]) -> Dict[str, float]:
            """DART 6요소 점수 계산"""
            scores = {
                "dart1_major_shareholding": 0.0,  # 대량보유 (1.5점)
                "dart2_executive_shareholding": 0.0,  # 임원 지분 변동 (1.5점)
                "dart3_material_events": 0.0,  # 주요사항 (1.0점)
                "dart4_disclosure_frequency": 0.0,  # 공시 빈도 (1.0점)
                "dart5_shareholding_changes": 0.0,  # 지분 변동률 (1.0점)
                "dart6_disclosure_timing": 0.0  # 공시 시점 (0.9점)
            }
            
            disclosure_count = len(disclosures)
            
            # 각 유형별로 한번만 점수 부여
            has_major_shareholding = False
            has_executive_shareholding = False
            has_material_events = False
            
            for disclosure in disclosures:
                report_nm = disclosure.get("report_nm", "")
                rm = disclosure.get("rm", "")
                
                # DART 1: 대량보유상황보고서 (1.5점)
                if not has_major_shareholding and ("대량보유" in report_nm or "대량보유" in rm):
                    scores["dart1_major_shareholding"] = 1.5
                    has_major_shareholding = True
                
                # DART 2: 임원·주요주주 소유보고서 (1.5점)
                if not has_executive_shareholding and ("임원" in rm or "주요주주" in rm):
                    scores["dart2_executive_shareholding"] = 1.5
                    has_executive_shareholding = True
                
                # DART 3: 주요사항보고서 (1.0점)
                if not has_material_events and "주요사항" in report_nm:
                    scores["dart3_material_events"] = 1.0
                    has_material_events = True
            
            # DART 4: 공시 빈도 (1.0점 - 3개 이상시 만점)
            if disclosure_count >= 3:
                scores["dart4_disclosure_frequency"] = 1.0
            elif disclosure_count >= 2:
                scores["dart4_disclosure_frequency"] = 0.7
            elif disclosure_count >= 1:
                scores["dart4_disclosure_frequency"] = 0.5
            
            # DART 5: 지분 변동률 (실제 구현시 상세 데이터 필요)
            # DART 6: 공시 시점 (실제 구현시 시장 시간 고려)
            
            total_score = sum(scores.values())
            
            return {
                **scores,
                "total_score": min(total_score, 8.9)  # 최대 8.9점
            }
        
        # 테스트 공시 데이터
        test_disclosures = [
            {"report_nm": "대량보유상황보고서", "rm": "대량보유상황보고서"},
            {"report_nm": "주요사항보고서", "rm": "임원ㆍ주요주주특정증권등소유상황보고서"},
            {"report_nm": "주요사항보고서", "rm": "주요사항보고서"}
        ]
        
        scores = calculate_dart_scores(test_disclosures)
        
        assert scores["dart1_major_shareholding"] == 1.5  # 대량보유
        assert scores["dart2_executive_shareholding"] == 1.5  # 임원·주요주주
        assert scores["dart3_material_events"] == 1.0  # 주요사항
        assert scores["dart4_disclosure_frequency"] == 1.0  # 3개 공시
        assert scores["total_score"] == 5.0  # 1.5 + 1.5 + 1.0 + 1.0
    
    @pytest.mark.asyncio
    async def test_batch_disclosure_collection(self):
        """배치 공시 수집 테스트"""
        
        async def mock_batch_collect(stock_codes: List[str], date_range: int):
            """모의 배치 공시 수집"""
            results = {}
            
            for code in stock_codes:
                if code == "005930":
                    results[code] = [
                        {"report_nm": "대량보유상황보고서", "rcept_dt": "20240915"},
                        {"report_nm": "주요사항보고서", "rcept_dt": "20240914"}
                    ]
                elif code == "000660":
                    results[code] = [
                        {"report_nm": "주요사항보고서", "rcept_dt": "20240915"}
                    ]
                else:
                    results[code] = []
            
            return results
        
        stock_codes = ["005930", "000660", "035420"]
        results = await mock_batch_collect(stock_codes, 30)
        
        assert len(results) == 3
        assert len(results["005930"]) == 2
        assert len(results["000660"]) == 1
        assert len(results["035420"]) == 0
    
    def test_disclosure_timing_analysis(self):
        """공시 시점 분석 테스트"""
        
        def analyze_disclosure_timing(disclosures: List[Dict]) -> Dict[str, Any]:
            """공시 시점 분석"""
            if not disclosures:
                return {"timing_score": 0.0, "analysis": "공시 없음"}
            
            # 공시 시간대별 분포 (실제로는 rcept_tm 필드 사용)
            business_hours_count = 0
            after_hours_count = 0
            
            timing_score = 0.0
            analysis_notes = []
            
            for disclosure in disclosures:
                # 모의 시간 분석 (실제로는 더 복잡한 로직)
                rcept_dt = disclosure.get("rcept_dt")
                if rcept_dt:
                    # 간단한 해시 기반 시간 모의
                    hour = abs(hash(rcept_dt)) % 24
                    
                    if 9 <= hour <= 15:  # 장중
                        business_hours_count += 1
                        analysis_notes.append(f"장중 공시: {rcept_dt}")
                    else:  # 장외
                        after_hours_count += 1
                        analysis_notes.append(f"장외 공시: {rcept_dt}")
            
            # 시점 점수 계산
            total_count = len(disclosures)
            if total_count > 0:
                after_hours_ratio = after_hours_count / total_count
                if after_hours_ratio >= 0.8:  # 80% 이상 장외
                    timing_score = 0.9
                elif after_hours_ratio >= 0.5:  # 50% 이상 장외
                    timing_score = 0.6
                else:
                    timing_score = 0.3
            
            return {
                "timing_score": timing_score,
                "business_hours_count": business_hours_count,
                "after_hours_count": after_hours_count,
                "after_hours_ratio": after_hours_count / total_count if total_count > 0 else 0,
                "analysis": analysis_notes
            }
        
        test_disclosures = [
            {"rcept_dt": "20240915"},  # 해시 -> 시간 변환
            {"rcept_dt": "20240914"},
            {"rcept_dt": "20240913"}
        ]
        
        analysis = analyze_disclosure_timing(test_disclosures)
        
        assert "timing_score" in analysis
        assert "business_hours_count" in analysis
        assert "after_hours_count" in analysis
        assert analysis["timing_score"] >= 0.0
        assert analysis["timing_score"] <= 0.9
    
    def test_data_storage_format(self, sample_dart_list_response):
        """데이터 저장 형식 테스트"""
        
        def convert_to_database_format(disclosure: Dict[str, Any]) -> Dict[str, Any]:
            """데이터베이스 저장 형식으로 변환"""
            db_format = {
                "rcept_no": disclosure["rcept_no"],
                "corp_name": disclosure["corp_name"],
                "corp_code": disclosure["corp_code"],
                "stock_code": disclosure.get("stock_code"),
                "report_nm": disclosure["report_nm"],
                "rcept_dt": datetime.strptime(disclosure["rcept_dt"], "%Y%m%d").date(),
                "flr_nm": disclosure["flr_nm"],
                "rm": disclosure["rm"],
                "processed_at": datetime.now()
            }
            
            return db_format
        
        for item in sample_dart_list_response["list"]:
            db_item = convert_to_database_format(item)
            
            assert isinstance(db_item["rcept_dt"], date)
            assert isinstance(db_item["processed_at"], datetime)
            assert db_item["corp_name"] in ["삼성전자", "SK하이닉스"]
            assert db_item["stock_code"] in ["005930", "000660"]

class TestDartScheduler:
    """DART 수집 스케줄러 테스트"""
    
    def test_hourly_collection_schedule(self):
        """시간별 수집 스케줄 테스트"""
        
        def should_collect_now(current_hour: int, business_hours_only: bool = True) -> bool:
            """현재 시간에 수집할지 결정"""
            if business_hours_only:
                # 장 운영시간 및 전후 시간 (8-18시)
                return 8 <= current_hour <= 18
            else:
                # 24시간 수집
                return True
        
        # 장중 테스트
        assert should_collect_now(9, True) == True   # 9시 - 수집
        assert should_collect_now(15, True) == True  # 3시 - 수집
        assert should_collect_now(22, True) == False # 10시 - 수집 안함
        
        # 24시간 테스트
        assert should_collect_now(22, False) == True # 10시 - 수집
        assert should_collect_now(3, False) == True  # 3시 - 수집
    
    def test_collection_priority(self):
        """수집 우선순위 테스트"""
        
        def get_collection_priority(report_type: str) -> int:
            """공시 유형별 수집 우선순위 (1: 최고, 5: 최저)"""
            priority_map = {
                "대량보유상황보고서": 1,       # 최우선
                "주요사항보고서": 2,           # 높음
                "임원소유보고서": 3,           # 보통
                "분기보고서": 4,               # 낮음
                "사업보고서": 5                # 최저
            }
            
            return priority_map.get(report_type, 5)
        
        assert get_collection_priority("대량보유상황보고서") == 1
        assert get_collection_priority("주요사항보고서") == 2
        assert get_collection_priority("임원소유보고서") == 3
        assert get_collection_priority("기타보고서") == 5

if __name__ == "__main__":
    pytest.main([__file__, "-v"])
