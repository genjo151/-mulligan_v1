# AI 머니 트래커 - 설정 관리 테스트

import pytest
import json
import os
from unittest.mock import Mock, patch

# 브라우저 환경 모킹
class MockLocalStorage:
    def __init__(self):
        self.storage = {}
    
    def getItem(self, key):
        return self.storage.get(key)
    
    def setItem(self, key, value):
        self.storage[key] = value
    
    def removeItem(self, key):
        if key in self.storage:
            del self.storage[key]

class MockWindow:
    def __init__(self):
        self.localStorage = MockLocalStorage()
        self.location = Mock()
        self.location.origin = "http://localhost:8000"

# 글로벌 모킹
mock_window = MockWindow()

class TestConfigModule:
    """설정 관리 모듈 테스트"""
    
    def setup_method(self):
        """각 테스트 전에 실행"""
        # localStorage 초기화
        mock_window.localStorage.storage.clear()
    
    def test_default_settings(self):
        """기본 설정 테스트"""
        default_settings = {
            'dartApiKey': '',
            'stockApiKey': '',
            'minScore': 5.5,
            'pushNotifications': False,
            'excludedSectors': [],
            'lastUpdated': '2024-01-01T00:00:00.000Z'  # 실제로는 현재 시간
        }
        
        # 기본 설정의 필수 필드가 모두 있는지 확인
        for key in ['dartApiKey', 'stockApiKey', 'minScore', 'pushNotifications', 'excludedSectors']:
            assert key in default_settings
    
    def test_save_and_load_settings(self):
        """설정 저장 및 로드 테스트"""
        test_settings = {
            'dartApiKey': 'test-dart-api-key-123456',
            'stockApiKey': 'test-stock-api-key-789',
            'minScore': 6.0,
            'pushNotifications': True,
            'excludedSectors': ['banks', 'insurance']
        }
        
        # 설정 저장 시뮬레이션
        settings_json = json.dumps(test_settings)
        mock_window.localStorage.setItem('smart-money-tracker-settings', settings_json)
        
        # 설정 로드 시뮬레이션
        saved_json = mock_window.localStorage.getItem('smart-money-tracker-settings')
        assert saved_json is not None
        
        loaded_settings = json.loads(saved_json)
        assert loaded_settings['dartApiKey'] == test_settings['dartApiKey']
        assert loaded_settings['stockApiKey'] == test_settings['stockApiKey']
        assert loaded_settings['minScore'] == test_settings['minScore']
        assert loaded_settings['pushNotifications'] == test_settings['pushNotifications']
        assert loaded_settings['excludedSectors'] == test_settings['excludedSectors']
    
    def test_api_key_validation(self):
        """API 키 검증 테스트"""
        # 유효한 API 키
        valid_dart_key = "a" * 40  # 40자리 키
        valid_stock_key = "b" * 32  # 32자리 키
        
        valid_settings = {
            'dartApiKey': valid_dart_key,
            'stockApiKey': valid_stock_key
        }
        
        # 유효성 검사 로직 시뮬레이션
        def validate_api_keys(settings):
            errors = []
            if not settings.get('dartApiKey') or len(settings['dartApiKey']) < 10:
                errors.append('DART API 키가 올바르지 않습니다.')
            if not settings.get('stockApiKey') or len(settings['stockApiKey']) < 10:
                errors.append('증권사 API 키가 올바르지 않습니다.')
            return {'isValid': len(errors) == 0, 'errors': errors}
        
        # 유효한 키 테스트
        result = validate_api_keys(valid_settings)
        assert result['isValid'] is True
        assert len(result['errors']) == 0
        
        # 무효한 키 테스트
        invalid_settings = {
            'dartApiKey': 'short',
            'stockApiKey': ''
        }
        
        result = validate_api_keys(invalid_settings)
        assert result['isValid'] is False
        assert len(result['errors']) == 2
    
    def test_settings_export_masking(self):
        """설정 내보내기 시 민감 정보 마스킹 테스트"""
        sensitive_settings = {
            'dartApiKey': 'sensitive-dart-key-123456789',
            'stockApiKey': 'sensitive-stock-key-987654321',
            'minScore': 5.5,
            'pushNotifications': True
        }
        
        # 마스킹 함수 시뮬레이션
        def mask_sensitive_data(settings):
            export_data = settings.copy()
            if export_data.get('dartApiKey'):
                export_data['dartApiKey'] = '***마스킹됨***'
            if export_data.get('stockApiKey'):
                export_data['stockApiKey'] = '***마스킹됨***'
            return export_data
        
        masked_settings = mask_sensitive_data(sensitive_settings)
        
        assert masked_settings['dartApiKey'] == '***마스킹됨***'
        assert masked_settings['stockApiKey'] == '***마스킹됨***'
        assert masked_settings['minScore'] == 5.5
        assert masked_settings['pushNotifications'] is True
    
    def test_settings_reset(self):
        """설정 초기화 테스트"""
        # 기존 설정 저장
        existing_settings = {
            'dartApiKey': 'existing-key',
            'stockApiKey': 'existing-stock-key',
            'minScore': 7.0,
            'pushNotifications': True,
            'excludedSectors': ['banks']
        }
        
        mock_window.localStorage.setItem('smart-money-tracker-settings', json.dumps(existing_settings))
        
        # 설정 초기화 시뮬레이션
        default_settings = {
            'dartApiKey': '',
            'stockApiKey': '',
            'minScore': 5.5,
            'pushNotifications': False,
            'excludedSectors': []
        }
        
        mock_window.localStorage.setItem('smart-money-tracker-settings', json.dumps(default_settings))
        
        # 초기화된 설정 확인
        reset_json = mock_window.localStorage.getItem('smart-money-tracker-settings')
        reset_settings = json.loads(reset_json)
        
        assert reset_settings['dartApiKey'] == ''
        assert reset_settings['stockApiKey'] == ''
        assert reset_settings['minScore'] == 5.5
        assert reset_settings['pushNotifications'] is False
        assert reset_settings['excludedSectors'] == []
    
    def test_api_url_generation(self):
        """API URL 생성 테스트"""
        base_url = "http://localhost:8000"
        
        def get_api_url(endpoint):
            return f"{base_url}/api/v1{endpoint}"
        
        # 다양한 엔드포인트 테스트
        assert get_api_url("/stocks") == "http://localhost:8000/api/v1/stocks"
        assert get_api_url("/scan/status") == "http://localhost:8000/api/v1/scan/status"
        assert get_api_url("/settings") == "http://localhost:8000/api/v1/settings"
    
    def test_auth_headers_generation(self):
        """인증 헤더 생성 테스트"""
        settings = {
            'dartApiKey': 'test-dart-key',
            'stockApiKey': 'test-stock-key'
        }
        
        def get_auth_headers(settings):
            return {
                'Content-Type': 'application/json',
                'X-DART-API-KEY': settings['dartApiKey'],
                'X-STOCK-API-KEY': settings['stockApiKey']
            }
        
        headers = get_auth_headers(settings)
        
        assert headers['Content-Type'] == 'application/json'
        assert headers['X-DART-API-KEY'] == 'test-dart-key'
        assert headers['X-STOCK-API-KEY'] == 'test-stock-key'

if __name__ == "__main__":
    pytest.main([__file__, "-v"])
